# Dalare Warehouse — Project Structure

This project was split from a single ~9,400-line HTML file into a proper
multi-file structure. **The behavior is 100% identical** — this was a pure
reorganization, verified byte-for-byte against the original file before
splitting, and re-tested end-to-end afterward (all 9 roles × 8 tabs,
workflow actions, print output).

## Folder structure

```
index.html          — page structure only (no inline CSS/JS)
css/
  styles.css         — all styling
js/
  00-config.js               — Supabase config & top-level constants
  01-auth-permissions.js     — login, session, roles & permissions (Phase 3)
  02-invoice-core.js         — save/restore helpers, shared backend calls, toolbar dispatch
  03-staff-directory.js      — Employee Directory, ID card designer
  04-attendance-leave.js     — Attendance, Shifts, Leave Requests, Payroll
  05-hr-records.js           — Assets, Expenses, Disciplinary Records, Training
  06-shared-widgets.js       — QR badges, PDF/extra/resizable table columns
  07-admin-settings.js       — custom sections, tab order, header/footer text,
                                global search, trash/recycle bin, site text
  08-admin-panel.js          — user management, activity log, CSV export, bulk delete
  09-sop.js                  — SOP module
  10-cashflow.js             — Cash Flow + tab-aware wrappers
  11-kpi.js                  — KPI Performance Evaluation + Daily Work Entry
  12-init-misc.js            — update checker + page bootstrap (must load LAST)
```

**The `js/` files are numbered because load order matters.** They're loaded
via plain `<script src="...">` tags (no bundler, no build step needed) in
the exact order the original single file executed them in. Don't reorder
the `<script>` tags in `index.html` — some later files' startup code (like
`12-init-misc.js`) depends on functions defined in earlier files already
being loaded.

## Deploying to GitHub Pages

Upload the **whole folder** (keeping the `css/` and `js/` subfolders intact)
to your repository — not just `index.html`. GitHub Pages serves static
files exactly as they sit in the repo, so the relative paths
(`css/styles.css`, `js/00-config.js`, etc.) will resolve correctly as long
as the folder structure is preserved.

## Why this split

- Each module/section now lives in its own file, matching the app's actual
  feature areas — much easier to find and edit one piece without scrolling
  through thousands of unrelated lines.
- Still zero build tooling — open `index.html` in any static file server
  (or GitHub Pages) and it works exactly as before.
- If you ever want to go further (e.g. a real bundler, TypeScript, a
  framework), this is a natural starting point since the code is already
  separated by concern.

## Testing note

Because this now loads external CSS/JS files, opening `index.html`
directly from your local filesystem (`file://...`) **will not work** in
most browsers due to CORS restrictions on local file access. Always test
through an actual web server — GitHub Pages, or locally via something like
`python3 -m http.server` from inside this folder.
