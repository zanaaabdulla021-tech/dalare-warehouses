/* =======================  STAFF DIRECTORY  ======================= */
let employees = [];

let kpiEmployeeInfoDebounce = null;
function renderKpiEmployeeInfoCard(){
  clearTimeout(kpiEmployeeInfoDebounce);
  kpiEmployeeInfoDebounce = setTimeout(async () => {
    const name = (document.querySelector('.kpi-employee').value || '').trim();
    const box = document.getElementById('kpiEmployeeInfoCard');
    if(!box) return;
    if(!name){ box.innerHTML = ''; return; }

    if(!employees.length && backendReady()){
      try{
        const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?select=*`, { headers: sbHeaders() });
        if(res.ok) employees = await res.json();
      }catch(e){ /* info card is a nice-to-have */ }
    }

    const match = employees.find(e => (e.full_name||'').trim().toLowerCase() === name.toLowerCase());
    if(!match){ box.innerHTML = ''; return; }

    box.innerHTML = `
      <div style="background:var(--sage);border-radius:14px;padding:14px 18px;margin:0 14px 10px;">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px;">
          ${match.photo ? `<img src="${match.photo}" style="width:60px;height:60px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #fff;">` : `<div style="width:60px;height:60px;border-radius:50%;background:var(--forest);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.4rem;flex-shrink:0;border:2px solid #fff;">${(match.full_name||'?').charAt(0).toUpperCase()}</div>`}
          <div>
            <div style="font-weight:800;font-size:1.1rem;color:var(--forest-deep);">${(match.full_name||'').replace(/</g,'&lt;')}</div>
            <div style="font-size:.85rem;color:#555;">${(match.job_title||'—').replace(/</g,'&lt;')}${match.department ? ' · ' + match.department.replace(/</g,'&lt;') : ''}</div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px 16px;font-size:.75rem;color:#555;border-top:1px solid rgba(12,58,27,.12);padding-top:10px;">
          <div><small style="display:block;opacity:.7;">Employee ID</small><strong>${match.id || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Phone</small><strong>${match.phone || '—'}</strong></div>
          <div style="min-width:0;"><small style="display:block;opacity:.7;">Email</small><strong style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${match.email||''}">${match.email || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Gender</small><strong>${match.gender || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Age</small><strong>${match.age || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Start Date</small><strong>${match.start_date || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Department</small><strong>${match.department || '—'}</strong></div>
          <div><small style="display:block;opacity:.7;">Status</small><strong>${match.status || '—'}</strong></div>
        </div>
      </div>`;
  }, 250);
}



/* =======================  CARD DESIGNER (admin only)  ======================= */
const CARD_FIELD_DEFS = [
  {id:'department', label:'Department'},
  {id:'gender',     label:'Gender'},
  {id:'age',        label:'Age'},
  {id:'phone',      label:'Phone'},
  {id:'start_date', label:'Start Date'}
];

let cardLayout = {
  front:  ['department','start_date'],
  public: ['department','gender','age']
};

function cardFieldValue(row, key){
  if(!row) return '';
  return row[key] !== undefined && row[key] !== null && row[key] !== '' ? row[key] : '—';
}

async function loadCardLayout(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/card_layout?id=eq.default&select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(rows.length){
      cardLayout.front  = rows[0].front_fields  || cardLayout.front;
      cardLayout.public = rows[0].public_fields || cardLayout.public;
    }
  }catch(e){ /* keep defaults */ }
}

function openCardDesigner(){
  if(!isAdmin()){ flash('Managers only.', true); return; }
  buildCdList('cdFrontFields', cardLayout.front);
  buildCdList('cdPublicFields', cardLayout.public);
  document.getElementById('cdOverlay').classList.add('open');
}
function closeCardDesigner(){ document.getElementById('cdOverlay').classList.remove('open'); }

function buildCdList(containerId, selected){
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  const ordered = [
    ...selected.filter(id => CARD_FIELD_DEFS.some(f=>f.id===id)),
    ...CARD_FIELD_DEFS.map(f=>f.id).filter(id => !selected.includes(id))
  ];
  ordered.forEach(id=>{
    const def = CARD_FIELD_DEFS.find(f=>f.id===id);
    const row = document.createElement('div');
    row.className = 'cd-field-row';
    row.draggable = true;
    row.dataset.field = id;
    row.innerHTML = `
      <span class="sb-drag">⋮⋮</span>
      <label><input type="checkbox" ${selected.includes(id)?'checked':''}> ${def.label}</label>
    `;
    row.addEventListener('dragstart', ()=>{ row.classList.add('dragging'); });
    row.addEventListener('dragend', ()=>{ row.classList.remove('dragging'); });
    container.appendChild(row);
  });
}

function readCdList(containerId){
  return Array.from(document.querySelectorAll(`#${containerId} .cd-field-row`))
    .filter(row => row.querySelector('input[type=checkbox]').checked)
    .map(row => row.dataset.field);
}

async function saveCardLayout(){
  if(!isAdmin()){ flash('Managers only.', true); return; }
  const front = readCdList('cdFrontFields');
  const pub   = readCdList('cdPublicFields');
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/card_layout`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', front_fields: front, public_fields: pub, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    cardLayout.front = front;
    cardLayout.public = pub;
    closeCardDesigner();
    logActivity('save_card_layout', null, `front:${front.join(',')} public:${pub.join(',')}`);
    flash('Card layout saved');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function makeEmpId(){
  return `EMP-${new Date().getFullYear()}-${Math.floor(Math.random()*9000 + 1000)}`;
}

function empPublicUrl(id){
  return location.origin + location.pathname + '?emp=' + encodeURIComponent(id);
}
