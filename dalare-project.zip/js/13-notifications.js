// ===================== Phase 11: Notifications =====================
let notificationsCache = [];
let notifPollTimer = null;

async function createNotification(targetEmail, type, title, detail, link){
  if(!backendReady() || !targetEmail) return;
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/notifications`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        id: 'notif-' + Date.now().toString(36) + Math.random().toString(36).slice(2,6),
        target_email: targetEmail, type, title, detail: detail || null, link: link || null,
        is_read: false, created_at: new Date().toISOString()
      })
    });
  }catch(e){ /* notifications are best-effort, never block the real action */ }
}

// Notifies everyone with 'approve' permission on a module — used when a
// form is submitted for review/approval so approvers see it without
// needing to poll the form manually.
async function notifyApprovers(tab, title, detail, link){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?select=email,role`, { headers: sbHeaders() });
    if(!res.ok) return;
    const profiles = await res.json();
    const approverEmails = profiles.filter(p => {
      const perm = permissionMatrix[p.role] && permissionMatrix[p.role][tab];
      return perm && perm.approve;
    }).map(p => p.email);
    await Promise.all(approverEmails.map(email => createNotification(email, 'approval_needed', title, detail, link)));
  }catch(e){ /* best-effort */ }
}

async function loadNotifications(){
  if(!backendReady() || !session.email) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/notifications?target_email=eq.${encodeURIComponent(session.email)}&select=*&order=created_at.desc&limit=30`, { headers: sbHeaders() });
    notificationsCache = res.ok ? await res.json() : [];
    renderNotificationBell();
  }catch(e){ /* keep previous state */ }
}

function renderNotificationBell(){
  const badge = document.getElementById('notifUnreadBadge');
  if(!badge) return;
  const unread = notificationsCache.filter(n => !n.is_read).length;
  badge.style.display = unread > 0 ? 'flex' : 'none';
  badge.textContent = unread > 9 ? '9+' : String(unread);
  renderNotificationList();
}

function renderNotificationList(){
  const box = document.getElementById('notifList');
  if(!box) return;
  if(!notificationsCache.length){
    box.innerHTML = '<div style="text-align:center;color:#888;font-size:.8rem;padding:20px;">No notifications yet.</div>';
    return;
  }
  const icons = { approval_needed:'📨', approved:'✓', rejected:'✕', returned:'↺', leave_submitted:'📅', leave_decided:'📅', overtime_pending:'⏰', kpi_pending:'📊' };
  box.innerHTML = notificationsCache.map(n => `
    <div onclick="openNotification('${n.id}','${(n.link||'').replace(/'/g,"\\'")}')" style="cursor:pointer;padding:10px 12px;border-radius:10px;display:flex;gap:10px;align-items:flex-start;${n.is_read ? '' : 'background:var(--sage);'}">
      <span style="font-size:1rem;flex-shrink:0;">${icons[n.type] || '🔔'}</span>
      <div style="flex:1;min-width:0;">
        <div style="font-weight:${n.is_read ? '600' : '800'};font-size:.8rem;">${n.title.replace(/</g,'&lt;')}</div>
        ${n.detail ? `<div style="font-size:.72rem;color:#666;">${n.detail.replace(/</g,'&lt;')}</div>` : ''}
        <div style="font-size:.65rem;color:#999;margin-top:2px;">${timeAgo(n.created_at)}</div>
      </div>
      ${!n.is_read ? '<span style="width:7px;height:7px;border-radius:50%;background:var(--forest);flex-shrink:0;margin-top:4px;"></span>' : ''}
    </div>`).join('');
}

function toggleNotificationPanel(){
  const panel = document.getElementById('notifPanel');
  const willOpen = panel.style.display === 'none';
  if(willOpen){
    const btn = panel.previousElementSibling;
    const rect = btn.getBoundingClientRect();
    panel.style.top = (rect.bottom + 6) + 'px';
    panel.style.right = (window.innerWidth - rect.right) + 'px';
    loadNotifications();
  }
  panel.style.display = willOpen ? 'block' : 'none';
}
document.addEventListener('click', (e) => {
  const panel = document.getElementById('notifPanel');
  if(!panel || panel.style.display === 'none') return;
  const wrap = panel.parentElement;
  if(wrap && !wrap.contains(e.target)) panel.style.display = 'none';
});

async function openNotification(id, link){
  const n = notificationsCache.find(x => x.id === id);
  if(n && !n.is_read){
    n.is_read = true;
    renderNotificationBell();
    fetch(`${SUPABASE_URL}/rest/v1/notifications?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ is_read: true })
    }).catch(()=>{});
  }
  document.getElementById('notifPanel').style.display = 'none';
  if(link) switchTab(link);
}

async function markAllNotificationsRead(){
  const unreadIds = notificationsCache.filter(n => !n.is_read).map(n => n.id);
  notificationsCache.forEach(n => n.is_read = true);
  renderNotificationBell();
  if(!unreadIds.length || !backendReady()) return;
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/notifications?target_email=eq.${encodeURIComponent(session.email)}&is_read=eq.false`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ is_read: true })
    });
  }catch(e){ /* best-effort */ }
}

function startNotificationPolling(){
  clearInterval(notifPollTimer);
  notifPollTimer = setInterval(loadNotifications, 60000); // refresh every minute
}
