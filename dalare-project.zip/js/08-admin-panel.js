/* =======================  ADMIN PANEL  ======================= */
function openAdmin(){
  if(!isAdmin()){ flash('Managers only.', true); return; }
  document.getElementById('admTabLog').style.display   = isSuperAdmin() ? '' : 'none';
  document.getElementById('admTabTools').style.display = isSuperAdmin() ? '' : 'none';
  document.getElementById('admOverlay').classList.add('open');
  admTab('users');
}
function closeAdmin(){ document.getElementById('admOverlay').classList.remove('open'); }

function admTab(name){
  if((name === 'log' || name === 'tools') && !isSuperAdmin()) name = 'users';
  ['users','log','tools'].forEach(n=>{
    document.getElementById('admPane' + n[0].toUpperCase() + n.slice(1))
      .classList.toggle('active', n === name);
    document.getElementById('admTab' + n[0].toUpperCase() + n.slice(1))
      .classList.toggle('active', n === name);
  });
  if(name === 'users') loadUsers();
  if(name === 'log')   loadActivity();
}

/* ---- Users ---- */
async function loadUsers(){
  const box = document.getElementById('admUsers');
  box.innerHTML = 'Loading…';
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?select=id,email,role&order=email`,
      { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const users = await res.json();
    if(!users.length){ box.innerHTML = '<div class="mgr-empty">No users yet.</div>'; return; }

    const deptRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?select=email,department`, { headers: sbHeaders() });
    const deptRows = deptRes.ok ? await deptRes.json() : [];
    const deptByEmail = {};
    deptRows.forEach(r => { if(r.email) deptByEmail[r.email] = r.department || ''; });

    const roleOptions = (current) => {
      const all = isSuperAdmin()
        ? ['employee','viewer','staff','warehouse_staff','accountant','reviewer','manager','admin','super_admin']
        : ['employee','viewer','staff'];
      return all.map(r => `<option value="${r}" ${r===current?'selected':''}>${ROLE_LABELS[r] || r}</option>`).join('');
    };
    document.getElementById('newUserRole').innerHTML = roleOptions('staff');

    box.innerHTML = `<table class="adm-table">
      <tr><th>Email</th><th style="width:130px;">Role</th><th style="width:130px;">Department</th><th style="width:70px;"></th></tr>
      ${users.map(u=>`<tr>
        <td>${(u.email||'').replace(/</g,'&lt;')}</td>
        <td>
          <select onchange="setUserRole('${u.id}', this.value)"
            ${(u.id === session.userId || (!isSuperAdmin() && ['admin','super_admin'].includes(u.role))) ? 'disabled' : ''}>
            ${roleOptions(u.role)}
          </select>
        </td>
        <td>
          <input type="text" class="user-dept-input" list="staffDeptList" value="${(deptByEmail[u.email]||'').replace(/"/g,'&quot;')}"
            data-email="${(u.email||'').replace(/"/g,'&quot;')}"
            onchange="setUserDepartment('${(u.email||'').replace(/'/g,"\\'")}', this.value)"
            style="width:100%;border:1px solid var(--line);border-radius:6px;padding:5px 7px;font-size:.78rem;"
            ${!isSuperAdmin() ? 'disabled' : ''}>
        </td>
        <td>${(u.id === session.userId || !isSuperAdmin()) ? ''
          : `<button class="mgr-btn del-b" onclick="deleteUser('${(u.email||'').replace(/'/g,"\\'")}')">Delete</button>`}</td>
      </tr>`).join('')}
    </table>`;
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}

async function setUserDepartment(email, department){
  try{
    const existingRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(email)}&select=id`, { headers: sbHeaders() });
    const existingRows = existingRes.ok ? await existingRes.json() : [];
    const empId = existingRows.length ? existingRows[0].id : 'ACCT-' + slugifyEmployeeName(email.split('@')[0]);
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({
        id: empId, email, department,
        full_name: existingRows.length ? undefined : email.split('@')[0],
        updated_at: new Date().toISOString()
      })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('set_user_department', null, email + ' -> ' + department);
    flash('Department updated for ' + email);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function createUser(){
  const email = document.getElementById('newUserEmail').value.trim();
  const pass  = document.getElementById('newUserPass').value;
  const role  = document.getElementById('newUserRole').value;
  const dept  = document.getElementById('newUserDept').value.trim();
  if(!email || !pass){ flash('Enter an email and password.', true); return; }
  if(pass.length < 6){ flash('Password must be at least 6 characters.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/admin_create_user`, {
      method:'POST', headers: sbHeaders(),
      body: JSON.stringify({ new_email: email, new_password: pass, new_role: role })
    });
    const body = await res.json();
    if(!res.ok) throw new Error(body.message || body.hint || JSON.stringify(body));

    if(dept){
      try{
        const existingRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(email)}&select=id`, { headers: sbHeaders() });
        const existingRows = existingRes.ok ? await existingRes.json() : [];
        const empId = existingRows.length ? existingRows[0].id : 'ACCT-' + slugifyEmployeeName(email.split('@')[0]);
        await fetch(`${SUPABASE_URL}/rest/v1/employees`, {
          method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
          body: JSON.stringify({
            id: empId, email, department: dept,
            full_name: existingRows.length ? undefined : email.split('@')[0],
            updated_at: new Date().toISOString()
          })
        });
      }catch(e2){ console.error('department link failed', e2); }
    }

    document.getElementById('newUserEmail').value = '';
    document.getElementById('newUserPass').value = '';
    document.getElementById('newUserDept').value = '';
    logActivity('create_user', null, email + ' as ' + role + (dept ? ' / ' + dept : ''));
    flash('User created: ' + email);
    loadUsers();
  }catch(e){ console.error(e); flash(String(e.message || e).slice(0,120), true); }
}

async function deleteUser(email){
  if(!isSuperAdmin()){ flash('Only a super admin can delete users.', true); return; }
  if(!confirm(`Permanently delete the account ${email}? This cannot be undone.`)) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/admin_delete_user`, {
      method:'POST', headers: sbHeaders(),
      body: JSON.stringify({ target_email: email })
    });
    const body = await res.json();
    if(!res.ok) throw new Error(body.message || body.hint || JSON.stringify(body));
    logActivity('delete_user', null, email);
    flash('User deleted: ' + email);
    loadUsers();
  }catch(e){ console.error(e); flash(String(e.message || e).slice(0,120), true); }
}

async function setUserRole(id, role){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${id}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ role })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('role_change', id, 'set to ' + role);
    flash('Role updated');
  }catch(e){ console.error(e); flash(sbError(e), true); loadUsers(); }
}

/* ---- Activity log ---- */
async function logActivity(action, formId, detail){
  if(!backendReady() || !session.token) return;
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/activity_log`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        user_email: session.email, action: action,
        form_id: formId || null, form_type: activeTab, detail: detail || null
      })
    });
  }catch(e){ /* logging must never block the user */ }
}

// ===================== Phase 11: Notifications =====================
// A notification targets either a specific person (userEmail) or every
// person with a given role (recipientRole) — never both.
async function createNotification({ userEmail, recipientRole, title, message, linkTab }){
  if(!backendReady()) return;
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/notifications`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        user_email: userEmail || null, recipient_role: recipientRole || null,
        title, message: message || null, link_tab: linkTab || null,
        is_read: false, created_at: new Date().toISOString()
      })
    });
  }catch(e){ /* notifications must never block the user's action */ }
}

let notifCache = [];

async function loadNotifications(){
  const badge = document.getElementById('notifUnreadBadge');
  if(!backendReady() || !session.email){ if(badge) badge.style.display = 'none'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/notifications?or=(user_email.eq.${encodeURIComponent(session.email)},recipient_role.eq.${session.role})&select=*&order=created_at.desc&limit=30`, { headers: sbHeaders() });
    notifCache = res.ok ? await res.json() : [];
    const unread = notifCache.filter(n => !n.is_read).length;
    if(badge){
      badge.textContent = unread > 9 ? '9+' : String(unread);
      badge.style.display = unread > 0 ? 'flex' : 'none';
    }
    renderNotifPanel();
  }catch(e){ /* keep quiet — notifications are non-critical */ }
}

function renderNotifPanel(){
  const box = document.getElementById('notifPanelList');
  if(!box) return;
  if(!notifCache.length){ box.innerHTML = '<div style="padding:16px;text-align:center;color:#888;font-size:.8rem;">No notifications yet.</div>'; return; }
  box.innerHTML = notifCache.map(n => `
    <div onclick="openNotification(${n.id})" style="padding:10px 14px;border-bottom:1px solid var(--line);cursor:pointer;background:${n.is_read?'#fff':'var(--sage)'};">
      <div style="font-weight:700;font-size:.8rem;color:#233b2b;">${(n.title||'').replace(/</g,'&lt;')}</div>
      ${n.message ? `<div style="font-size:.74rem;color:#666;margin-top:2px;">${String(n.message).replace(/</g,'&lt;')}</div>` : ''}
      <div style="font-size:.68rem;color:#999;margin-top:3px;">${timeAgo(n.created_at)}</div>
    </div>`).join('');
}

function toggleNotifPanel(){
  const panel = document.getElementById('notifPanel');
  const willOpen = panel.style.display === 'none';
  if(willOpen){
    const btn = document.getElementById('notifBellWrap');
    const rect = btn.getBoundingClientRect();
    panel.style.top = (rect.bottom + 6) + 'px';
    panel.style.left = Math.max(8, rect.left) + 'px';
    loadNotifications();
  }
  panel.style.display = willOpen ? 'block' : 'none';
}
document.addEventListener('click', (e) => {
  const wrap = document.getElementById('notifBellWrap');
  const panel = document.getElementById('notifPanel');
  if(wrap && panel && panel.style.display !== 'none' && !wrap.contains(e.target)) panel.style.display = 'none';
});

async function openNotification(id){
  const n = notifCache.find(x => x.id === id);
  if(!n) return;
  if(!n.is_read){
    try{
      await fetch(`${SUPABASE_URL}/rest/v1/notifications?id=eq.${id}`, {
        method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}), body: JSON.stringify({ is_read: true })
      });
      n.is_read = true;
      loadNotifications();
    }catch(e){}
  }
  document.getElementById('notifPanel').style.display = 'none';
  if(n.link_tab && canViewTab(n.link_tab)) switchTab(n.link_tab);
}

async function markAllNotifsRead(){
  const unreadIds = notifCache.filter(n => !n.is_read).map(n => n.id);
  if(!unreadIds.length) return;
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/notifications?id=in.(${unreadIds.join(',')})`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}), body: JSON.stringify({ is_read: true })
    });
    loadNotifications();
  }catch(e){ flash(sbError(e), true); }
}

let activityLogRows = [];

const ACTIVITY_ACTION_COLORS = {
  save: '#0f7a3d', save_kpi: '#0f7a3d', save_employee: '#0f7a3d', save_card_layout: '#0f7a3d', save_kpi_order: '#0f7a3d',
  delete: '#a8462e', delete_employee: '#a8462e',
  change_logo: '#7c5cd4',
};
function activityActionColor(action){
  if(ACTIVITY_ACTION_COLORS[action]) return ACTIVITY_ACTION_COLORS[action];
  if(action.startsWith('save')) return '#0f7a3d';
  if(action.startsWith('delete')) return '#a8462e';
  return '#555';
}
function relativeTime(dateStr){
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diffMs / 60000);
  if(mins < 1) return 'just now';
  if(mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if(hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if(days < 30) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString('en-US');
}

async function loadActivity(){
  const box = document.getElementById('admLog');
  box.innerHTML = 'Loading…';
  try{
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/activity_log?select=*&order=created_at.desc&limit=100`,
      { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    activityLogRows = await res.json();

    const actions = [...new Set(activityLogRows.map(r => r.action))].sort();
    const actionSel = document.getElementById('admLogActionFilter');
    actionSel.innerHTML = '<option value="">All actions</option>' + actions.map(a => `<option value="${a}">${a}</option>`).join('');

    const modules = [...new Set(activityLogRows.map(r => r.form_type).filter(Boolean))].sort();
    const modSel = document.getElementById('admLogModuleFilter');
    modSel.innerHTML = '<option value="">All modules</option>' + modules.map(m => `<option value="${m}">${m}</option>`).join('');

    renderActivityLog();
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}

function renderActivityLog(){
  const box = document.getElementById('admLog');
  const search = (document.getElementById('admLogSearch').value || '').toLowerCase();
  const actionFilter = document.getElementById('admLogActionFilter').value;
  const moduleFilter = document.getElementById('admLogModuleFilter').value;
  const fromDate = document.getElementById('admLogFrom').value;
  const toDate = document.getElementById('admLogTo').value;

  let rows = activityLogRows;
  if(actionFilter) rows = rows.filter(r => r.action === actionFilter);
  if(moduleFilter) rows = rows.filter(r => r.form_type === moduleFilter);
  if(fromDate) rows = rows.filter(r => r.created_at >= fromDate);
  if(toDate) rows = rows.filter(r => r.created_at <= toDate + 'T23:59:59');
  if(search){
    rows = rows.filter(r =>
      (r.user_email||'').toLowerCase().includes(search) ||
      (r.detail||'').toLowerCase().includes(search) ||
      (r.form_id||'').toLowerCase().includes(search)
    );
  }

  const uniqueUsers = new Set(rows.map(r => r.user_email)).size;
  const summaryEl = document.getElementById('admLogSummary');
  if(summaryEl) summaryEl.textContent = `${rows.length} action${rows.length===1?'':'s'} · ${uniqueUsers} user${uniqueUsers===1?'':'s'}`;

  if(!rows.length){ box.innerHTML = '<div class="mgr-empty">No matching activity.</div>'; return; }

  // Group consecutive rows by calendar day for easier scanning.
  let lastDay = null;
  const bodyRows = rows.map(r=>{
    const day = new Date(r.created_at).toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'});
    const dayHeader = day !== lastDay ? `<tr><td colspan="6" style="background:var(--sage);font-weight:700;font-size:.72rem;color:var(--forest-deep);padding:5px 9px;">${day}</td></tr>` : '';
    lastDay = day;
    const color = activityActionColor(r.action);
    return dayHeader + `<tr>
      <td title="${new Date(r.created_at).toLocaleString('en-US')}">${relativeTime(r.created_at)}</td>
      <td>${(r.user_email||'').replace(/</g,'&lt;')}</td>
      <td>${(r.form_type||'—').replace(/</g,'&lt;')}</td>
      <td><span style="background:${color}1a;color:${color};padding:2px 8px;border-radius:999px;font-weight:700;font-size:.72rem;">${r.action}</span></td>
      <td>${r.detail ? String(r.detail).replace(/</g,'&lt;') : ''}</td>
      <td style="font-family:'IBM Plex Mono',monospace;">${r.form_id || ''}</td>
    </tr>`;
  }).join('');

  box.innerHTML = `<table class="adm-table">
    <tr><th>When</th><th>User</th><th>Module</th><th>Action</th><th>Detail</th><th>Form ID</th></tr>
    ${bodyRows}
  </table>`;
}

function exportActivityLogCSV(){
  const search = (document.getElementById('admLogSearch').value || '').toLowerCase();
  const actionFilter = document.getElementById('admLogActionFilter').value;
  const moduleFilter = document.getElementById('admLogModuleFilter').value;
  const fromDate = document.getElementById('admLogFrom').value;
  const toDate = document.getElementById('admLogTo').value;

  let rows = activityLogRows;
  if(actionFilter) rows = rows.filter(r => r.action === actionFilter);
  if(moduleFilter) rows = rows.filter(r => r.form_type === moduleFilter);
  if(fromDate) rows = rows.filter(r => r.created_at >= fromDate);
  if(toDate) rows = rows.filter(r => r.created_at <= toDate + 'T23:59:59');
  if(search){
    rows = rows.filter(r =>
      (r.user_email||'').toLowerCase().includes(search) ||
      (r.detail||'').toLowerCase().includes(search) ||
      (r.form_id||'').toLowerCase().includes(search)
    );
  }
  if(!rows.length){ flash('Nothing to export.', true); return; }

  const cols = ['created_at','user_email','form_type','action','detail','form_id'];
  let csv = cols.join(',') + '\n';
  rows.forEach(r=>{ csv += cols.map(k=>csvCell(r[k])).join(',') + '\n'; });

  const blob = new Blob(['\uFEFF' + csv], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `activity-log-${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
}


/* ---- Export CSV ---- */
function csvCell(v){
  const s = v === null || v === undefined ? '' : String(v);
  return '"' + s.replace(/"/g,'""') + '"';
}

async function exportFormsToExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load. Check your connection and try again.', true); return; }
  const tab = activeTab;
  if(tab !== 'inv' && tab !== 'cf'){ flash('Excel export is available for Invoice and Cash Flow only.', true); return; }
  const table = tab === 'inv' ? 'forms' : 'cashflow_forms';
  const q = (document.getElementById('mgrSearch').value || '').toLowerCase().trim();
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=*&deleted_at=is.null&order=updated_at.desc`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    let forms = await res.json();
    if(q){
      forms = forms.filter(f =>
        (f.id||'').toLowerCase().includes(q) ||
        (f.company_name||'').toLowerCase().includes(q)
      );
    }
    if(!forms.length){ flash('No forms match your search — nothing to export.', true); return; }

    const flatRows = [];
    forms.forEach(f => {
      const company = f.company_name || '(unnamed)';
      const rows = (f.data && f.data.rows) ? f.data.rows : [];
      if(!rows.length){
        flatRows.push({ 'Company': company, 'Form ID': f.id, 'Updated By': f.updated_by || '', 'Updated At': f.updated_at || '' });
        return;
      }
      rows.forEach(r => {
        if(tab === 'inv'){
          flatRows.push({
            'Company': company, 'Form ID': f.id,
            'Date': r.date || '', 'Invoice Number': r.invoiceNo || '',
            'Price (IQD)': r.price || '', 'Bonus (IQD)': r.bonus || '',
            'Cash Back (%)': r.cashback || '', 'Discount (%)': r.discount || '',
            'Notes': r.notes || '', 'Paid': r.paid ? 'Yes' : 'No',
            'Updated By': f.updated_by || '', 'Updated At': f.updated_at || ''
          });
        }else{
          flatRows.push({
            'Company': company, 'Form ID': f.id,
            'Product': r.product || '', 'Batch/Lot Number': r.sectionNo || '',
            'Items per Package': r.itemsPerPkg || '', 'Cash Flow': r.cashflow || '',
            'Stock Dalare': r.stock || '', 'Note': r.note || '',
            'Updated By': f.updated_by || '', 'Updated At': f.updated_at || ''
          });
        }
      });
    });

    const ws = XLSX.utils.json_to_sheet(flatRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, tab === 'inv' ? 'Invoices' : 'Cash Flow');
    XLSX.writeFile(wb, `${tab === 'inv' ? 'invoice' : 'cashflow'}-export-${new Date().toISOString().slice(0,10)}.xlsx`);
    logActivity('export_excel', null, table);
    flash(`Exported ${forms.length} forms (${flatRows.length} rows)`);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function exportCSV(){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${activeTable()}?select=*&order=updated_at.desc`,
      { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Nothing to export.', true); return; }

    const cols = ['id','company_name','stage','updated_by','updated_at'];
    let csv = cols.join(',') + '\n';
    rows.forEach(r=>{ csv += cols.map(k=>csvCell(r[k])).join(',') + '\n'; });

    const blob = new Blob(['\uFEFF' + csv], {type:'text/csv;charset=utf-8;'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${activeTable()}_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    logActivity('export', null, activeTable());
    flash('Exported ' + rows.length + ' rows');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

/* ---- Bulk delete ---- */
async function bulkDelete(){
  const days = parseInt(document.getElementById('admBulkDays').value, 10);
  const label = days === 0 ? 'ALL forms' : `forms older than ${days} days`;
  if(!confirm(`Move ${label} in "${activeTable()}" to Trash? You can restore them later.`)) return;
  try{
    let url = `${SUPABASE_URL}/rest/v1/${activeTable()}?deleted_at=is.null`;
    if(days !== 0){
      const cutoff = new Date(Date.now() - days*24*60*60*1000).toISOString();
      url += `&updated_at=lt.${cutoff}`;
    }
    const res = await fetch(url, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=representation'}),
      body: JSON.stringify({ deleted_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    const moved = await res.json();
    logActivity('bulk_delete', null, `${moved.length} from ${activeTable()} moved to trash`);
    flash('Moved ' + moved.length + ' forms to Trash');
    loadFormsList();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
