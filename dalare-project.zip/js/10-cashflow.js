/* =======================  TABS + CASH FLOW  ======================= */
let activeTab = 'home';                // 'home' | 'inv' | 'cf' | 'sop' | 'staff' | 'custom:*'
let cfRowCount = 0;
let cfFormId = null;
let currentStageCF = 'entry';

function setStageCF(stage){
  if(!STAGES[stage]) stage = 'entry';
  currentStageCF = stage;
  const badge = document.getElementById('cfStageBadge');
  if(badge){
    badge.textContent = STAGES[stage].label;
    badge.className = 'stage-badge ' + STAGES[stage].cls;
  }
  renderStageActions('cashflow_forms', cfFormId, 'cf');
  renderApprovalHistory('cashflow_forms', cfFormId);
}


function openDrawer(){
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drawerOverlay').classList.add('open');
}
function closeDrawer(){
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawerOverlay').classList.remove('open');
}

function switchTab(tab){
  closeDrawer();
  if(!canViewTab(tab)) return;
  activeTab = tab;
  document.getElementById('homeScreen').classList.toggle('hidden-tab', tab !== 'home');
  document.getElementById('form').classList.toggle('hidden-tab', tab !== 'inv');
  document.getElementById('cfForm').classList.toggle('hidden-tab', tab !== 'cf');
  document.getElementById('sopForm').classList.toggle('hidden-tab', tab !== 'sop');
  document.getElementById('staffForm').classList.toggle('hidden-tab', tab !== 'staff');
  document.getElementById('kpiForm').classList.toggle('hidden-tab', tab !== 'kpi');
  document.getElementById('attForm').classList.toggle('hidden-tab', tab !== 'att');
  document.getElementById('hrForm').classList.toggle('hidden-tab', tab !== 'hr');
  document.getElementById('tabHome').classList.toggle('active', tab === 'home');
  document.getElementById('tabInv').classList.toggle('active', tab === 'inv');
  document.getElementById('tabCf').classList.toggle('active', tab === 'cf');
  document.getElementById('tabSop').classList.toggle('active', tab === 'sop');
  document.getElementById('tabStaff').classList.toggle('active', tab === 'staff');
  document.getElementById('tabKpi').classList.toggle('active', tab === 'kpi');
  document.getElementById('tabAtt').classList.toggle('active', tab === 'att');
  document.getElementById('tabHr').classList.toggle('active', tab === 'hr');
  document.querySelectorAll('.custom-tab-btn').forEach(btn=>{
    const sid = btn.id.replace('tab_custom_','');
    const sheet = document.getElementById('customForm_' + sid);
    const match = tab === 'custom:' + sid;
    btn.classList.toggle('active', match);
    if(sheet) sheet.classList.toggle('hidden-tab', !match);
  });
  if(tab === 'home'){ renderHomeGrid(); loadHomeNotifications(); loadHomeAnnouncement(); loadHomeTrendChart(); }
  document.querySelector('.toolbar').style.display = (tab === 'home' || isEmployee()) ? 'none' : 'flex';
  if(tab === 'staff') loadEmployees();
  if(tab === 'att') loadAttendanceTab();
  if(tab === 'hr') loadHrRecordsTab();
  if(tab === 'kpi') showKpiDeptPicker();
  if(tab === 'sop') document.querySelectorAll('#sopList textarea').forEach(autoGrow);
  applyViewerLock();
  updatePdfColsButton();
  updateColumnMgrButton();
}

function addRowCF(){
  cfRowCount++;
  const tbody = document.getElementById('cashBody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="row-num">${cfRowCount}</td>
    <td><input type="text"></td>
    <td><input type="text" list="cfSectionList" class="cf-section-input"></td>
    <td><input type="number" min="0"></td>
    <td><input type="text" inputmode="decimal" class="cash-input" oninput="calcCFTotal()" onblur="formatMoneyField(this)"></td>
    <td><input type="text" inputmode="decimal" class="stock-input" onblur="formatMoneyField(this)"></td>
    <td><input type="text"></td>
    ${extraColCells('cf')}
    <td><button class="btn-small remove" onclick="removeRowCF(this)">×</button></td>
  `;
  tbody.appendChild(tr);
}

function removeRowCF(btn){
  btn.closest('tr').remove();
  const rows = document.querySelectorAll('#cashBody tr');
  rows.forEach((r,i)=>{ r.querySelector('.row-num').textContent = i+1; });
  cfRowCount = rows.length;
  calcCFTotal();
}

function calcCFTotal(){
  let sum = 0;
  document.querySelectorAll('#cashBody .cash-input').forEach(el=>{ sum += parseMoney(el.value); });
  document.getElementById('cfGrandTotal').textContent = formatMoney(sum);
}

function setCFFormId(id){
  cfFormId = id;
  document.getElementById('cfFormIdDisplay').textContent = id || '—';
}
function makeCFFormId(){
  return `CF-${new Date().getFullYear()}-${Math.floor(Math.random()*90000 + 10000)}`;
}

function serializeCF(){
  const rows = Array.from(document.querySelectorAll('#cashBody tr')).map(tr => {
    const c = tr.querySelectorAll('input');
    const extra = {};
    tr.querySelectorAll('td[data-extra-cell] input').forEach(inp => { extra[inp.dataset.extra] = inp.value; });
    return { product:c[0].value, sectionNo:c[1].value, itemsPerPkg:c[2].value, cashflow:c[3].value, stock:c[4].value, note:c[5].value, extra };
  });
  return { companyName: document.querySelector('.cf-company').value, rows: rows };
}

function restoreCF(d){
  document.querySelector('.cf-company').value = d.companyName || '';
  document.getElementById('cashBody').innerHTML = '';
  cfRowCount = 0;
  const rows = d.rows && d.rows.length ? d.rows : [];
  const total = Math.max(rows.length, 12);
  for(let i=0;i<total;i++) addRowCF();
  Array.from(document.querySelectorAll('#cashBody tr')).forEach((tr,i)=>{
    const r = rows[i]; if(!r) return;
    const c = tr.querySelectorAll('input');
    c[0].value = r.product || '';      c[1].value = r.sectionNo || '';
    c[2].value = r.itemsPerPkg || '';  c[3].value = r.cashflow || '';
    c[4].value = r.stock || '';        c[5].value = r.note || '';
    if(r.extra){
      tr.querySelectorAll('td[data-extra-cell] input').forEach(inp => {
        inp.value = r.extra[inp.dataset.extra] || '';
      });
    }
  });
  calcCFTotal();
  applyViewerLock();
}

/* ---- Tab-aware wrappers (each tab has its own Supabase table) ---- */
const TABLES = { inv:'forms', cf:'cashflow_forms', sop:'sop_forms', kpi:'kpi_forms' };
function activeTable(){
  if(activeTab && activeTab.startsWith('custom:')) return 'custom_section_forms';
  return TABLES[activeTab];
}

