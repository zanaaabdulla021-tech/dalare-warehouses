
/* =========================================================================
   CONFIG — paste your Supabase project details here.
   Get these from: Supabase dashboard > Project Settings > API
   ========================================================================= */
const SUPABASE_URL_RAW  = 'https://sgxgmrrrbqkwunprybsj.supabase.co/rest/v1/';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNneGdtcnJyYnFrd3VucHJ5YnNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY2NDYyNjEsImV4cCI6MjEwMjIyMjI2MX0.HJYrwzfgmEIiA6393emqhUQvhzOiOnXhCBxJnIz2Xlw';

// Normalise the URL: strip trailing slashes and any accidental /rest/v1 suffix,
// so pasting either form of the URL still works.
const SUPABASE_URL = String(SUPABASE_URL_RAW)
  .trim()
  .replace(/\/+$/, '')
  .replace(/\/rest\/v1$/, '');

const RETENTION_DAYS = 30;

const STAGES = {
  entry:               { label: 'Data Entry',          cls: 'stage-entry' },
  review:              { label: 'Under Review',        cls: 'stage-review' },
  manager_approval:    { label: 'Manager Approval',    cls: 'stage-approval' },
  accounting_approval: { label: 'Accounting Approval', cls: 'stage-approval' },
  completed:           { label: 'Completed',           cls: 'stage-completed' },
  rejected:            { label: 'Rejected',            cls: 'stage-rejected' },
  returned:            { label: 'Returned for Correction', cls: 'stage-review' },
  cancelled:           { label: 'Cancelled',           cls: 'stage-rejected' }
};
// Valid forward transitions from each stage, and which permission type
// is required to make that specific move.
const STAGE_TRANSITIONS = {
  entry:               [{ to:'review',              action:'Submit for Review',       perm:'edit'    }],
  review:              [{ to:'manager_approval',     action:'Approve (Reviewer)',      perm:'approve' },
                         { to:'returned',             action:'Return for Correction',   perm:'reject'  },
                         { to:'rejected',             action:'Reject',                  perm:'reject'  }],
  manager_approval:    [{ to:'accounting_approval',  action:'Approve (Manager)',        perm:'approve' },
                         { to:'returned',             action:'Return for Correction',   perm:'reject'  },
                         { to:'rejected',             action:'Reject',                  perm:'reject'  }],
  accounting_approval: [{ to:'completed',            action:'Approve (Accounting)',     perm:'approve' },
                         { to:'returned',             action:'Return for Correction',   perm:'reject'  },
                         { to:'rejected',             action:'Reject',                  perm:'reject'  }],
  returned:            [{ to:'entry',                action:'Resume Editing',           perm:'edit'    }],
};

let currentFormId = null;
let currentStage  = 'entry';
let rowCount = 0;

const backendReady = () =>
  SUPABASE_URL.startsWith('http') && SUPABASE_ANON_KEY.length > 20;

function validateNonNegative(rows){
  // rows: array of { value, label } — returns the first offending label, or null if all OK.
  for(const r of rows){
    const n = parseFloat(r.value);
    if(!isNaN(n) && n < 0) return r.label;
  }
  return null;
}

function sbError(e){
  const msg = String(e && e.message || e);
  if(msg.includes('PGRST125') || msg.includes('Invalid path'))
    return 'Bad Supabase URL — remove any trailing "/" from SUPABASE_URL.';
  if(msg.includes('PGRST205') || msg.includes('Could not find the table'))
    return 'Table missing — run the SQL from the setup guide in Supabase.';
  if(msg.includes('PGRST204') || msg.includes('Could not find the'))
    return 'A database update is needed — run the latest SQL migration in Supabase, then try again.';
  if(msg.includes('JWT') || msg.includes('apikey') || msg.includes('401'))
    return 'Bad API key — re-copy the anon public key.';
  if(msg.includes('Failed to fetch'))
    return 'Network/CORS error — check the URL is correct.';
  return 'Error: ' + msg.slice(0, 120);
}

let session = { token:null, email:null, role:'staff', userId:null };

function sbHeaders(extra){
  return Object.assign({
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + (session.token || SUPABASE_ANON_KEY),
    'Content-Type': 'application/json'
  }, extra || {});
}
