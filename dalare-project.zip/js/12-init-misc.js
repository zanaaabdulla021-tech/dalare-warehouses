/* =======================  UPDATE-AVAILABLE CHECKER  ======================= */
let __pageFingerprint = null;
async function __captureFingerprint(){
  if(location.protocol === 'file:') return; // no server to check against locally
  try{
    const res = await fetch(location.pathname + '?_=' + Date.now(), { method:'HEAD', cache:'no-store' });
    __pageFingerprint = res.headers.get('etag') || res.headers.get('last-modified') || res.headers.get('content-length');
  }catch(e){ /* offline or blocked; skip */ }
}
async function __checkForUpdate(){
  if(location.protocol === 'file:' || !__pageFingerprint) return;
  try{
    const res = await fetch(location.pathname + '?_=' + Date.now(), { method:'HEAD', cache:'no-store' });
    const current = res.headers.get('etag') || res.headers.get('last-modified') || res.headers.get('content-length');
    if(current && current !== __pageFingerprint){
      document.getElementById('updateBanner').style.display = 'flex';
    }
  }catch(e){ /* offline; try again next interval */ }
}
__captureFingerprint().then(() => {
  setInterval(__checkForUpdate, 3 * 60 * 1000); // every 3 minutes
  document.addEventListener('visibilitychange', () => { if(!document.hidden) __checkForUpdate(); });
});

// If a QR code was scanned, show the public badge instead of the app
checkPublicView().then(isPublic => { if(!isPublic) restoreSession(); });

function isEmptyInput(el){
  if(el.type === 'checkbox' || el.type === 'radio') return !el.checked;
  return !el.value || !el.value.trim();
}

function hideEmptyForPrint(){
  const hidden = [];

  // Invoice table rows: hide if every text/number/date input is empty and no checkbox is checked
  document.querySelectorAll('#priceBody tr').forEach(tr => {
    const inputs = Array.from(tr.querySelectorAll('input'));
    const allEmpty = inputs.every(isEmptyInput);
    if(allEmpty){ tr.classList.add('print-hide'); hidden.push(tr); }
  });

  // grid2 fields (single-input fields like Company Name, System Reference Number, etc.)
  document.querySelectorAll('.grid2 .field').forEach(field => {
    const inputs = field.querySelectorAll('input, textarea');
    if(inputs.length && Array.from(inputs).every(isEmptyInput)){
      field.classList.add('print-hide'); hidden.push(field);
    }
  });

  // Signature columns: hide if name, signature, and date are all empty
  const sigContainer = document.querySelector('.signatures');
  document.querySelectorAll('.sig-col').forEach(col => {
    const inputs = col.querySelectorAll('input');
    if(inputs.length && Array.from(inputs).every(isEmptyInput)){
      col.classList.add('print-hide'); hidden.push(col);
    }
  });
  if(sigContainer){
    const visibleCount = sigContainer.querySelectorAll('.sig-col:not(.print-hide)').length;
    if(visibleCount > 0 && visibleCount < 3){
      sigContainer.dataset.prevGridCols = sigContainer.style.gridTemplateColumns || '';
      sigContainer.style.gridTemplateColumns = `repeat(${visibleCount}, 1fr)`;
      hidden.push(sigContainer);
    }
  }

  // Yes/No rows (Black List, Google Chat, System qa-rows): hide if neither option is selected
  document.querySelectorAll('.blacklist-row, .qa-row').forEach(row => {
    const radios = row.querySelectorAll('input[type=radio]');
    if(radios.length && Array.from(radios).every(r => !r.checked)){
      row.classList.add('print-hide'); hidden.push(row);
    }
  });

  // Notes box: hide if the textarea is empty
  document.querySelectorAll('.notes-box').forEach(box => {
    const ta = box.querySelector('textarea');
    if(ta && isEmptyInput(ta)){ box.classList.add('print-hide'); hidden.push(box); }
  });

  return hidden;
}

function restoreAfterPrint(){
  document.querySelectorAll('.print-hide').forEach(el => el.classList.remove('print-hide'));
  removePrintColumnOverrides();
  const sigContainer = document.querySelector('.signatures');
  if(sigContainer && sigContainer.dataset.prevGridCols !== undefined){
    sigContainer.style.gridTemplateColumns = sigContainer.dataset.prevGridCols;
    delete sigContainer.dataset.prevGridCols;
  }
}

function setFormTheme(status){
  const sheet = document.getElementById('form');
  if(sheet) sheet.dataset.status = status;
}

function printInv(){
  try{
    document.body.classList.remove('print-fit');
    document.body.style.zoom = '';
    hideEmptyForPrint();
  }catch(e){
    // never let a prep-step error block the actual print call
  }
  window.print();
}

window.addEventListener('afterprint', restoreAfterPrint);
