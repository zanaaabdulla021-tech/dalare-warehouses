/* ---------- Serialize / restore ---------- */
function getRadio(name){
  const checked = document.querySelector(`input[name="${name}"]:checked`);
  if(!checked) return null;
  return checked.classList.contains('no') ? 'no' : 'yes';
}

function setRadio(name, val){
  document.querySelectorAll(`input[name="${name}"]`).forEach(r => r.checked = false);
  if(val === 'yes' || val === 'no'){
    const sel = val === 'no'
      ? document.querySelector(`input[name="${name}"].no`)
      : document.querySelector(`input[name="${name}"]:not(.no)`);
    if(sel) sel.checked = true;
  }
}

function serializeForm(){
  const sigCols = Array.from(document.querySelectorAll('.sig-col')).map(col => {
    const ins = col.querySelectorAll('input');
    return { name: ins[0].value, sign: ins[1].value, date: ins[2].value };
  });

  const rows = Array.from(document.querySelectorAll('#priceBody tr')).map(tr => {
    const c = tr.querySelectorAll('input');
    const extra = {};
    tr.querySelectorAll('td[data-extra-cell] input').forEach(inp => { extra[inp.dataset.extra] = inp.value; });
    return {
      date: c[0].value, invoiceNo: c[1].value,
      price: c[2].value, bonus: c[3].value,
      cashback: c[4].value, discount: c[5].value,
      priceOk: c[8].checked, bonusOk: c[9].checked, qtyOk: c[10].checked,
      notes: c[11].value,
      paid: c[12] ? c[12].checked : false,
      extra
    };
  });

  let finalStatus = null;
  document.querySelectorAll('input[name="finalstatus"]').forEach((r,i)=>{
    if(r.checked) finalStatus = ['approved','rejected','pending'][i];
  });

  return {
    companyName: document.querySelector('.company-name-input').value,
    blacklist: getRadio('blacklist'),
    gc1: getRadio('gc1'),
    sy1: getRadio('sy1'),
    sy2: getRadio('sy2'),
    sy3: getRadio('sy3'),
    sy4: getRadio('sy4'),
    notes: document.querySelector('.notes-box textarea').value,
    signatures: sigCols,
    finalStatus: finalStatus,
    rows: rows
  };
}

function restoreForm(d){
  document.querySelector('.company-name-input').value = d.companyName || '';
  setRadio('blacklist', d.blacklist);
  setRadio('gc1', d.gc1);
  setRadio('sy1', d.sy1);
  setRadio('sy2', d.sy2);
  setRadio('sy3', d.sy3);
  setRadio('sy4', d.sy4);

  document.querySelector('.notes-box textarea').value = d.notes || '';

  document.querySelectorAll('.sig-col').forEach((col,i)=>{
    const ins = col.querySelectorAll('input');
    const s = (d.signatures && d.signatures[i]) || {};
    ins[0].value = s.name || '';
    ins[1].value = s.sign || '';
    ins[2].value = s.date || '';
  });

  const fsRadios = document.querySelectorAll('input[name="finalstatus"]');
  fsRadios.forEach(r => r.checked = false);
  const fsIdx = ['approved','rejected','pending'].indexOf(d.finalStatus);
  if(fsIdx >= 0){ fsRadios[fsIdx].checked = true; setFormTheme(d.finalStatus); }
  else { setFormTheme('approved'); }

  document.getElementById('priceBody').innerHTML = '';
  rowCount = 0;
  const rows = d.rows && d.rows.length ? d.rows : [];
  const total = Math.max(rows.length, 10);
  for(let i=0;i<total;i++) addRow();

  Array.from(document.querySelectorAll('#priceBody tr')).forEach((tr,i)=>{
    const r = rows[i];
    if(!r) return;
    const c = tr.querySelectorAll('input');
    c[0].value = r.date || ''; c[1].value = r.invoiceNo || '';
    c[2].value = r.price || ''; c[3].value = r.bonus || '';
    c[4].value = r.cashback || ''; c[5].value = r.discount || '';
    c[8].checked = !!r.priceOk; c[9].checked = !!r.bonusOk; c[10].checked = !!r.qtyOk;
    c[11].value = r.notes || '';
    if(c[12]) c[12].checked = !!r.paid;
    if(r.extra){
      tr.querySelectorAll('td[data-extra-cell] input').forEach(inp => {
        inp.value = r.extra[inp.dataset.extra] || '';
      });
    }
    if(c[2].value) calcRow(c[2]);
  });
  calcGrandTotal();
  applyViewerLock();
}

/* ---------- Backend operations ---------- */
function findDuplicateInvoiceNumbers(data){
  const seen = {};
  const dupes = new Set();
  (data.rows || []).forEach(r => {
    const no = (r.invoiceNo || '').trim();
    if(!no) return;
    if(seen[no]) dupes.add(no);
    seen[no] = true;
  });
  return [...dupes];
}

async function checkSameCompanyToday(table, companyName, excludeId){
  if(!companyName || !backendReady()) return [];
  try{
    const todayStart = new Date(); todayStart.setHours(0,0,0,0);
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/${table}?select=id,updated_at&company_name=eq.${encodeURIComponent(companyName)}&id=neq.${encodeURIComponent(excludeId)}&updated_at=gte.${todayStart.toISOString()}&deleted_at=is.null`,
      { headers: sbHeaders() }
    );
    if(!res.ok) return [];
    return await res.json();
  }catch(e){ return []; }
}

async function saveInv(){
  if(!backendReady()){
    flash('Backend not configured — see CONFIG at top of file.', true);
    return;
  }
  if(!currentFormId) setFormId(makeFormId());

  const newData = serializeForm();
  const oldData = await fetchExistingFormData('forms', currentFormId);
  const companyName = document.querySelector('.company-name-input').value || '(unnamed)';

  const negFieldChecks = [];
  (newData.rows || []).forEach((r, i) => {
    negFieldChecks.push({ value: r.price, label: `Row ${i+1} Price` });
    negFieldChecks.push({ value: r.bonus, label: `Row ${i+1} Bonus` });
    negFieldChecks.push({ value: r.cashback, label: `Row ${i+1} Cash Back` });
    negFieldChecks.push({ value: r.discount, label: `Row ${i+1} Discount` });
  });
  const negField = validateNonNegative(negFieldChecks);
  if(negField){ flash(`${negField} can't be negative. Please fix it before saving.`, true); return; }

  const dupeInvoiceNos = findDuplicateInvoiceNumbers(newData);
  if(dupeInvoiceNos.length){
    const proceed = confirm(`This form has repeated Invoice Number(s): ${dupeInvoiceNos.join(', ')}. Save anyway?`);
    if(!proceed) return;
  }
  const sameCompanyToday = await checkSameCompanyToday('forms', companyName, currentFormId);
  if(sameCompanyToday.length){
    const proceed = confirm(`${sameCompanyToday.length} other invoice form(s) for "${companyName}" were already saved today. This might be a duplicate — save anyway?`);
    if(!proceed) return;
  }

  const payload = {
    id: currentFormId,
    company_name: companyName,
    stage: currentStage,
    data: newData,
    updated_at: new Date().toISOString(),
    updated_by: session.email || null
  };

  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/forms`, {
      method: 'POST',
      headers: sbHeaders({ 'Prefer': 'resolution=merge-duplicates' }),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save', currentFormId, describeFormDiff(oldData, newData));
    flash('Saved ✓ ' + currentFormId);
    loadCompanyNamesList();
  }catch(e){
    console.error(e);
    flash(sbError(e), true);
  }
}

const FIELD_LABELS = {
  invoiceNo:'Invoice #', price:'Price', bonus:'Bonus', cashback:'Cash Back', discount:'Discount',
  priceOk:'Price Verified', bonusOk:'Bonus Verified', qtyOk:'Qty Verified', notes:'Notes', paid:'Paid', date:'Date',
  product:'Product', sectionNo:'Batch/Lot', itemsPerPkg:'Items/Pkg', cashflow:'Cash Flow', stock:'Stock', note:'Note',
  companyName:'Company', employee:'Employee', target:'Target', actual:'Actual', accuracy:'Accuracy',
};
function fieldLabel(k){ return FIELD_LABELS[k] || k; }

function describeFormDiff(oldData, newData){
  if(!oldData) return null; // brand new form — nothing to diff against
  const changes = [];

  // Top-level scalar fields (skip 'rows' — handled separately).
  Object.keys(newData || {}).forEach(k => {
    if(k === 'rows') return;
    const ov = oldData[k], nv = newData[k];
    if(typeof nv === 'object') return;
    if((ov ?? '') !== (nv ?? '')) changes.push(`${fieldLabel(k)}: "${ov ?? ''}" → "${nv ?? ''}"`);
  });

  // Row-level diffs, matched by index.
  const oldRows = oldData.rows || [];
  const newRows = newData.rows || [];
  const maxLen = Math.max(oldRows.length, newRows.length);
  for(let i = 0; i < maxLen; i++){
    const or = oldRows[i], nr = newRows[i];
    if(or && !nr){ changes.push(`Row ${i+1} removed`); continue; }
    if(!or && nr){ changes.push(`Row ${i+1} added`); continue; }
    Object.keys(nr || {}).forEach(k => {
      if(k === 'extra') return;
      const ov = or[k], nv = nr[k];
      if(typeof nv === 'object') return;
      const ovN = ov === true ? 'Yes' : ov === false ? 'No' : (ov ?? '');
      const nvN = nv === true ? 'Yes' : nv === false ? 'No' : (nv ?? '');
      if(String(ovN) !== String(nvN)) changes.push(`Row ${i+1} ${fieldLabel(k)}: "${ovN}" → "${nvN}"`);
    });
  }

  if(!changes.length) return null;
  const shown = changes.slice(0, 5).join('; ');
  return changes.length > 5 ? `${shown}; +${changes.length - 5} more change(s)` : shown;
}

async function fetchExistingFormData(table, id){
  if(!id) return null;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}&select=data`, { headers: sbHeaders() });
    if(!res.ok) return null;
    const rows = await res.json();
    return rows.length ? rows[0].data : null;
  }catch(e){ return null; }
}

async function loadFormsList(){
  const list = document.getElementById('mgrList');
  if(!backendReady()){
    list.innerHTML = '<div class="mgr-empty">Backend not configured. Open this file and fill in SUPABASE_URL and SUPABASE_ANON_KEY at the top of the &lt;script&gt; block.</div>';
    return;
  }
  list.innerHTML = '<div class="mgr-empty">Loading…</div>';
  try{
    const extraFilter = (activeTab && activeTab.startsWith('custom:'))
      ? `&section_id=eq.${encodeURIComponent(activeTab.slice(7))}` : '';
    const selectFields = activeTab === 'kpi' ? 'id,company_name,stage,updated_at,data' : 'id,company_name,stage,updated_at';
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/${activeTable()}?select=${selectFields}&deleted_at=is.null${extraFilter}&order=updated_at.desc`,
      { headers: sbHeaders() }
    );
    if(!res.ok) throw new Error(await res.text());
    window._forms = await res.json();

    const deptFilterSel = document.getElementById('mgrDeptFilter');
    if(activeTab === 'kpi'){
      const depts = [...new Set(window._forms.map(f => f.data && f.data.department).filter(Boolean))].sort();
      deptFilterSel.innerHTML = '<option value="">All departments</option>' + depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">${d.replace(/</g,'&lt;')}</option>`).join('');
      deptFilterSel.style.display = '';
    }else{
      deptFilterSel.style.display = 'none';
      deptFilterSel.value = '';
    }

    renderManagerList();
  }catch(e){
    console.error(e);
    list.innerHTML = '<div class="mgr-empty">' + sbError(e) + '</div>';
  }
}

function renderManagerList(){
  const list = document.getElementById('mgrList');
  const q = (document.getElementById('mgrSearch').value || '').toLowerCase().trim();
  let forms = window._forms || [];
  if(activeTab === 'kpi'){
    const deptFilter = document.getElementById('mgrDeptFilter').value;
    if(deptFilter) forms = forms.filter(f => f.data && f.data.department === deptFilter);
  }
  if(q){
    forms = forms.filter(f =>
      (f.id||'').toLowerCase().includes(q) ||
      (f.company_name||'').toLowerCase().includes(q)
    );
  }
  if(!forms.length){
    list.innerHTML = '<div class="mgr-empty">No forms found.</div>';
    return;
  }
  list.innerHTML = forms.map(f => {
    const st = STAGES[f.stage] || STAGES.entry;
    const when = f.updated_at ? new Date(f.updated_at).toLocaleString('en-US') : '';
    return `<div class="mgr-item">
      <div class="who">
        <span class="fid">${f.id}</span>
        <span class="cname">${(f.company_name||'').replace(/</g,'&lt;')}</span>
        <span class="meta">Updated ${when}</span>
      </div>
      <span class="stage-badge ${st.cls}">${st.label}</span>
      <div class="mgr-actions">
        <button class="mgr-btn open-b" onclick="openForm('${f.id}')">Open</button>
        ${isSuperAdmin() ? `<button class="mgr-btn del-b" onclick="deleteFormActive('${f.id}')">Delete</button>` : ''}
      </div>
    </div>`;
  }).join('');
}

async function openInv(id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/forms?id=eq.${encodeURIComponent(id)}&select=*`,
      { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Form not found.', true); return; }
    const f = rows[0];
    setFormId(f.id);
    setStage(f.stage || 'entry');
    restoreForm(f.data || {});
    closeManager();
    flash('Opened ' + f.id);
  }catch(e){
    console.error(e);
    flash(sbError(e), true);
  }
}

async function deleteForm(id){
  if(!confirm(`Permanently delete form ${id}? This cannot be undone.`)) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/forms?id=eq.${encodeURIComponent(id)}`,
      { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    if(currentFormId === id) newInv();
    logActivity('delete', id);
    flash('Deleted ' + id);
    loadFormsList();
  }catch(e){
    console.error(e);
    flash(sbError(e), true);
  }
}

async function purgeOldForms(){
  if(!backendReady()) return;
  const cutoff = new Date(Date.now() - RETENTION_DAYS*24*60*60*1000).toISOString();
  try{
    await fetch(`${SUPABASE_URL}/rest/v1/forms?updated_at=lt.${cutoff}`,
      { method:'DELETE', headers: sbHeaders() });
    await fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms?updated_at=lt.${cutoff}`,
      { method:'DELETE', headers: sbHeaders() });
    await fetch(`${SUPABASE_URL}/rest/v1/sop_forms?updated_at=lt.${cutoff}`,
      { method:'DELETE', headers: sbHeaders() });
  }catch(e){ /* non-critical */ }
}

function newInv(){
  setFormId(makeFormId());
  setStage('entry');
  restoreForm({});
  flash('New form started');
}

function openManager(){
  document.querySelector('.mgr-head h2').textContent =
    (activeTab && activeTab.startsWith('custom:')) ? 'Saved ' + (customSections[activeTab.slice(7)]?.name || 'Section') + ' Forms'
    : activeTab === 'cf' ? 'Saved Cash Flow Forms'
    : activeTab === 'sop' ? 'Saved SOP Documents'
    : activeTab === 'kpi' ? 'Saved KPI Evaluations'
    : 'Saved Invoice Forms';
  const excelBtn = document.getElementById('mgrExcelExportBtn');
  if(excelBtn) excelBtn.style.display = (activeTab === 'inv' || activeTab === 'cf') ? '' : 'none';
  document.getElementById('mgrOverlay').classList.add('open');
  loadFormsList();
}
function closeManager(){
  document.getElementById('mgrOverlay').classList.remove('open');
}


function addRow(){
  rowCount++;
  const tbody = document.getElementById('priceBody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="row-num">${rowCount}</td>
    <td><input type="text" placeholder="dd/mm/yyyy"></td>
    <td><input type="text"></td>
    <td><input type="text" inputmode="decimal" class="price-input" oninput="calcRow(this)" onblur="formatMoneyField(this)"></td>
    <td><input type="text" inputmode="decimal" class="bonus-input" oninput="calcRow(this)" onblur="formatMoneyField(this)"></td>
    <td><input type="number" class="cashback-input" min="0" max="100" step="0.1" oninput="clampPercent(this);calcRow(this)"></td>
    <td><input type="number" class="discount-input" min="0" max="100" step="0.1" oninput="clampPercent(this);calcRow(this)"></td>
    <td><input type="text" class="before-discount-input" readonly></td>
    <td><input type="text" class="total-input" readonly></td>
    <td><input type="checkbox" class="checkbox"></td>
    <td><input type="checkbox" class="checkbox"></td>
    <td><input type="checkbox" class="checkbox"></td>
    <td><input type="text"></td>
    <td><input type="checkbox" class="checkbox paid-checkbox" onchange="calcGrandTotal()"></td>
    ${extraColCells('inv')}
    <td><button class="btn-small remove" onclick="removeRow(this)">×</button></td>
  `;
  tbody.appendChild(tr);
}

function removeRow(btn){
  const tr = btn.closest('tr');
  tr.remove();
  renumberRows();
  calcGrandTotal();
}

function renumberRows(){
  const rows = document.querySelectorAll('#priceBody tr');
  rows.forEach((r,i)=>{ r.querySelector('.row-num').textContent = i+1; });
  rowCount = rows.length;
}

function parseMoney(str){
  return parseFloat(String(str).replace(/,/g,'')) || 0;
}

function formatMoney(num){
  return num.toLocaleString('en-US', {minimumFractionDigits:0, maximumFractionDigits:2});
}

function formatMoneyField(input){
  if(input.value.trim() === '') return;
  input.value = formatMoney(parseMoney(input.value));
}

function clampPercent(input){
  let v = parseFloat(input.value);
  if(isNaN(v)) return;
  if(v > 100) input.value = 100;
  if(v < 0) input.value = 0;
}

function calcRow(input){
  const tr = input.closest('tr');
  const price = parseMoney(tr.querySelector('.price-input').value);
  const bonus = parseMoney(tr.querySelector('.bonus-input').value);
  const cashbackPct = parseFloat(tr.querySelector('.cashback-input').value) || 0;
  const cashbackAmount = price * (cashbackPct / 100);
  const discountPct = parseFloat(tr.querySelector('.discount-input').value) || 0;

  const beforeDiscount = price - bonus - cashbackAmount;
  const discountAmount = beforeDiscount * (discountPct / 100);
  const afterDiscount = beforeDiscount - discountAmount;

  tr.querySelector('.before-discount-input').value = formatMoney(beforeDiscount);
  tr.querySelector('.total-input').value = formatMoney(afterDiscount);
  calcGrandTotal();
}

function calcGrandTotal(){
  let sum = 0, remaining = 0;
  document.querySelectorAll('#priceBody tr').forEach(tr => {
    const totalInput = tr.querySelector('.total-input');
    const val = parseMoney(totalInput ? totalInput.value : '0');
    sum += val;
    const paidBox = tr.querySelector('.paid-checkbox');
    if(paidBox && !paidBox.checked) remaining += val;
  });
  document.getElementById('grandTotal').textContent = formatMoney(sum) + ' IQD';
  const debtEl = document.getElementById('remainingDebt');
  if(debtEl) debtEl.textContent = formatMoney(remaining) + ' IQD';
}

function resetInv(){
  if(confirm('Are you sure you want to clear all data?')){
    document.querySelectorAll('input[type=text], input[type=email], input[type=tel], input[type=number], input[type=date], textarea').forEach(el=>el.value='');
    document.querySelectorAll('input[type=checkbox], input[type=radio]').forEach(el=>el.checked=false);
    document.getElementById('priceBody').innerHTML='';
    rowCount=0;
    calcGrandTotal();
    for(let i=0;i<15;i++) addRow();
    setFormTheme('approved');
  }
}


/* ---- Shared toolbar buttons dispatch to the active tab ---- */
function saveForm(){
  if(activeTab && activeTab.startsWith('custom:')) return saveCustomSectionForm(activeTab.slice(7));
  if(activeTab === 'cf')  return saveCF();
  if(activeTab === 'sop') return saveSOP();
  if(activeTab === 'kpi') return saveKPI();
  return saveInv();
}
function newForm(){
  if(activeTab && activeTab.startsWith('custom:')) return newCustomSectionForm(activeTab.slice(7));
  if(activeTab === 'cf')  return newFormCF();
  if(activeTab === 'sop') return newFormSOP();
  if(activeTab === 'kpi') return newFormKPI();
  return newInv();
}
function openForm(id){
  if(activeTab && activeTab.startsWith('custom:')) return openCustomSectionForm(activeTab.slice(7), id);
  if(activeTab === 'cf')  return openCF(id);
  if(activeTab === 'sop') return openSOP(id);
  if(activeTab === 'kpi') return openKPI(id);
  return openInv(id);
}

function resetForm(){
  if(activeTab && activeTab.startsWith('custom:')){
    if(confirm('Are you sure you want to clear all data?')) restoreCustomSection(activeTab.slice(7), {});
    return;
  }
  if(activeTab === 'cf'){
    if(confirm('Are you sure you want to clear all data?')) restoreCF({});
    return;
  }
  if(activeTab === 'sop'){
    if(confirm('Are you sure you want to clear all data?')) restoreSOP({});
    return;
  }
  if(activeTab === 'kpi'){
    if(confirm('Are you sure you want to clear all data?')) restoreKpi({});
    return;
  }
  return resetInv();
}

function setPrintOrientation(orientation){
  const style = document.getElementById('pageOrientStyle');
  if(style) style.textContent = `@page{ size:A4 ${orientation}; margin:6mm; }`;
  try{ localStorage.setItem('dalare-print-orientation', orientation); }catch(e){ /* fine, just won't persist */ }
  const select = document.getElementById('printOrientSelect');
  if(select) select.value = orientation;
}

function printForm(){
  applyPrintColumnOverrides();
  // only the active tab's sheet is visible, so print output is already correct
  return printInv();
}

async function deleteFormActive(id){
  if(!isSuperAdmin()){ flash('Only a super admin can delete forms.', true); return; }
  if(!confirm(`Move form ${id} to Trash? You can restore it later from Admin → Trash.`)) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${activeTable()}?id=eq.${encodeURIComponent(id)}`,
      { method:'PATCH', headers: sbHeaders(), body: JSON.stringify({ deleted_at: new Date().toISOString() }) });
    if(!res.ok) throw new Error(await res.text());
    if(activeTab === 'cf'){ if(cfFormId === id) newFormCF(); }
    else if(activeTab === 'sop'){ if(sopFormId === id) newFormSOP(); }
    else if(activeTab === 'kpi'){ if(kpiFormId === id) newFormKPI(); }
    else if(activeTab && activeTab.startsWith('custom:')){ /* custom section forms don't track a "current id" the same way */ }
    else { if(currentFormId === id) newInv(); }
    flash('Moved to Trash: ' + id);
    loadFormsList();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
