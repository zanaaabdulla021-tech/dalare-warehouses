/* =======================  AUTH  ======================= */
const SESSION_KEY = 'dalare_session';

function showApp(show){
  document.getElementById('authOverlay').classList.toggle('hidden', show);
  document.getElementById('userBar').style.display = show ? 'flex' : 'none';
  document.querySelector('.tabbar').style.display = show ? 'flex' : 'none';
  document.querySelector('.toolbar').style.display = show ? 'flex' : 'none';
  ['form','cfForm','sopForm'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.style.visibility = show ? 'visible' : 'hidden';
  });
}

async function doLogin(){
  try{
    const emailEl = document.getElementById('authEmail');
    const passEl  = document.getElementById('authPass');
    const btn     = document.getElementById('authBtn');
    const err     = document.getElementById('authErr');
    if(!emailEl || !passEl || !btn || !err){
      alert('Login form failed to load correctly. Please refresh the page and try again.');
      return;
    }
    const email = emailEl.value.trim();
    const pass  = passEl.value;
    err.textContent = '';
    if(!email || !pass){ err.textContent = 'Enter your email and password.'; return; }
    if(!backendReady()){ err.textContent = 'Backend not configured.'; return; }

    btn.disabled = true; btn.textContent = 'Signing in…';
    try{
      const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
        method:'POST',
        headers:{ 'apikey': SUPABASE_ANON_KEY, 'Content-Type':'application/json' },
        body: JSON.stringify({ email, password: pass })
      });
      const body = await res.json();
      if(!res.ok) throw new Error(body.error_description || body.msg || body.message || 'Sign in failed');

      session.token  = body.access_token;
      session.email  = body.user && body.user.email;
      session.userId = body.user && body.user.id;
      await loadRole();

      if(session.role === 'super_admin'){
        const requiredPin = await fetchSuperAdminPin();
        if(requiredPin){
          document.getElementById('authPin').value = '';
          document.getElementById('pinErr').textContent = '';
          document.querySelector('.auth-card:not(#pinCard)').style.display = 'none';
          document.getElementById('pinCard').style.display = '';
          document.getElementById('authPin').focus();
          return; // Wait for submitSuperAdminPin() to finish the login.
        }
      }
      localStorage.setItem(SESSION_KEY, JSON.stringify(session));
      applySession();
    }catch(e){
      err.textContent = String(e.message || e);
    }finally{
      btn.disabled = false; btn.textContent = 'Sign in';
    }
  }catch(outerErr){
    // Something failed before we even reached the normal flow (e.g. a missing
    // element). Surface it instead of the button silently doing nothing.
    console.error('doLogin failed unexpectedly:', outerErr);
    alert('Something went wrong signing in: ' + (outerErr.message || outerErr));
  }
}

async function fetchSuperAdminPin(){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings?id=eq.default&select=super_admin_pin`, { headers: sbHeaders() });
    if(!res.ok) return null;
    const rows = await res.json();
    return rows.length ? (rows[0].super_admin_pin || null) : null;
  }catch(e){ return null; }
}

async function submitSuperAdminPin(){
  const pin = document.getElementById('authPin').value.trim();
  const errEl = document.getElementById('pinErr');
  if(!pin){ errEl.textContent = 'Enter your PIN.'; return; }
  const requiredPin = await fetchSuperAdminPin();
  if(pin !== requiredPin){ errEl.textContent = 'Incorrect PIN.'; return; }
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  applySession();
}

function cancelPinStep(){
  session = { token:null, email:null, role:'staff', userId:null };
  document.getElementById('pinCard').style.display = 'none';
  document.querySelector('.auth-card:not(#pinCard)').style.display = '';
  document.getElementById('authPass').value = '';
}

function openPinSetup(){
  if(!isSuperAdmin()){ flash('Only a super admin can manage the security PIN.', true); return; }
  document.getElementById('newPinInput').value = '';
  document.getElementById('pinSetupOverlay').classList.add('open');
}
function closePinSetup(){ document.getElementById('pinSetupOverlay').classList.remove('open'); }

async function saveSuperAdminPin(){
  const pin = document.getElementById('newPinInput').value.trim();
  if(pin && (pin.length < 4 || pin.length > 12 || !/^\d+$/.test(pin))){
    flash('PIN must be 4–12 digits, or leave it blank to turn this off.', true);
    return;
  }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', super_admin_pin: pin || null, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    flash(pin ? 'Security PIN saved ✓' : 'Security PIN turned off');
    closePinSetup();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadRole(){
  session.role = 'staff';
  try{
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?id=eq.${session.userId}&select=role`,
      { headers: sbHeaders() });
    if(res.ok){
      const rows = await res.json();
      if(rows.length && rows[0].role) session.role = rows[0].role;
    }
  }catch(e){ /* default to staff */ }
}

function applySession(){
  document.getElementById('userEmail').textContent = session.email || '';
  document.getElementById('userRole').textContent = session.role;
  document.getElementById('adminBtn').style.display = isAdmin() ? 'inline-block' : 'none';

  refreshTabVisibility();
  document.querySelectorAll('.custom-tab-btn').forEach(btn=>{
    const sid = btn.id.replace('tab_custom_','');
    btn.style.display = canViewTab('custom:'+sid) ? '' : 'none';
  });

  document.getElementById('employeeScreen').style.display = isEmployee() ? 'flex' : 'none';
  applyLanguage();
  if(isEmployee()) loadEmployeeSelfService();
  if(document.getElementById('stageActionBar')) renderStageActions('forms', currentFormId, 'inv');
  if(document.getElementById('cfStageActionBar')) renderStageActions('cashflow_forms', cfFormId, 'cf');
  loadNotifications();

  if(!isEmployee() && !canViewTab(activeTab)){
    const firstOk = ['home','inv','cf','sop','staff'].find(canViewTab);
    if(firstOk) switchTab(firstOk);
  }
  document.getElementById('authPass').value = '';
  showApp(true);
  if(isEmployee()){
    document.querySelector('.tabbar').style.display = 'none';
    document.querySelector('.toolbar').style.display = 'none';
    ['homeScreen','form','cfForm','sopForm','staffForm'].forEach(id=>{
      const el = document.getElementById(id);
      if(el) el.style.display = 'none';
    });
  }
  purgeOldForms();
  applyViewerLock();
  loadCustomSections();
  loadCardLayout();
  renderHomeGrid();
  loadPrintColumns();
  updatePdfColsButton();
  loadExtraColumns();
  updateColumnMgrButton();
  loadTabOrder();
  updateReorderTabsButton();
  loadSiteSettings();
  loadRolePermissions();
  loadCurrentUserDepartment();
  loadCompanyNamesList();
  loadEmployeeNamesList();
  loadCfSectionList();
  loadStaffDeptListOnly();
  document.body.classList.toggle('super-admin-mode', isSuperAdmin());
  document.querySelector('.toolbar').style.display = (activeTab === 'home' || isEmployee()) ? 'none' : 'flex';
}

function doLogout(){
  session = { token:null, email:null, role:'staff', userId:null };
  localStorage.removeItem(SESSION_KEY);
  showApp(false);
}

/* ---------- Role model ----------
   super_admin — edits every section, full Admin panel (Users, Log, Tools), Staff directory
   admin       — view-only on Invoice/CashFlow/SOP, can manage Users only (no Log/Tools/Staff)
   staff       — edit access to Invoice + Cash Flow only (no SOP, no Staff)
   viewer      — view-only on Invoice/CashFlow/SOP (legacy read-only role)
   employee    — no sections yet (KPI Employee tab is planned separately)
------------------------------------------------------------------------- */
function isSuperAdmin(){ return session.role === 'super_admin'; }
function isAdmin(){ return session.role === 'admin' || session.role === 'super_admin'; }
function isViewer(){ return session.role === 'viewer'; }
function isEmployee(){ return session.role === 'employee'; }

async function loadEmployeeSelfService(){
  const box = document.getElementById('employeeSelfServiceContent');
  if(!box) return;
  if(!backendReady()){ box.innerHTML = '<div style="text-align:center;color:#888;padding:20px;">Backend not configured.</div>'; return; }
  try{
    const empRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(session.email)}&select=full_name,department,job_title,photo`, { headers: sbHeaders() });
    const empRows = empRes.ok ? await empRes.json() : [];
    if(!empRows.length){
      box.innerHTML = `<div style="text-align:center;color:#888;padding:20px;">
        <div class="employee-icon">⏳</div>
        <h2>Your account isn't linked yet</h2>
        <p>Ask your manager to add your login email to your profile in Staff Directory.</p>
      </div>`;
      return;
    }
    const me = empRows[0];
    const name = me.full_name;

    const [kpiRes, attRes, leaveRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?company_name=eq.${encodeURIComponent(name)}&select=data,updated_at&deleted_at=is.null&order=updated_at.desc&limit=1`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/attendance?employee_name=eq.${encodeURIComponent(name)}&select=*&order=date.desc&limit=10`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/leave_requests?employee_name=eq.${encodeURIComponent(name)}&select=*&order=requested_at.desc&limit=10`, { headers: sbHeaders() })
    ]);
    const kpiRows = kpiRes.ok ? await kpiRes.json() : [];
    const attRows = attRes.ok ? await attRes.json() : [];
    const leaveRows = leaveRes.ok ? await leaveRes.json() : [];

    const latestKpi = kpiRows.length ? kpiRows[0] : null;
    const kpiScore = latestKpi ? computeKpiScoreFromData(latestKpi.data || {}) : null;

    box.innerHTML = `
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px;">
        ${me.photo ? `<img src="${me.photo}" style="width:56px;height:56px;border-radius:50%;object-fit:cover;">` : `<div style="width:56px;height:56px;border-radius:50%;background:var(--forest);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.3rem;">${(name||'?').charAt(0).toUpperCase()}</div>`}
        <div>
          <div style="font-weight:800;font-size:1.15rem;color:var(--forest-deep);">${(name||'').replace(/</g,'&lt;')}</div>
          <div style="color:#666;font-size:.85rem;">${(me.job_title||'').replace(/</g,'&lt;')}${me.department ? ' · ' + me.department.replace(/</g,'&lt;') : ''}</div>
        </div>
      </div>

      <div class="section-header"><div class="num">★</div><div class="title">My Latest KPI Score</div></div>
      ${latestKpi ? `
        <div class="kpi-summary-grid" style="margin:10px 14px;">
          <div class="kpi-stat"><small>Total Score</small><strong>${kpiScore.toFixed(1)}%</strong></div>
          <div class="kpi-stat"><small>Month</small><strong>${latestKpi.data.month || '—'}</strong></div>
          <div class="kpi-stat"><small>Last Updated</small><strong>${new Date(latestKpi.updated_at).toLocaleDateString('en-US')}</strong></div>
        </div>` : `<div style="text-align:center;color:#888;padding:14px;">No KPI evaluations yet.</div>`}

      <div class="section-header" style="margin-top:18px;"><div class="num">🕐</div><div class="title">My Recent Attendance</div></div>
      <div class="price-table-wrap" style="margin:10px 14px;">
        <table class="pricelist">
          <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Status</th></tr></thead>
          <tbody>${attRows.length ? attRows.map(r => `<tr>
            <td>${r.date}</td>
            <td>${r.check_in ? new Date(r.check_in).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}) : '—'}</td>
            <td>${r.check_out ? new Date(r.check_out).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}) : '—'}</td>
            <td>${(r.status||'').replace('_',' ')}</td>
          </tr>`).join('') : '<tr><td colspan="4" style="text-align:center;color:#888;">No attendance records yet.</td></tr>'}</tbody>
        </table>
      </div>

      <div class="section-header" style="margin-top:18px;"><div class="num">📨</div><div class="title">My Leave Requests</div></div>
      <div class="table-actions no-print" style="margin:10px 14px;">
        <button class="btn-small" onclick="openLeaveRequestForm(); document.getElementById('leaveEmployee').value='${name.replace(/'/g,"\\'")}';">+ Request Leave</button>
      </div>
      <div class="price-table-wrap" style="margin:10px 14px;">
        <table class="pricelist">
          <thead><tr><th>Type</th><th>From</th><th>To</th><th>Status</th><th>Pay</th></tr></thead>
          <tbody>${leaveRows.length ? leaveRows.map(r => `<tr>
            <td>${r.leave_type||''}</td><td>${r.start_date||''}</td><td>${r.end_date||''}</td>
            <td>${r.status||''}</td><td>${r.status!=='approved' ? '—' : (r.paid_status==='paid'?'Paid':'Unpaid')}</td>
          </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;color:#888;">No leave requests yet.</td></tr>'}</tbody>
        </table>
      </div>`;
  }catch(e){ console.error(e); box.innerHTML = `<div style="text-align:center;color:#888;padding:20px;">${sbError(e)}</div>`; }
}

const MANAGEABLE_TABS = ['inv','cf','sop','staff','kpi','att','hr'];
// ===================== Phase 3: Roles & Permissions =====================
// Permission types tracked per module. "reject" mirrors "approve" in the
// UI (whoever can approve a request can also reject it) but is tracked
// separately in case a future workflow needs to split them.
const PERMISSION_TYPES = ['view','create','edit','delete','approve','reject','export','print'];
const ALL_ROLES = ['super_admin','admin','manager','reviewer','accountant','warehouse_staff','staff','viewer','employee'];
const ROLE_LABELS = {
  super_admin:'Super Admin', admin:'Admin', manager:'Manager', reviewer:'Reviewer',
  accountant:'Accountant', warehouse_staff:'Warehouse Staff', staff:'Staff', viewer:'Viewer', employee:'Employee'
};

function emptyPerms(){ return { view:false, create:false, edit:false, delete:false, approve:false, reject:false, export:false, print:false }; }
function viewOnlyPerms(){ return { ...emptyPerms(), view:true, print:true }; }
function editPerms(){ return { ...emptyPerms(), view:true, create:true, edit:true, export:true, print:true }; }
function approverPerms(){ return { ...emptyPerms(), view:true, approve:true, reject:true, export:true, print:true }; }
function editApprovePerms(){ return { ...emptyPerms(), view:true, create:true, edit:true, approve:true, reject:true, export:true, print:true }; }

// Sensible starting point for each role, per module (MANAGEABLE_TABS ids).
// Super admin bypasses this entirely (see hasPermission below).
function defaultPermissionMatrix(){
  const modules = ['inv','cf','sop','staff','kpi','att','hr'];
  const m = {};
  ALL_ROLES.forEach(role => { m[role] = {}; });
  modules.forEach(mod => {
    m.admin[mod]           = editPerms();
    m.manager[mod]         = approverPerms();
    m.reviewer[mod]        = viewOnlyPerms();
    m.accountant[mod]      = (mod === 'inv' || mod === 'cf') ? editApprovePerms() : viewOnlyPerms();
    m.warehouse_staff[mod] = (mod === 'att') ? editPerms() : (mod === 'kpi' ? viewOnlyPerms() : emptyPerms());
    m.staff[mod]           = (mod === 'kpi') ? editPerms() : (mod === 'att' ? viewOnlyPerms() : emptyPerms());
    m.viewer[mod]          = viewOnlyPerms();
    m.employee[mod]        = emptyPerms();
  });
  return m;
}

let permissionMatrix = defaultPermissionMatrix();

// Converts the old { role: { view:[tabIds], edit:[tabIds] } } shape (still
// possibly stored in the database from before Phase 3) into the new
// per-module permission-type matrix, so nothing that worked before breaks.
function migrateOldPermissionFormat(oldMatrix){
  const modules = ['inv','cf','sop','staff','kpi','att','hr'];
  const migrated = defaultPermissionMatrix();
  Object.keys(oldMatrix || {}).forEach(role => {
    if(!migrated[role]) migrated[role] = {};
    const old = oldMatrix[role];
    if(!old || !Array.isArray(old.view)) return;
    modules.forEach(mod => {
      const canView = old.view.includes(mod);
      const canEdit = old.edit && old.edit.includes(mod);
      if(canView || canEdit){
        migrated[role][mod] = canEdit ? editPerms() : viewOnlyPerms();
      }
    });
  });
  return migrated;
}

function hasPermission(tab, permType){
  if(isSuperAdmin()) return true;
  if(tab === 'home') return permType === 'view';
  if(tab && tab.startsWith('custom:')) return permType === 'view' ? ['admin','staff','viewer'].includes(session.role) : (permType === 'edit' && ['admin','staff'].includes(session.role));
  const rolePerm = permissionMatrix[session.role];
  if(!rolePerm || !rolePerm[tab]) return false;
  return !!rolePerm[tab][permType];
}

let currentUserDepartment = null;
async function loadCurrentUserDepartment(){
  currentUserDepartment = null;
  if(!backendReady() || isSuperAdmin() || session.role === 'admin'){
    if(document.getElementById('kpiGroupsWrap')) renderKpiRows(); // admins see every department
    return;
  }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(session.email)}&select=department`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(rows.length && rows[0].department) currentUserDepartment = rows[0].department;
  }catch(e){ /* leave unrestricted-null; renderKpiRows treats null as "show nothing" for non-admins */ }
  if(document.getElementById('kpiGroupsWrap')) renderKpiRows();
}

function canViewTab(tab){
  if(tab === 'home') return true;
  return hasPermission(tab, 'view');
}

function canEditTab(tab){
  return hasPermission(tab, 'edit');
}

function canCreateTab(tab){ return hasPermission(tab, 'create'); }
function canDeleteTab(tab){ return hasPermission(tab, 'delete'); }
function canApproveTab(tab){ return hasPermission(tab, 'approve'); }
function canRejectTab(tab){ return hasPermission(tab, 'reject'); }
function canExportTab(tab){ return hasPermission(tab, 'export'); }
function canPrintTab(tab){ return hasPermission(tab, 'print'); }

function applyViewerLock(){
  const editable = canEditTab(activeTab);
  const locked = !editable;
  document.body.classList.toggle('viewer-mode', locked);

  // disable every fillable field on the currently active form only
  const scope = activeTab === 'inv' ? '#form' : activeTab === 'cf' ? '#cfForm' : activeTab === 'sop' ? '#sopForm'
    : (activeTab && activeTab.startsWith('custom:')) ? '#customForm_' + activeTab.slice(7) : null;
  if(scope){
    document.querySelectorAll(`${scope} input, ${scope} textarea, ${scope} select`)
      .forEach(el => { el.disabled = locked; });
  }

  // hide row/step-adding buttons; keep Print working
  document.querySelectorAll('.btn-small, .sop-del, .table-actions')
    .forEach(el => { el.style.display = locked ? 'none' : ''; });

  document.querySelectorAll('.toolbar button').forEach(btn=>{
    const key = btn.dataset.labelKey;
    if(key === 'toolbar.save' || key === 'toolbar.cleardata' || key === 'toolbar.newform'){
      btn.disabled = locked;
      btn.style.opacity = locked ? .5 : '';
      btn.style.cursor = locked ? 'not-allowed' : '';
    }
  });

  const badge = document.getElementById('viewerBadge');
  if(badge) badge.style.display = locked ? 'inline-flex' : 'none';
}

async function restoreSession(){
  const raw = localStorage.getItem(SESSION_KEY);
  if(!raw){ showApp(false); return; }
  try{
    const s = JSON.parse(raw);
    if(!s.token) { showApp(false); return; }
    session = s;
    // verify the token is still valid
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: sbHeaders() });
    if(!res.ok) throw new Error('expired');
    applySession();
  }catch(e){
    localStorage.removeItem(SESSION_KEY);
    showApp(false);
  }
}

function flash(msg, isError){
  const el = document.getElementById('saveStatus');
  el.textContent = msg;
  el.style.color = isError ? '#a8462e' : 'var(--forest)';
  clearTimeout(flash._t);
  flash._t = setTimeout(()=>{ el.textContent = ''; }, 4000);

  const duration = isError ? 6000 : 3500;
  const t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  document.getElementById('toastIcon').textContent = isError ? '✕' : '✓';
  t.classList.toggle('err', !!isError);
  t.classList.add('show');

  const bar = document.getElementById('toastBar');
  bar.style.animation = 'none';
  bar.offsetWidth; // force reflow so the animation restarts cleanly
  bar.style.animation = `toastCountdown ${duration}ms linear forwards`;

  clearTimeout(flash._tt);
  flash._tt = setTimeout(()=>{ t.classList.remove('show'); }, duration);
}
function dismissToast(){
  clearTimeout(flash._tt);
  document.getElementById('toast').classList.remove('show');
}

/* ---------- Form ID ---------- */
function makeFormId(){
  const y = new Date().getFullYear();
  const rand = Math.floor(Math.random()*90000 + 10000);
  return `DW-${y}-${rand}`;
}

function setFormId(id){
  currentFormId = id;
  document.getElementById('formIdDisplay').textContent = id || '—';
}

/* ---------- Workflow stage ---------- */
function setStage(stage){
  if(!STAGES[stage]) stage = 'entry';
  currentStage = stage;
  const badge = document.getElementById('stageBadge');
  if(badge){
    badge.textContent = STAGES[stage].label;
    badge.className = 'stage-badge ' + STAGES[stage].cls;
  }
  renderStageActions('forms', currentFormId, 'inv');
  renderApprovalHistory('forms', currentFormId);
}

// Renders the buttons valid from the CURRENT stage, filtered to only the
// ones this user's permissions on `tab` allow.
function renderStageActions(formTable, formId, tab){
  const bar = document.getElementById(formTable === 'forms' ? 'stageActionBar' : formTable === 'cashflow_forms' ? 'cfStageActionBar' : null);
  if(!bar) return;
  const transitions = STAGE_TRANSITIONS[currentStageFor(formTable)] || [];
  const allowed = transitions.filter(t => hasPermission(tab, t.perm));
  if(!formId || !allowed.length){ bar.innerHTML = ''; return; }
  bar.innerHTML = allowed.map(t => `
    <button class="btn-small" onclick="openStageTransition('${formTable}','${t.to}','${t.action.replace(/'/g,"\\'")}','${t.perm}')">${t.action}</button>
  `).join('');
}
function currentStageFor(formTable){
  if(formTable === 'forms') return currentStage;
  if(formTable === 'cashflow_forms') return currentStageCF;
  return 'entry';
}

let pendingStageTransition = null;
function openStageTransition(formTable, toStage, actionLabel, permType){
  const formId = formTable === 'forms' ? currentFormId : cfFormId;
  if(!formId){ flash('Save the form once before changing its stage.', true); return; }
  pendingStageTransition = { formTable, formId, toStage, actionLabel, fromStage: currentStageFor(formTable) };
  document.getElementById('stageCommentTitle').textContent = actionLabel;
  document.getElementById('stageCommentInput').value = '';
  document.getElementById('stageCommentRequired').style.display = (toStage === 'rejected' || toStage === 'returned') ? '' : 'none';
  document.getElementById('stageCommentOverlay').classList.add('open');
}
function closeStageComment(){
  document.getElementById('stageCommentOverlay').classList.remove('open');
  pendingStageTransition = null;
}

async function confirmStageTransition(){
  if(!pendingStageTransition) return;
  const { formTable, formId, toStage, actionLabel, fromStage } = pendingStageTransition;
  const comment = document.getElementById('stageCommentInput').value.trim();
  if((toStage === 'rejected' || toStage === 'returned') && !comment){
    flash('A comment is required for this action.', true);
    return;
  }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${formTable}?id=eq.${encodeURIComponent(formId)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ stage: toStage, updated_at: new Date().toISOString(), updated_by: session.email })
    });
    if(!res.ok) throw new Error(await res.text());

    await fetch(`${SUPABASE_URL}/rest/v1/approval_history`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        form_table: formTable, form_id: formId,
        previous_stage: fromStage, new_stage: toStage, action: actionLabel,
        user_email: session.email, role: session.role, comment: comment || null,
        created_at: new Date().toISOString()
      })
    });

    if(formTable === 'forms') setStage(toStage); else setStageCF(toStage);
    closeStageComment();
    flash(`${actionLabel} ✓`);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function renderApprovalHistory(formTable, formId){
  const box = document.getElementById(formTable === 'forms' ? 'approvalHistoryBox' : formTable === 'cashflow_forms' ? 'cfApprovalHistoryBox' : null);
  if(!box) return;
  if(!formId || !backendReady()){ box.innerHTML = ''; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/approval_history?form_table=eq.${formTable}&form_id=eq.${encodeURIComponent(formId)}&select=*&order=created_at.asc`, { headers: sbHeaders() });
    if(!res.ok){ box.innerHTML = ''; return; }
    const rows = await res.json();
    if(!rows.length){ box.innerHTML = '<div style="font-size:.78rem;color:#888;">No approval actions yet — this form is still in Data Entry.</div>'; return; }
    box.innerHTML = `<div style="display:flex;flex-direction:column;gap:8px;">${rows.map(r => `
      <div style="border-left:3px solid var(--forest);padding:6px 12px;background:var(--sage);border-radius:0 8px 8px 0;">
        <div style="font-weight:700;font-size:.8rem;">${r.action.replace(/</g,'&lt;')} — ${(STAGES[r.new_stage]||{}).label || r.new_stage}</div>
        <div style="font-size:.72rem;color:#555;">${r.user_email} (${r.role}) · ${new Date(r.created_at).toLocaleString('en-US')}</div>
        ${r.comment ? `<div style="font-size:.76rem;color:#333;margin-top:3px;font-style:italic;">"${String(r.comment).replace(/</g,'&lt;')}"</div>` : ''}
      </div>`).join('')}</div>`;
  }catch(e){ box.innerHTML = ''; }
}
