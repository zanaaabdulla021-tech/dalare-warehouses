/* =======================  KPI PERFORMANCE EVALUATION  ======================= */
let KPI_DEFS = [
  {id:'entering-data-system', label:'Entering data into the system', weight:7, department:'Data Entry', group:'data-entry'},
  {id:'updating-existing-data', label:'Updating existing data', weight:2, department:'Data Entry', group:'data-entry'},
  {id:'entering-forms-documents', label:'Entering forms and documents', weight:5, department:'Data Entry', group:'data-entry'},
  {id:'verifying-entered-data', label:'Verifying entered data', weight:6, department:'Data Entry', group:'data-entry'},
  {id:'checking-duplicate-records', label:'Checking duplicate records', weight:4, department:'Data Entry', group:'data-entry'},
  {id:'correcting-incorrect-data', label:'Correcting incorrect data', weight:4, department:'Data Entry', group:'data-entry'},
  {id:'completing-missing-info', label:'Completing missing information', weight:4, department:'Data Entry', group:'data-entry'},
  {id:'organizing-files-records', label:'Organizing files and records', weight:1, department:'Data Entry', group:'data-entry'},
  {id:'completing-data-entry-time', label:'Completing data entry on time', weight:5, department:'Data Entry', group:'data-entry'},
  {id:'preparing-data-reports', label:'Preparing data reports', weight:3, department:'Data Entry', group:'data-entry'},
  {id:'final-quality-check', label:'Final quality checking before submission', weight:6, department:'Data Entry', group:'data-entry'},
  {id:'following-up-incomplete-data', label:'Following up on incomplete data', weight:3, department:'Data Entry', group:'data-entry'},
  {id:'errors', label:'Errors', weight:20, department:'Data Entry', group:'errors'},
  {id:'uniform-compliance', label:'Uniform Compliance', weight:10, department:'Data Entry', group:'satisfaction'},
  {id:'management-evaluation', label:'Management Evaluation', weight:20, department:'Data Entry', group:'satisfaction'},
];
let KPI_GROUPS = [
  {id:'data-entry', label:'Data Entry', icon:'📝'},
  {id:'errors', label:'Errors', icon:'⚠️'},
  {id:'satisfaction', label:'Satisfaction', icon:'⭐'},
];
let KPI_GROUP_WEIGHTS = { 'data-entry':50, 'errors':20, 'satisfaction':30 };
let kpiFormId = null;

let kpiTaskEditId = null;
function openKpiTaskEdit(taskId){
  const tr = document.querySelector(`#kpiGroupsWrap tr[data-task-id="${taskId}"]`);
  if(!tr) return;
  kpiTaskEditId = taskId;
  const def = KPI_DEFS.find(k => k.id === taskId);
  const canManage = isSuperAdmin() || session.role === 'admin';
  document.getElementById('kpiTaskEditTitle').textContent = def ? def.label : 'Task';
  document.getElementById('kpiTaskEditAccuracy').value = tr.querySelector('.kpi-accuracy').value;
  const nameRow = document.getElementById('kpiTaskEditNameRow');
  nameRow.style.display = canManage ? '' : 'none';
  document.getElementById('kpiTaskEditName').value = def ? def.label : '';
  document.getElementById('kpiTaskEditDeleteBtn').style.display = canManage ? '' : 'none';
  document.getElementById('kpiTaskEditOverlay').classList.add('open');
}
function closeKpiTaskEdit(){
  document.getElementById('kpiTaskEditOverlay').classList.remove('open');
  kpiTaskEditId = null;
}
async function saveKpiTaskEdit(){
  if(!kpiTaskEditId) return;
  const tr = document.querySelector(`#kpiGroupsWrap tr[data-task-id="${kpiTaskEditId}"]`);
  if(!tr){ closeKpiTaskEdit(); return; }
  tr.querySelector('.kpi-accuracy').value = document.getElementById('kpiTaskEditAccuracy').value;
  calcKpi();

  const canManage = isSuperAdmin() || session.role === 'admin';
  if(canManage){
    const newName = document.getElementById('kpiTaskEditName').value.trim();
    const def = KPI_DEFS.find(k => k.id === kpiTaskEditId);
    if(def && newName && newName !== def.label){
      if(!backendReady()){ flash('Backend not configured.', true); closeKpiTaskEdit(); return; }
      try{
        const newDefs = KPI_DEFS.map(k => k.id === kpiTaskEditId ? { ...k, label: newName } : k);
        const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
          method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
          body: JSON.stringify({ id:'default', kpi_defs: newDefs, updated_by: session.email, updated_at: new Date().toISOString() })
        });
        if(!res.ok) throw new Error(await res.text());
        KPI_DEFS = newDefs;
        renderKpiRows();
        flash('Task renamed ✓');
      }catch(e){ console.error(e); flash(sbError(e), true); }
    }
  }
  closeKpiTaskEdit();
}

async function deleteKpiTask(){
  if(!kpiTaskEditId) return;
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can delete a task.', true); return; }
  const def = KPI_DEFS.find(k => k.id === kpiTaskEditId);
  if(!def) return;
  if(!confirm(`Delete the task "${def.label}"? This cannot be undone.`)) return;
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const newDefs = KPI_DEFS.filter(k => k.id !== kpiTaskEditId);
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', kpi_defs: newDefs, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    KPI_DEFS = newDefs;
    renderKpiRows();
    flash('Task deleted');
    closeKpiTaskEdit();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

const KPI_DEPT_COLORS = ['#2f6fed','#0c8a4a','#b8720e','#7c5cd4','#0e7c86','#c0392b','#8e44ad','#16a085'];

async function showKpiDeptPicker(){
  document.getElementById('kpiDeptPicker').classList.remove('hidden-tab');
  document.getElementById('kpiFormBody').classList.add('hidden-tab');
  const cardsBox = document.getElementById('kpiDeptCards');
  cardsBox.innerHTML = '<div class="mgr-empty">Loading…</div>';
  if(!backendReady()){ cardsBox.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }
  try{
    const [empRes, formsRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/employees?select=department`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=data&deleted_at=is.null`, { headers: sbHeaders() })
    ]);
    const empRows = empRes.ok ? await empRes.json() : [];
    const formRows = formsRes.ok ? await formsRes.json() : [];
    const empDepts = empRows.map(r => r.department).filter(Boolean);
    const formDepts = formRows.map(r => r.data && r.data.department).filter(Boolean);
    const defDepts = KPI_DEFS.map(k => k.department).filter(Boolean);
    let depts = [...new Set([...empDepts, ...formDepts, ...defDepts])].sort();
    const canManage = isSuperAdmin() || session.role === 'admin';
    if(!depts.length){
      cardsBox.innerHTML = '<div class="mgr-empty">No departments found yet.</div>' +
        (canManage ? `<div class="home-card" style="border:2px dashed var(--line);box-shadow:none;display:flex;align-items:center;justify-content:center;min-height:160px;cursor:pointer;margin-top:10px;" onclick="addNewKpiDepartment()">
          <div style="text-align:center;color:var(--forest);">
            <div style="font-size:1.8rem;">+</div>
            <div style="font-weight:700;font-size:.9rem;">Add Department</div>
          </div>
        </div>` : '');
      return;
    }
    cardsBox.innerHTML = depts.map((d,idx) => {
      const color = KPI_DEPT_COLORS[idx % KPI_DEPT_COLORS.length];
      const escaped = d.replace(/'/g,"\\'");
      return `
      <div class="home-card" style="--accent:${color};--i:${idx};position:relative;" onclick="pickKpiDepartment('${escaped}')">
        ${canManage ? `<span class="kpi-edit-icon" style="position:absolute;top:10px;right:36px;font-size:1rem;" onclick="event.stopPropagation(); renameKpiDepartment('${escaped}')" title="Rename department">✎</span>
        <span class="kpi-edit-icon" style="position:absolute;top:10px;right:12px;font-size:1rem;" onclick="event.stopPropagation(); deleteKpiDepartment('${escaped}')" title="Delete department">🗑️</span>` : ''}
        <div class="card-top">
          <div class="ic" style="background:${color}1a;color:${color};">🏢</div>
          <div>
            <div class="nm">${d.replace(/</g,'&lt;')}</div>
            <div class="dsc">KPI evaluations for this department</div>
          </div>
        </div>
        <button class="go-btn" style="background:${color};" onclick="event.stopPropagation(); pickKpiDepartment('${escaped}')">Go to Department →</button>
      </div>`;
    }).join('') + (canManage ? `
      <div class="home-card" style="border:2px dashed var(--line);box-shadow:none;display:flex;align-items:center;justify-content:center;min-height:160px;cursor:pointer;" onclick="addNewKpiDepartment()">
        <div style="text-align:center;color:var(--forest);">
          <div style="font-size:1.8rem;">+</div>
          <div style="font-weight:700;font-size:.9rem;">Add Department</div>
        </div>
      </div>` : '');
  }catch(e){ cardsBox.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}

async function deleteKpiDepartment(name){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can delete a department.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }

  try{
    const [empRes, formsRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/employees?department=eq.${encodeURIComponent(name)}&select=id`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=id,data&deleted_at=is.null`, { headers: sbHeaders() })
    ]);
    const empRows = empRes.ok ? await empRes.json() : [];
    const formRows = formsRes.ok ? await formsRes.json() : [];
    const matchingForms = formRows.filter(f => f.data && f.data.department === name);

    const msg = `Delete the "${name}" department?\n\n`
      + `- ${empRows.length} employee(s) will have their department cleared.\n`
      + `- ${matchingForms.length} past KPI evaluation(s) reference it (their records are kept, but the department field on them will be cleared too).\n\n`
      + `This cannot be undone. Continue?`;
    if(!confirm(msg)) return;

    if(empRows.length){
      const empRes2 = await fetch(`${SUPABASE_URL}/rest/v1/employees?department=eq.${encodeURIComponent(name)}`, {
        method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({ department: '' })
      });
      if(!empRes2.ok) throw new Error(await empRes2.text());
    }
    for(const f of matchingForms){
      const updatedData = { ...f.data, department: '' };
      await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?id=eq.${encodeURIComponent(f.id)}`, {
        method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({ data: updatedData })
      });
    }

    flash(`Department "${name}" deleted ✓`);
    showKpiDeptPicker();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function renameKpiDepartment(oldName){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can rename a department.', true); return; }
  const newName = prompt(`Rename department "${oldName}" to:`, oldName);
  if(!newName || !newName.trim() || newName.trim() === oldName) return;
  const trimmed = newName.trim();
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  if(!confirm(`This will rename "${oldName}" to "${trimmed}" for every employee and KPI form using it. Continue?`)) return;

  try{
    const empRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?department=eq.${encodeURIComponent(oldName)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ department: trimmed })
    });
    if(!empRes.ok) throw new Error(await empRes.text());

    const formsRes = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=id,data`, { headers: sbHeaders() });
    if(formsRes.ok){
      const forms = await formsRes.json();
      const toUpdate = forms.filter(f => f.data && f.data.department === oldName);
      for(const f of toUpdate){
        const updatedData = { ...f.data, department: trimmed };
        await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?id=eq.${encodeURIComponent(f.id)}`, {
          method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
          body: JSON.stringify({ data: updatedData })
        });
      }
    }
    flash(`Department renamed to "${trimmed}" ✓`);
    showKpiDeptPicker();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function addNewKpiDepartment(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can add a new department.', true); return; }
  const name = prompt('New department name');
  if(!name || !name.trim()) return;
  pickKpiDepartment(name.trim());
}

function pickKpiDepartment(dept){
  document.getElementById('kpiDeptPicker').classList.add('hidden-tab');
  document.getElementById('kpiFormBody').classList.remove('hidden-tab');
  newFormKPI();
  document.querySelector('.kpi-department').value = dept;
  // Defensive re-check: guards against any async re-render (e.g. department
  // lookup finishing late) silently restoring the button's default visibility.
  setTimeout(() => {
    const showAll = isSuperAdmin() || session.role === 'admin';
    const btn = document.getElementById('addKpiSectionBtn');
    if(btn) btn.style.display = showAll ? '' : 'none';
  }, 0);
}

function backToKpiDeptPicker(){
  showKpiDeptPicker();
}

async function deleteKpiSection(groupId){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can delete a section.', true); return; }
  const g = KPI_GROUPS.find(x => x.id === groupId);
  if(!g) return;
  const taskCount = KPI_DEFS.filter(k => (k.group || 'data-entry') === groupId).length;
  if(!confirm(`Delete the "${g.label}" section? This also removes its ${taskCount} task(s) from the KPI Scorecard. This cannot be undone.`)) return;
  if(!backendReady()){ flash('Backend not configured.', true); return; }

  try{
    const newGroups = KPI_GROUPS.filter(x => x.id !== groupId);
    const newDefs = KPI_DEFS.filter(k => (k.group || 'data-entry') !== groupId);
    const newGroupWeights = { ...KPI_GROUP_WEIGHTS };
    delete newGroupWeights[groupId];

    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', kpi_groups: newGroups, kpi_defs: newDefs, kpi_group_weights: newGroupWeights, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());

    KPI_GROUPS = newGroups;
    KPI_DEFS = newDefs;
    KPI_GROUP_WEIGHTS = newGroupWeights;
    renderKpiRows();
    flash(`Section "${g.label}" deleted`);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function addNewKpiSection(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can add a new section.', true); return; }
  const name = prompt('New section name (e.g. "Punctuality", "Communication")');
  if(!name || !name.trim()) return;
  const trimmed = name.trim();
  const id = trimmed.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') || 'section-' + Date.now().toString(36);
  if(KPI_GROUPS.some(g => g.id === id)){ flash('A section with a similar name already exists.', true); return; }

  const icon = prompt('Pick an emoji icon for this section (or leave blank for 📌)', '📌') || '📌';
  const weightStr = prompt(`Weight % for "${trimmed}" out of the total score (existing sections currently total ${Object.values(KPI_GROUP_WEIGHTS).reduce((a,b)=>a+b,0)}%)`, '10');
  const weight = parseFloat(weightStr);
  if(isNaN(weight) || weight < 0){ flash('Enter a valid weight percentage.', true); return; }

  const taskName = prompt(`First task inside "${trimmed}" (you can add more later via Reorder KPI Tasks)`, `${trimmed} Score`);
  if(!taskName || !taskName.trim()) return;
  const taskId = taskName.trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') || 'task-' + Date.now().toString(36);

  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const newGroups = [...KPI_GROUPS, { id, label: trimmed, icon }];
    const newGroupWeights = { ...KPI_GROUP_WEIGHTS, [id]: weight };
    const newDefs = [...KPI_DEFS, { id: taskId, label: taskName.trim(), weight: 100, department: 'Data Entry', group: id }];

    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', kpi_groups: newGroups, kpi_group_weights: newGroupWeights, kpi_defs: newDefs, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());

    KPI_GROUPS = newGroups;
    KPI_GROUP_WEIGHTS = newGroupWeights;
    KPI_DEFS = newDefs;
    renderKpiRows();
    flash(`Section "${trimmed}" added ✓`);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function renderKpiRows(){
  const wrap = document.getElementById('kpiGroupsWrap');
  const showAll = isSuperAdmin() || session.role === 'admin';
  const addSectionBtn = document.getElementById('addKpiSectionBtn');
  if(addSectionBtn) addSectionBtn.style.display = showAll ? '' : 'none';
  const visibleDefs = showAll ? KPI_DEFS : KPI_DEFS.filter(k => k.department && k.department === currentUserDepartment);
  if(!visibleDefs.length){
    wrap.innerHTML = `<div style="text-align:center;color:#888;padding:14px;">
      <div style="margin-bottom:10px;">${currentUserDepartment ? `No KPI tasks are set up yet for the ${currentUserDepartment} department.` : "Your account isn't linked to a department yet. Ask a super admin to add your login email to your Staff profile."}</div>
      <button type="button" class="btn-small" onclick="switchTab('home')">← Back to Home</button>
    </div>`;
    return;
  }

  const rowHtml = k => `
    <tr data-task-id="${k.id}">
      <td>${k.label.replace(/</g,'&lt;')} <span class="kpi-edit-icon" onclick="openKpiTaskEdit('${k.id}')" title="Enter Accuracy %">✎</span></td>
      <td><input type="number" value="${k.weight}" class="kpi-weight" readonly></td>
      <td><input type="number" min="0" class="kpi-target" placeholder="0"></td>
      <td><input type="number" min="0" class="kpi-actual" placeholder="0"></td>
      <td class="kpi-hidden-col"><input type="number" min="0" max="100" class="kpi-accuracy" placeholder="100"></td>
      <td class="readonly-cell kpi-achievement kpi-hidden-col">0%</td>
      <td class="readonly-cell kpi-score">0%</td>
    </tr>`;

  wrap.innerHTML = KPI_GROUPS.map(g => {
    const groupDefs = visibleDefs.filter(k => (k.group || 'data-entry') === g.id);
    if(!groupDefs.length) return '';
    const weightSum = groupDefs.reduce((s,k) => s + (parseFloat(k.weight)||0), 0);
    return `
      <div class="section-header" style="margin-top:18px;justify-content:space-between;"><div style="display:flex;align-items:center;gap:10px;"><div class="num">${g.icon}</div><div class="title">${g.label} <span style="opacity:.75;font-weight:600;">(${KPI_GROUP_WEIGHTS[g.id] !== undefined ? KPI_GROUP_WEIGHTS[g.id] : '—'}% of total)</span></div></div>${showAll ? `<span class="no-print" onclick="deleteKpiSection('${g.id}')" title="Delete this section" style="cursor:pointer;background:rgba(255,255,255,.22);width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">🗑️</span>` : ''}</div>
      <div class="price-table-wrap">
        <table class="pricelist kpi-table">
          <thead>
            <tr>
              <th data-label-key="kpi.col.task">Task / KPI</th>
              <th data-label-key="kpi.col.weight">Weight %</th>
              <th data-label-key="kpi.col.target">Target</th>
              <th data-label-key="kpi.col.actual">total</th>
              <th class="kpi-hidden-col" data-label-key="kpi.col.accuracy">Accuracy %</th>
              <th class="kpi-hidden-col" data-label-key="kpi.col.achievement">Achievement %</th>
              <th data-label-key="kpi.col.score">Score</th>
            </tr>
          </thead>
          <tbody>${groupDefs.map(rowHtml).join('')}</tbody>
          <tfoot>
            <tr class="kpi-group-total-row" data-group="${g.id}">
              <td class="readonly-cell" data-label-key="kpi.col.total">Total</td>
              <td class="readonly-cell">${weightSum}</td>
              <td></td>
              <td class="readonly-cell kpi-group-actual-sum">0</td>
              <td class="kpi-hidden-col"></td>
              <td class="kpi-hidden-col"></td>
              <td class="readonly-cell kpi-group-score-sum">0%</td>
            </tr>
          </tfoot>
        </table>
      </div>`;
  }).join('');

  wrap.querySelectorAll('input').forEach(inp => inp.addEventListener('input', calcKpi));
  applySiteLabels();
}

let kpiManualStatus = undefined; // undefined = follow auto-calculated color; 'rejected'/'warning'/null = manual override
function setKpiManualStatus(status){
  kpiManualStatus = status;
  calcKpi();
}

function calcKpi(){
  const groupTotals = {}; // groupId -> { weightedScore, totalWeight }
  let accuracySum = 0, count = 0;
  let anyActualEntered = false;

  document.querySelectorAll('#kpiGroupsWrap tr[data-task-id]').forEach(tr => {
    const t = parseFloat(tr.querySelector('.kpi-target').value) || 0;
    const a = parseFloat(tr.querySelector('.kpi-actual').value) || 0;
    if(a > 0) anyActualEntered = true;
    const accRaw = tr.querySelector('.kpi-accuracy').value;
    const ac = Math.min(100, Math.max(0, accRaw === '' ? 100 : (parseFloat(accRaw) || 0)));
    const w = parseFloat(tr.querySelector('.kpi-weight').value) || 0;

    const def = KPI_DEFS.find(k => k.id === tr.dataset.taskId);
    const groupId = (def && def.group) || 'data-entry';
    const isInverse = groupId === 'errors'; // fewer errors relative to target = better score
    const rawAchievement = t > 0 ? Math.min(100, (a/t)*100) : 0;
    // A task with no Target set yet hasn't really been evaluated — don't let the
    // inverse formula read that as "zero errors = perfect score" by default.
    const achievement = isInverse ? (t > 0 ? (100 - rawAchievement) : 0) : rawAchievement;
    const score = achievement * (ac/100);

    tr.querySelector('.kpi-achievement').textContent = achievement.toFixed(1) + '%';
    tr.querySelector('.kpi-score').textContent = (score * (w/100)).toFixed(1) + '%';

    if(!groupTotals[groupId]) groupTotals[groupId] = { weightedScore:0, totalWeight:0, scoreSum:0, actualSum:0 };
    groupTotals[groupId].weightedScore += score * w;
    groupTotals[groupId].totalWeight += w;
    groupTotals[groupId].scoreSum += score * (w/100);
    groupTotals[groupId].actualSum += a;

    accuracySum += ac;
    count++;
  });

  // Each visible group contributes its own within-group average, scaled by that group's overall weight.
  let combinedScore = 0, combinedGroupWeight = 0;
  Object.keys(groupTotals).forEach(groupId => {
    const g = groupTotals[groupId];
    const totalCell = document.querySelector(`.kpi-group-total-row[data-group="${groupId}"] .kpi-group-score-sum`);
    if(totalCell) totalCell.textContent = g.scoreSum.toFixed(1) + '%';
    const actualCell = document.querySelector(`.kpi-group-total-row[data-group="${groupId}"] .kpi-group-actual-sum`);
    if(actualCell) actualCell.textContent = g.actualSum;
    if(g.totalWeight <= 0) return;
    const groupScore = g.weightedScore / g.totalWeight; // 0-100 within this group
    const groupWeight = KPI_GROUP_WEIGHTS[groupId] !== undefined ? KPI_GROUP_WEIGHTS[groupId] : (100 / Object.keys(groupTotals).length);
    combinedScore += groupScore * groupWeight;
    combinedGroupWeight += groupWeight;
  });

  const finalKpi = combinedGroupWeight ? combinedScore / combinedGroupWeight : 0;
  const avgAccuracy = count ? accuracySum/count : 0;

  document.getElementById('kpiTotalScore').textContent = finalKpi.toFixed(1) + '%';
  document.getElementById('kpiAvgAccuracy').textContent = avgAccuracy.toFixed(1) + '%';

  const level = document.getElementById('kpiLevel');
  level.className = 'kpi-level';
  const kpiSheet = document.getElementById('kpiForm');
  if(kpiManualStatus !== undefined){
    // A person explicitly chose a color; respect it until they pick another or clear it.
    if(kpiSheet){
      if(kpiManualStatus) kpiSheet.setAttribute('data-status', kpiManualStatus);
      else kpiSheet.removeAttribute('data-status');
    }
  }else if(!anyActualEntered && kpiSheet){ kpiSheet.removeAttribute('data-status'); }
  else if(finalKpi >= 80){ if(kpiSheet) kpiSheet.removeAttribute('data-status'); }
  else if(finalKpi >= 70){ if(kpiSheet) kpiSheet.setAttribute('data-status','warning'); }
  else{ if(kpiSheet) kpiSheet.setAttribute('data-status','rejected'); }

  if(finalKpi >= 90){ level.textContent = 'Excellent'; level.classList.add('excellent'); }
  else if(finalKpi >= 80){ level.textContent = 'Good'; level.classList.add('good'); }
  else if(finalKpi >= 70){ level.textContent = 'Average'; level.classList.add('average'); }
  else{ level.textContent = 'Needs Improvement'; level.classList.add('low'); }
}

function serializeKpi(){
  const rows = Array.from(document.querySelectorAll('#kpiGroupsWrap tr[data-task-id]')).map(tr => ({
    taskId: tr.dataset.taskId,
    target: tr.querySelector('.kpi-target').value,
    actual: tr.querySelector('.kpi-actual').value,
    accuracy: tr.querySelector('.kpi-accuracy').value,
  }));
  return {
    employee: document.querySelector('.kpi-employee').value,
    department: document.querySelector('.kpi-department').value,
    month: document.querySelector('.kpi-month').value,
    supervisor: document.querySelector('.kpi-supervisor').value,
    notes: document.querySelector('.kpi-notes') ? document.querySelector('.kpi-notes').value : '',
    manualStatus: kpiManualStatus !== undefined ? kpiManualStatus : null,
    manualStatusSet: kpiManualStatus !== undefined,
    rows
  };
}

function restoreKpi(d){
  renderKpiRows();
  document.querySelector('.kpi-employee').value = d.employee || '';
  document.querySelector('.kpi-department').value = d.department || 'Data Entry';
  document.querySelector('.kpi-month').value = d.month || '';
  document.querySelector('.kpi-supervisor').value = d.supervisor || '';
  if(document.querySelector('.kpi-notes')) document.querySelector('.kpi-notes').value = d.notes || '';
  kpiManualStatus = d.manualStatusSet ? (d.manualStatus || null) : undefined;
  renderKpiEmployeeInfoCard();
  const savedRows = d.rows || [];
  document.querySelectorAll('#kpiGroupsWrap tr[data-task-id]').forEach((tr, i) => {
    // Prefer matching by stable task id (safe across reordering); fall back to
    // array position for older saved forms recorded before this existed.
    const r = savedRows.find(x => x.taskId === tr.dataset.taskId) || savedRows[i];
    if(!r) return;
    const targetInp = tr.querySelector('.kpi-target');
    const actualInp = tr.querySelector('.kpi-actual');
    const accuracyInp = tr.querySelector('.kpi-accuracy');
    if(targetInp && r.target !== undefined) targetInp.value = r.target;
    if(actualInp && r.actual !== undefined) actualInp.value = r.actual;
    if(accuracyInp && r.accuracy !== undefined) accuracyInp.value = r.accuracy;
  });
  calcKpi();
  applyViewerLock();
}

function setKpiFormId(id){
  kpiFormId = id;
  document.getElementById('kpiFormId').textContent = id || '—';
}
function slugifyEmployeeName(name){
  return String(name || '').trim().toUpperCase()
    .replace(/[^A-Z0-9\u0600-\u06FF]+/g, '-')
    .replace(/(^-|-$)/g, '');
}
function makeKpiFormId(employeeName){
  const slug = slugifyEmployeeName(employeeName);
  const monthVal = (document.querySelector('.kpi-month') || {}).value;
  const suffix = monthVal ? monthVal : Math.floor(Math.random()*9000 + 1000).toString();
  if(slug) return `KPI-${slug}-${suffix}`;
  return `KPI-${new Date().getFullYear()}-${Math.floor(Math.random()*90000 + 10000)}`;
}
let kpiIsNewForm = true;

function refreshKpiFormIdFromEmployee(){
  if(!kpiIsNewForm) return; // don't rename an already-saved/opened form's ID
  const name = document.querySelector('.kpi-employee').value;
  setKpiFormId(makeKpiFormId(name));
}

/* =======================  DAILY WORK ENTRY (feeds KPI Actual totals)  ======================= */
function openDailyEntry(){
  document.getElementById('dailyEntryEmployee').value = document.querySelector('.kpi-employee').value || '';
  document.getElementById('dailyEntryDate').value = new Date().toISOString().slice(0,7);
  const box = document.getElementById('dailyEntryFields');
  const showAll = isSuperAdmin() || session.role === 'admin';
  const visibleDefs = showAll ? KPI_DEFS : KPI_DEFS.filter(k => k.department && k.department === currentUserDepartment);
  box.innerHTML = visibleDefs.map(k => `
    <div class="site-text-row">
      <label style="flex:0 0 160px;" title="${k.id}">${k.label.replace(/</g,'&lt;')}</label>
      <input type="number" min="0" class="daily-entry-value" data-task-id="${k.id}" placeholder="0">
    </div>
  `).join('');
  document.getElementById('dailyEntryOverlay').classList.add('open');
  loadDailyEntryForSelectedDay();
}
function closeDailyEntry(){ document.getElementById('dailyEntryOverlay').classList.remove('open'); }

async function loadDailyEntryForSelectedDay(){
  document.querySelectorAll('.daily-entry-value').forEach(inp => inp.value = '');
  const employee = document.getElementById('dailyEntryEmployee').value.trim();
  const month = document.getElementById('dailyEntryDate').value; // YYYY-MM
  if(!employee || !month || !backendReady()) return;
  const date = month + '-01';
  const id = `${slugifyEmployeeName(employee)}-${date}`;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_daily_entries?id=eq.${encodeURIComponent(id)}&select=data`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(!rows.length) return;
    Object.entries(rows[0].data || {}).forEach(([taskId, val]) => {
      const inp = document.querySelector(`.daily-entry-value[data-task-id="${taskId}"]`);
      if(inp) inp.value = val;
    });
    flash('Loaded existing entry for ' + month);
  }catch(e){ /* fine to start blank */ }
}

function addTaskFromDailyEntry(){
  const box = document.getElementById('dailyEntryFields');
  const id = 'task-' + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
  const row = document.createElement('div');
  row.className = 'site-text-row';
  row.dataset.newTask = 'true';
  row.innerHTML = `
    <input type="text" class="daily-entry-new-label" placeholder="New task name" style="flex:0 0 160px;">
    <input type="number" min="0" class="daily-entry-value" data-task-id="${id}" placeholder="0">
  `;
  box.appendChild(row);
  row.querySelector('.daily-entry-new-label').focus();
}

async function saveDailyEntry(){
  const employee = document.getElementById('dailyEntryEmployee').value.trim();
  const month = document.getElementById('dailyEntryDate').value; // YYYY-MM
  if(!employee){ flash('Enter an employee name.', true); return; }
  if(!month){ flash('Pick a month.', true); return; }
  const date = month + '-01';

  // Persist any newly-added tasks to the shared KPI task list first.
  const newRows = Array.from(document.querySelectorAll('#dailyEntryFields [data-new-task="true"]'));
  const newTasks = newRows.map(row => ({
    id: row.querySelector('.daily-entry-value').dataset.taskId,
    label: row.querySelector('.daily-entry-new-label').value.trim(),
  })).filter(t => t.label);
  if(newTasks.length){
    try{
      const updatedDefs = [...KPI_DEFS, ...newTasks.map(t => ({ id:t.id, label:t.label, weight:0, department: currentUserDepartment || '', group: 'data-entry' }))];
      const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
        method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
        body: JSON.stringify({ id:'default', kpi_defs: updatedDefs, updated_by: session.email, updated_at: new Date().toISOString() })
      });
      if(!res.ok) throw new Error(await res.text());
      KPI_DEFS = updatedDefs;
      if(document.getElementById('kpiGroupsWrap')) renderKpiRows();
    }catch(e){
      console.error(e);
      flash('Could not add new task (' + sbError(e) + '). Ask a super admin to set its weight in Reorder KPI Tasks.', true);
    }
  }

  const values = {};
  document.querySelectorAll('.daily-entry-value').forEach(inp => {
    const v = parseFloat(inp.value);
    if(v) values[inp.dataset.taskId] = v;
  });
  const id = `${slugifyEmployeeName(employee)}-${date}`;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_daily_entries`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id, employee_name: employee, entry_date: date, data: values, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    closeDailyEntry();
    flash('Monthly entry saved for ' + month);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function pullFromDailyLog(){
  const employee = document.querySelector('.kpi-employee').value.trim();
  const month = document.querySelector('.kpi-month').value; // YYYY-MM
  if(!employee){ flash('Enter the employee name first.', true); return; }
  if(!month){ flash('Pick the evaluation month first.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  const id = `${slugifyEmployeeName(employee)}-${month}-01`;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_daily_entries?id=eq.${encodeURIComponent(id)}&select=data`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('No monthly entry found for ' + employee + ' in ' + month, true); return; }
    const data = rows[0].data || {};
    document.querySelectorAll('#kpiGroupsWrap tr[data-task-id]').forEach(tr => {
      const val = data[tr.dataset.taskId];
      if(val !== undefined) tr.querySelector('.kpi-actual').value = val;
    });
    calcKpi();
    flash('Pulled monthly entry into Actual totals');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function openKpiCompare(){
  document.getElementById('kpiCompareOverlay').classList.add('open');
  const monthInp = document.getElementById('kpiCompareMonth');
  if(!monthInp.value){
    const now = new Date();
    monthInp.value = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  }
  loadKpiCompare();
}
function closeKpiCompare(){
  document.getElementById('kpiCompareOverlay').classList.remove('open');
}

function openCompanyKpiOverview(){
  document.getElementById('companyKpiOverlay').classList.add('open');
  const monthInp = document.getElementById('companyKpiMonth');
  if(!monthInp.value){
    const now = new Date();
    monthInp.value = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  }
  loadCompanyKpiOverview();
}
function closeCompanyKpiOverview(){ document.getElementById('companyKpiOverlay').classList.remove('open'); }

async function loadCompanyKpiOverview(){
  const box = document.getElementById('companyKpiContent');
  const month = document.getElementById('companyKpiMonth').value;
  if(!month){ box.innerHTML = '<div class="mgr-empty">Pick a month.</div>'; return; }
  box.innerHTML = '<div class="mgr-empty">Loading…</div>';
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=*&deleted_at=is.null`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const forms = (await res.json()).filter(f => f.data && f.data.month === month);
    if(!forms.length){ box.innerHTML = `<div class="mgr-empty">No KPI evaluations found for ${month}.</div>`; return; }

    const scored = forms.map(f => ({ employee: f.company_name || '(unnamed)', department: f.data.department || '—', score: computeKpiScoreFromData(f.data || {}) }));
    const avgScore = scored.reduce((s,r) => s+r.score, 0) / scored.length;
    const sorted = [...scored].sort((a,b) => b.score - a.score);
    const top3 = sorted.slice(0,3);
    const topNames = new Set(top3.map(r => r.employee));
    const bottom3 = [...sorted].reverse().filter(r => !topNames.has(r.employee)).slice(0,3);

    const byDept = {};
    scored.forEach(r => { if(!byDept[r.department]) byDept[r.department] = []; byDept[r.department].push(r.score); });
    const deptAverages = Object.keys(byDept).sort().map(d => ({ dept: d, avg: byDept[d].reduce((s,v)=>s+v,0)/byDept[d].length, count: byDept[d].length }));

    box.innerHTML = `
      <div class="kpi-summary-grid" style="margin-bottom:16px;">
        <div class="kpi-stat"><small>Company Average</small><strong>${avgScore.toFixed(1)}%</strong></div>
        <div class="kpi-stat"><small>Employees Evaluated</small><strong>${scored.length}</strong></div>
        <div class="kpi-stat"><small>Departments</small><strong>${deptAverages.length}</strong></div>
      </div>

      <div style="font-weight:800;color:var(--forest-deep);margin-bottom:6px;">By Department</div>
      <table class="adm-table" style="margin-bottom:16px;">
        <tr><th>Department</th><th>Avg Score</th><th>Employees</th></tr>
        ${deptAverages.map(d => `<tr><td>${d.dept.replace(/</g,'&lt;')}</td><td>${d.avg.toFixed(1)}%</td><td>${d.count}</td></tr>`).join('')}
      </table>

      <div style="font-weight:800;color:var(--forest-deep);margin-bottom:6px;">🏆 Top Performers</div>
      <table class="adm-table" style="margin-bottom:16px;">
        ${top3.map((r,i) => `<tr><td>${i+1}</td><td>${r.employee.replace(/</g,'&lt;')}</td><td style="color:#0f7a3d;font-weight:700;">${r.score.toFixed(1)}%</td></tr>`).join('')}
      </table>

      <div style="font-weight:800;color:var(--forest-deep);margin-bottom:6px;">Needs Attention</div>
      <table class="adm-table">
        ${bottom3.length ? bottom3.map((r,i) => `<tr><td>${r.employee.replace(/</g,'&lt;')}</td><td style="color:#a8462e;font-weight:700;">${r.score.toFixed(1)}%</td></tr>`).join('')
          : '<tr><td style="text-align:center;color:#888;">Not enough employees to show separately from Top Performers.</td></tr>'}
      </table>`;
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}

async function loadKpiCompare(){
  const box = document.getElementById('kpiCompareResults');
  const month = document.getElementById('kpiCompareMonth').value;
  if(!month){ box.innerHTML = '<div class="mgr-empty">Pick a month to compare.</div>'; return; }
  box.innerHTML = '<div class="mgr-empty">Loading…</div>';
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }

  try{
    let allowedNames = null;
    let scopeNote = 'Showing every department.';
    if(!isSuperAdmin() && session.role !== 'admin'){
      const meRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(session.email)}&select=department`, { headers: sbHeaders() });
      const meRows = meRes.ok ? await meRes.json() : [];
      if(!meRows.length || !meRows[0].department){
        box.innerHTML = '<div class="mgr-empty">Your account isn\'t linked to a department yet.</div>';
        return;
      }
      const dept = meRows[0].department;
      scopeNote = `Showing the ${dept} department only.`;
      const teamRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?department=eq.${encodeURIComponent(dept)}&select=full_name`, { headers: sbHeaders() });
      const teamRows = teamRes.ok ? await teamRes.json() : [];
      allowedNames = new Set(teamRows.map(r => r.full_name));
    }

    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=*&deleted_at=is.null`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    let forms = await res.json();
    forms = forms.filter(f => f.data && f.data.month === month);
    if(allowedNames) forms = forms.filter(f => allowedNames.has(f.company_name));

    // Populate the department dropdown from whatever departments show up this month.
    const deptSel = document.getElementById('kpiCompareDeptFilter');
    const depts = [...new Set(forms.map(f => f.data && f.data.department).filter(Boolean))].sort();
    const currentDeptChoice = deptSel.value;
    deptSel.innerHTML = '<option value="">All departments</option>' + depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">${d.replace(/</g,'&lt;')}</option>`).join('');
    deptSel.value = depts.includes(currentDeptChoice) ? currentDeptChoice : '';

    const deptFilter = deptSel.value;
    if(deptFilter){
      forms = forms.filter(f => f.data && f.data.department === deptFilter);
      scopeNote = `Showing the ${deptFilter} department only.`;
    }

    if(!forms.length){ box.innerHTML = `<div class="mgr-empty">No KPI evaluations found for ${month}.</div>`; return; }

    const ranked = forms.map(f => ({
      employee: f.company_name || '(unnamed)',
      score: computeKpiScoreFromData(f.data || {}),
    })).sort((a,b) => b.score - a.score);

    const maxScore = Math.max(...ranked.map(r => r.score), 1);
    box.innerHTML = `
      <div class="adm-hint">${scopeNote} — ${ranked.length} employee(s) evaluated for ${month}.</div>
      <table class="adm-table">
        <tr><th>Rank</th><th>Employee</th><th>Score</th><th></th></tr>
        ${ranked.map((r,i) => {
          const barColor = r.score>=90?'#0f7a3d':r.score>=80?'#2f7d32':r.score>=70?'#b9770e':'#a8462e';
          const barWidth = Math.max(4, (r.score/maxScore)*100);
          return `<tr>
            <td style="font-weight:800;">${i+1}</td>
            <td>${r.employee.replace(/</g,'&lt;')}</td>
            <td style="font-family:'IBM Plex Mono',monospace;font-weight:700;">${r.score.toFixed(1)}%</td>
            <td style="width:40%;"><div style="background:${barColor};height:10px;border-radius:5px;width:${barWidth}%;"></div></td>
          </tr>`;
        }).join('')}
      </table>`;
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}

async function openDailyLogViewer(){
  document.getElementById('dailyLogViewerOverlay').classList.add('open');
  const hint = document.getElementById('dailyLogScopeHint');
  const box = document.getElementById('dailyLogResults');
  box.innerHTML = '<div class="mgr-empty">Loading…</div>';
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }

  try{
    let allowedNames = null; // null = no restriction (admin/super_admin)
    if(!isSuperAdmin() && session.role !== 'admin'){
      const meRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?email=eq.${encodeURIComponent(session.email)}&select=department`, { headers: sbHeaders() });
      const meRows = meRes.ok ? await meRes.json() : [];
      if(!meRows.length || !meRows[0].department){
        hint.textContent = "Your account isn't linked to a department yet. Ask a super admin to add your login email to your Staff profile.";
        box.innerHTML = '';
        return;
      }
      const dept = meRows[0].department;
      hint.textContent = `Showing entries for the ${dept} department only.`;
      const teamRes = await fetch(`${SUPABASE_URL}/rest/v1/employees?department=eq.${encodeURIComponent(dept)}&select=full_name`, { headers: sbHeaders() });
      const teamRows = teamRes.ok ? await teamRes.json() : [];
      allowedNames = new Set(teamRows.map(r => r.full_name));
    }else{
      hint.textContent = 'Showing entries for every department.';
    }

    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_daily_entries?select=*&order=entry_date.desc&limit=200`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    let rows = await res.json();
    if(allowedNames) rows = rows.filter(r => allowedNames.has(r.employee_name));

    if(!rows.length){ box.innerHTML = '<div class="mgr-empty">No monthly entries found.</div>'; return; }

    box.innerHTML = rows.map(r => {
      const taskLines = Object.entries(r.data || {}).map(([taskId, val]) => {
        const def = KPI_DEFS.find(k => k.id === taskId);
        return `${(def ? def.label : taskId).replace(/</g,'&lt;')}: ${val}`;
      }).join(' · ');
      const monthLabel = (r.entry_date || '').slice(0,7); // YYYY-MM-01 -> YYYY-MM
      return `
        <div class="ep-kpi-row" style="cursor:default;flex-direction:column;align-items:flex-start;">
          <div style="font-weight:700;font-size:.82rem;">${r.employee_name.replace(/</g,'&lt;')} — ${monthLabel}</div>
          <div style="font-size:.72rem;color:#777;margin-top:2px;">${taskLines || 'No tasks logged'}</div>
        </div>
      `;
    }).join('');
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">Could not load the log.</div>'; }
}
function closeDailyLogViewer(){ document.getElementById('dailyLogViewerOverlay').classList.remove('open'); }

function newFormKPI(){
  kpiIsNewForm = true;
  setKpiFormId(makeKpiFormId());
  restoreKpi({});
  flash('New form started');
}

async function saveKPI(){
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  if(!kpiFormId) setKpiFormId(makeKpiFormId());
  const newData = serializeKpi();
  const oldData = await fetchExistingFormData('kpi_forms', kpiFormId);
  const payload = {
    id: kpiFormId,
    company_name: document.querySelector('.kpi-employee').value || '(unnamed)',
    data: newData,
    updated_by: session.email,
    updated_at: new Date().toISOString()
  };
  try{
    if(oldData){
      await fetch(`${SUPABASE_URL}/rest/v1/form_versions`, {
        method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({ form_table:'kpi_forms', form_id: kpiFormId, data: oldData, saved_by: session.email, saved_at: new Date().toISOString() })
      }).catch(()=>{});
    }
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save', kpiFormId, describeFormDiff(oldData, newData) || payload.company_name);
    flash('Saved ✓ ' + kpiFormId);
    loadEmployeeNamesList();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function openKPI(id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?id=eq.${encodeURIComponent(id)}&select=*`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Form not found.', true); return; }
    kpiIsNewForm = false;
    setKpiFormId(rows[0].id);
    closeManager();
    restoreKpi(rows[0].data || {});
    flash('Opened ' + rows[0].id);
  }catch(e){ console.error(e); closeManager(); flash(sbError(e), true); }
}

function computeKpiScoreFromData(d){
  const groupTotals = {};
  (d.rows || []).forEach((r, i) => {
    const def = (r.taskId && KPI_DEFS.find(k => k.id === r.taskId)) || KPI_DEFS[i];
    if(!def) return;
    const t = parseFloat(r.target) || 0;
    const a = parseFloat(r.actual) || 0;
    const ac = Math.min(100, Math.max(0, r.accuracy === '' || r.accuracy === undefined ? 100 : (parseFloat(r.accuracy) || 0)));
    const groupId = def.group || 'data-entry';
    const isInverse = groupId === 'errors';
    const rawAchievement = t > 0 ? Math.min(100, (a/t)*100) : 0;
    const achievement = isInverse ? (t > 0 ? (100 - rawAchievement) : 0) : rawAchievement;
    const score = achievement * (ac/100);
    if(!groupTotals[groupId]) groupTotals[groupId] = { weightedScore:0, totalWeight:0 };
    groupTotals[groupId].weightedScore += score * def.weight;
    groupTotals[groupId].totalWeight += def.weight;
  });
  let combinedScore = 0, combinedGroupWeight = 0;
  Object.keys(groupTotals).forEach(groupId => {
    const g = groupTotals[groupId];
    if(g.totalWeight <= 0) return;
    const groupScore = g.weightedScore / g.totalWeight;
    const groupWeight = KPI_GROUP_WEIGHTS[groupId] !== undefined ? KPI_GROUP_WEIGHTS[groupId] : (100 / Object.keys(groupTotals).length);
    combinedScore += groupScore * groupWeight;
    combinedGroupWeight += groupWeight;
  });
  return combinedGroupWeight ? combinedScore / combinedGroupWeight : 0;
}

async function openEmployeeProfile(id){
  const e = employees.find(x => x.id === id);
  if(!e){ flash('Employee not found.', true); return; }
  const body = document.getElementById('empProfileBody');
  body.innerHTML = `
    <div class="ep-head">
      ${e.photo ? `<img src="${e.photo}" class="ep-photo" alt="">` : `<div class="ep-photo-placeholder">👤</div>`}
      <div>
        <div class="ep-name">${(e.full_name||'(no name)').replace(/</g,'&lt;')}</div>
        <div class="ep-sub">${(e.job_title||'').replace(/</g,'&lt;')}${e.department ? ' · ' + e.department.replace(/</g,'&lt;') : ''}</div>
      </div>
    </div>
    <div class="ep-info-grid">
      <div class="ep-info-item"><small>Employee ID</small><span>${e.id}</span></div>
      <div class="ep-info-item"><small>Gender</small><span>${e.gender || '—'}</span></div>
      <div class="ep-info-item"><small>Age</small><span>${e.age || '—'}</span></div>
      <div class="ep-info-item"><small>Phone</small><span>${e.phone || '—'}</span></div>
      <div class="ep-info-item"><small>Start Date</small><span>${e.start_date || '—'}</span></div>
    </div>
    <div id="epKpiSummary"></div>
    <div id="epKpiTrend"></div>
    <div class="activities-head">KPI Evaluation History</div>
    <div id="epKpiList"><div class="mgr-empty">Loading…</div></div>
  `;
  document.getElementById('empProfileOverlay').classList.add('open');

  if(!backendReady() || !e.full_name){
    document.getElementById('epKpiList').innerHTML = '<div class="mgr-empty">No KPI records.</div>';
    document.getElementById('epKpiTrend').innerHTML = '';
    return;
  }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?company_name=eq.${encodeURIComponent(e.full_name)}&select=*&order=updated_at.desc`, { headers: sbHeaders() });
    if(!res.ok) throw new Error();
    const rows = await res.json();
    const list = document.getElementById('epKpiList');
    const summaryBox = document.getElementById('epKpiSummary');
    if(!rows.length){
      list.innerHTML = '<div class="mgr-empty">No KPI evaluations yet.</div>';
      summaryBox.innerHTML = '';
      document.getElementById('epKpiTrend').innerHTML = '';
      return;
    }
    const scores = rows.map(r => computeKpiScoreFromData(r.data || {}));
    const avg = scores.reduce((a,b) => a+b, 0) / scores.length;
    const latest = scores[0];
    const levelFor = s => s>=90?'Excellent':s>=80?'Good':s>=70?'Average':'Needs Improvement';
    const colorFor = s => s>=90?'#0f7a3d':s>=80?'#2f7d32':s>=70?'#b9770e':'#a8462e';
    summaryBox.innerHTML = `
      <div class="kpi-summary-grid" style="padding:0 0 14px;">
        <div class="kpi-stat"><small>Average Score</small><strong style="color:${colorFor(avg)};">${avg.toFixed(1)}%</strong></div>
        <div class="kpi-stat"><small>Latest Score</small><strong style="color:${colorFor(latest)};">${latest.toFixed(1)}%</strong></div>
        <div class="kpi-stat"><small>Performance Level</small><strong style="color:${colorFor(avg)};font-size:1.1rem;">${levelFor(avg)}</strong></div>
      </div>
      <div style="font-size:.72rem;color:#777;margin:-8px 0 12px;">${rows.length} evaluation${rows.length>1?'s':''} on record</div>
    `;
    const trendBox = document.getElementById('epKpiTrend');
    const chronological = [...rows].reverse(); // oldest -> newest, left to right
    const levelCounts = { Excellent:0, Good:0, Average:0, 'Needs Improvement':0 };
    chronological.forEach(r => {
      const s = computeKpiScoreFromData(r.data || {});
      const lvl = s>=90?'Excellent':s>=80?'Good':s>=70?'Average':'Needs Improvement';
      levelCounts[lvl]++;
    });
    trendBox.innerHTML = `
      <div class="activities-head" style="margin-bottom:6px;">Performance Trend</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
        ${chronological.map((r,i) => {
          const s = computeKpiScoreFromData(r.data || {});
          const dot = s>=90?'💚':s>=80?'🟢':s>=70?'🟡':'🔴';
          const levelName = s>=90?'Excellent':s>=80?'Good':s>=70?'Average':'Needs Improvement';
          const month = (r.data && r.data.month) || r.id;
          return `<span title="${month.replace(/</g,'&lt;')}: ${s.toFixed(1)}% (${levelName})" style="font-size:1.1rem;cursor:default;">${dot}</span>`;
        }).join('')}
      </div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:.72rem;color:#666;margin:6px 0 14px;">
        <span>💚 Excellent × ${levelCounts.Excellent}</span>
        <span>🟢 Good × ${levelCounts.Good}</span>
        <span>🟡 Average × ${levelCounts.Average}</span>
        <span>🔴 Needs Improvement × ${levelCounts['Needs Improvement']}</span>
      </div>
    `;
    list.innerHTML = rows.map((r,i) => {
      const score = scores[i];
      const month = (r.data && r.data.month) || 'No month set';
      const color = score>=90?'#0f7a3d':score>=80?'#2f7d32':score>=70?'#b9770e':'#a8462e';
      return `
        <div class="ep-kpi-row" onclick="openEmployeeProfileKpi('${r.id}')">
          <div>
            <div style="font-weight:700;font-size:.82rem;">${r.id.replace(/</g,'&lt;')}</div>
            <div style="font-size:.72rem;color:#777;">${month.replace(/</g,'&lt;')}</div>
          </div>
          <div class="ep-kpi-score" style="color:${color};">${score.toFixed(1)}%</div>
        </div>
      `;
    }).join('');
  }catch(err){
    document.getElementById('epKpiList').innerHTML = '<div class="mgr-empty">Could not load KPI history.</div>';
  }
}
function closeEmployeeProfile(){ document.getElementById('empProfileOverlay').classList.remove('open'); }

function openEmployeeProfileKpi(id){
  closeEmployeeProfile();
  switchTab('kpi');
  openKPI(id);
}

function newFormCF(){
  setCFFormId(makeCFFormId());
  restoreCF({});
  setStageCF('entry');
  flash('New cash flow form started');
}

async function saveCF(){
  if(!backendReady()){ flash('Backend not configured — see CONFIG at top of file.', true); return; }
  if(!cfFormId) setCFFormId(makeCFFormId());
  const newData = serializeCF();
  const oldData = await fetchExistingFormData('cashflow_forms', cfFormId);

  const negFieldChecks = [];
  (newData.rows || []).forEach((r, i) => {
    negFieldChecks.push({ value: r.itemsPerPkg, label: `Row ${i+1} Items per Package` });
    negFieldChecks.push({ value: r.cashflow, label: `Row ${i+1} Cash Flow` });
    negFieldChecks.push({ value: r.stock, label: `Row ${i+1} Stock` });
  });
  const negField = validateNonNegative(negFieldChecks);
  if(negField){ flash(`${negField} can't be negative. Please fix it before saving.`, true); return; }

  const payload = {
    id: cfFormId,
    company_name: document.querySelector('.cf-company').value || '(unnamed)',
    stage: currentStageCF,
    data: newData,
    updated_at: new Date().toISOString(),
    updated_by: session.email || null
  };
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save', cfFormId, describeFormDiff(oldData, newData));
    flash('Saved ✓ ' + cfFormId);
    loadCompanyNamesList();
    loadCfSectionList();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function openCF(id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms?id=eq.${encodeURIComponent(id)}&select=*`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Form not found.', true); return; }
    setCFFormId(rows[0].id);
    restoreCF(rows[0].data || {});
    setStageCF(rows[0].stage || 'entry');
    closeManager();
    flash('Opened ' + rows[0].id);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

// initial rows to match original form
for(let i=0;i<10;i++) addRow();

// Initialise a fresh form ID + stage, and clean up expired forms
setFormId(makeFormId());
setStage('entry');

// Cash flow tab init
for(let i=0;i<12;i++) addRowCF();
setCFFormId(makeCFFormId());
setStageCF('entry');

// SOP tab init
restoreSOP({});
setSopFormId(makeSopFormId());

// KPI tab init
renderKpiRows();
setKpiFormId(makeKpiFormId());
document.querySelector('.kpi-employee').addEventListener('input', refreshKpiFormIdFromEmployee);
document.querySelector('.kpi-month').addEventListener('input', refreshKpiFormIdFromEmployee);

switchTab('home');
makeColumnsResizable('#form table.pricelist', 'dalare-col-widths-inv');
makeColumnsResizable('#cfForm table.pricelist', 'dalare-col-widths-cf');

try{
  const savedOrientation = localStorage.getItem('dalare-print-orientation');
  if(savedOrientation === 'landscape' || savedOrientation === 'portrait') setPrintOrientation(savedOrientation);
}catch(e){ /* fine, defaults to portrait */ }
