// ===================== Attendance & Shifts =====================
let shiftsCache = [];

async function loadAttendanceTab(){
  const hintEl = document.getElementById('attApiUrlHint');
  if(hintEl) hintEl.textContent = SUPABASE_URL;
  const canManage = isSuperAdmin() || session.role === 'admin';
  const addShiftBtn = document.getElementById('addShiftBtn');
  if(addShiftBtn) addShiftBtn.style.display = canManage ? '' : 'none';
  const addAttRecordBtn = document.getElementById('addAttRecordBtn');
  if(addAttRecordBtn) addAttRecordBtn.style.display = canManage ? '' : 'none';
  const markAbsentBtn = document.getElementById('markAbsentBtn');
  if(markAbsentBtn) markAbsentBtn.style.display = canManage ? '' : 'none';
  await loadShifts();
  const dateInp = document.getElementById('attDateFilter');
  if(!dateInp.value) dateInp.value = new Date().toISOString().slice(0,10);
  await loadAttendanceRecords();
  await loadAttendanceDashboard();
  await loadLeaveRequests();
  const reportMonthInp = document.getElementById('attReportMonth');
  if(!reportMonthInp.value){
    const now = new Date();
    reportMonthInp.value = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  }
  await loadAttendanceReports();
}

async function loadShifts(){
  const body = document.getElementById('shiftsBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/shifts?select=*&order=name.asc`, { headers: sbHeaders() });
    shiftsCache = res.ok ? await res.json() : [];
  }catch(e){ shiftsCache = []; }
  renderShifts();
}

function renderShifts(){
  const body = document.getElementById('shiftsBody');
  if(!shiftsCache.length){ body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#888;padding:10px;">No shifts yet.</td></tr>'; return; }
  const canManage = isSuperAdmin() || session.role === 'admin';
  body.innerHTML = shiftsCache.map(s => `
    <tr data-shift-id="${s.id}">
      <td><input value="${(s.name||'').replace(/"/g,'&quot;')}" data-f="name" ${canManage?'':'readonly'}></td>
      <td><input type="time" value="${s.start_time||''}" data-f="start_time" ${canManage?'':'readonly'}></td>
      <td><input type="time" value="${s.end_time||''}" data-f="end_time" ${canManage?'':'readonly'}></td>
      <td><input type="number" min="0" value="${s.grace_minutes||0}" data-f="grace_minutes" style="width:60px;" ${canManage?'':'readonly'}></td>
      <td><input type="number" min="0" value="${s.break_minutes||0}" data-f="break_minutes" style="width:60px;" ${canManage?'':'readonly'}></td>
      <td>
        <select data-f="overtime_enabled" ${canManage?'':'disabled'}>
          <option value="true" ${s.overtime_enabled?'selected':''}>Yes</option>
          <option value="false" ${!s.overtime_enabled?'selected':''}>No</option>
        </select>
      </td>
      <td>
        ${canManage ? `<button class="btn-small" onclick="saveShiftRow('${s.id}')">Save</button>
        <button class="btn-small remove" onclick="deleteShift('${s.id}')">×</button>` : ''}
      </td>
    </tr>`).join('');
}

function saveShiftRow(id){
  const tr = document.querySelector(`#shiftsBody tr[data-shift-id="${id}"]`);
  if(!tr) return;
  const name = tr.querySelector('[data-f="name"]').value.trim();
  const start_time = tr.querySelector('[data-f="start_time"]').value;
  const end_time = tr.querySelector('[data-f="end_time"]').value;
  const grace_minutes = parseInt(tr.querySelector('[data-f="grace_minutes"]').value) || 0;
  const break_minutes = parseInt(tr.querySelector('[data-f="break_minutes"]').value) || 0;
  const overtime_enabled = tr.querySelector('[data-f="overtime_enabled"]').value === 'true';
  if(!name){ flash('Enter a shift name.', true); return; }
  if(!start_time || !end_time){ flash('Enter both start and end time.', true); return; }
  const isNew = id.startsWith('new-');
  saveShift({ id: isNew ? null : id, name, start_time, end_time, grace_minutes, break_minutes, overtime_enabled });
}

function addBlankShiftRow(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can manage shifts.', true); return; }
  const tempId = 'new-' + Date.now().toString(36);
  shiftsCache.unshift({ id: tempId, name:'', start_time:'08:00', end_time:'16:00', grace_minutes:10, break_minutes:60, overtime_enabled:true, _isNew:true });
  renderShifts();
  const nameInput = document.querySelector(`#shiftsBody tr[data-shift-id="${tempId}"] [data-f="name"]`);
  if(nameInput) nameInput.focus();
}

async function saveShift(shift){
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  const id = shift.id || 'shift-' + Date.now().toString(36);
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/shifts`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id, name: shift.name, start_time: shift.start_time, end_time: shift.end_time,
        grace_minutes: shift.grace_minutes, break_minutes: shift.break_minutes, overtime_enabled: shift.overtime_enabled })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Shift saved ✓');
    loadShifts();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function deleteShift(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can delete shifts.', true); return; }
  if(!confirm('Delete this shift?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/shifts?id=eq.${encodeURIComponent(id)}`, { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    loadShifts();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function computeAttendanceMetrics(checkIn, checkOut, shift){
  // checkIn/checkOut are 'HH:MM' strings for the same day; shift has start_time/end_time/grace_minutes.
  const toMin = (t) => { if(!t) return null; const [h,m] = t.split(':').map(Number); return h*60+m; };
  const ciMin = toMin(checkIn), coMin = toMin(checkOut);
  const shiftStart = shift ? toMin(shift.start_time) : null;
  const shiftEnd = shift ? toMin(shift.end_time) : null;
  const grace = shift ? (shift.grace_minutes||0) : 0;
  const breakMin = shift ? (shift.break_minutes||0) : 0;

  let workingMinutes = null, lateMinutes = 0, overtimeMinutes = 0, earlyLeaveMinutes = 0, status = 'present';

  if(ciMin === null){ status = 'absent'; return { workingMinutes:null, lateMinutes:0, overtimeMinutes:0, earlyLeaveMinutes:0, status }; }
  if(coMin === null){ status = 'missing_checkout'; }
  else{
    workingMinutes = Math.max(0, coMin - ciMin - breakMin);
    if(shiftEnd !== null && coMin > shiftEnd && shift && shift.overtime_enabled) overtimeMinutes = coMin - shiftEnd;
    if(shiftEnd !== null && coMin < shiftEnd) earlyLeaveMinutes = shiftEnd - coMin;
  }
  if(shiftStart !== null && ciMin > shiftStart + grace){ lateMinutes = ciMin - shiftStart; status = 'late'; }

  return { workingMinutes, lateMinutes, overtimeMinutes, earlyLeaveMinutes, status };
}

function formatMinutes(mins){
  if(mins === null || mins === undefined) return '—';
  const h = Math.floor(mins/60), m = mins%60;
  return `${h}h ${m}m`;
}

let attendanceCache = [];

async function loadAttendanceRecords(){
  const body = document.getElementById('attendanceBody');
  const date = document.getElementById('attDateFilter').value;
  if(!date){ body.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#888;padding:14px;">Pick a date to view records.</td></tr>'; return; }
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/attendance?select=*&date=eq.${date}&order=employee_name.asc`, { headers: sbHeaders() });
    attendanceCache = res.ok ? await res.json() : [];
  }catch(e){ attendanceCache = []; }
  renderAttendanceRecords();
}

function renderAttendanceRecords(){
  const body = document.getElementById('attendanceBody');
  const search = (document.getElementById('attSearchFilter').value || '').toLowerCase();
  const statusFilter = document.getElementById('attStatusFilter').value;
  let rows = attendanceCache;
  if(search) rows = rows.filter(r => (r.employee_name||'').toLowerCase().includes(search));
  if(statusFilter) rows = rows.filter(r => r.status === statusFilter);

  if(!rows.length){ body.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#888;padding:14px;">No records for this date.</td></tr>'; return; }

  const statusColors = { present:'#0f7a3d', late:'#b9770e', absent:'#a8462e', missing_checkout:'#a8462e' };
  const canManage = isSuperAdmin() || session.role === 'admin';
  body.innerHTML = rows.map(r => {
    const color = statusColors[r.status] || '#555';
    const ciTime = r.check_in ? new Date(r.check_in).toISOString().slice(11,16) : '';
    const coTime = r.check_out ? new Date(r.check_out).toISOString().slice(11,16) : '';
    const shiftOpts = `<option value="">No shift</option>` + shiftsCache.map(s =>
      `<option value="${s.id}" ${s.id === r.shift_id ? 'selected' : ''}>${s.name.replace(/</g,'&lt;')}</option>`).join('');
    return `<tr data-att-id="${r.id}" data-att-date="${r.date}">
      <td><input value="${(r.employee_name||'').replace(/"/g,'&quot;')}" data-f="employee_name" ${canManage?'':'readonly'} list="employeeNamesList"></td>
      <td>${r.date}</td>
      <td><input type="time" value="${ciTime}" data-f="check_in" ${canManage?'':'readonly'}></td>
      <td><input type="time" value="${coTime}" data-f="check_out" ${canManage?'':'readonly'}></td>
      <td>${formatMinutes(r.working_minutes)}</td>
      <td>${r.late_minutes ? r.late_minutes + 'm' : '—'}</td>
      <td>${r.overtime_minutes ? `${r.overtime_minutes}m ${
        r.overtime_approved ? '<span style="color:#0f7a3d;font-weight:700;" title="Overtime approved">✓</span>'
        : (canManage ? `<button class="btn-small" style="padding:2px 6px;font-size:.65rem;" onclick="approveOvertime('${r.id}')">Approve</button>` : '<span style="color:#b9770e;" title="Awaiting approval">⏳</span>')
      }` : '—'}</td>
      <td><span style="background:${color}1a;color:${color};padding:2px 8px;border-radius:999px;font-weight:700;font-size:.72rem;">${(r.status||'').replace('_',' ')}</span></td>
      <td>
        ${canManage ? `<select data-f="shift_id" style="width:90px;font-size:.72rem;">${shiftOpts}</select>
        <button class="btn-small" onclick="saveAttendanceRow('${r.id}')">Save</button>
        <button class="btn-small remove" onclick="deleteAttendanceRecord('${r.id}')">×</button>` : ''}
      </td>
    </tr>`;
  }).join('');
}

let attEditId = null;
function addBlankAttendanceRow(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can manage attendance records.', true); return; }
  const date = document.getElementById('attDateFilter').value || new Date().toISOString().slice(0,10);
  const tempId = 'new-' + Date.now().toString(36);
  attendanceCache.unshift({ id: tempId, employee_name:'', date, check_in:null, check_out:null, shift_id:null, status:'present', _isNew:true });
  renderAttendanceRecords();
  const nameInput = document.querySelector(`#attendanceBody tr[data-att-id="${tempId}"] [data-f="employee_name"]`);
  if(nameInput) nameInput.focus();
}

function saveAttendanceRow(id){
  const tr = document.querySelector(`#attendanceBody tr[data-att-id="${id}"]`);
  if(!tr) return;
  const employee_name = tr.querySelector('[data-f="employee_name"]').value.trim();
  const checkIn = tr.querySelector('[data-f="check_in"]').value;
  const checkOut = tr.querySelector('[data-f="check_out"]').value;
  const shiftId = tr.querySelector('[data-f="shift_id"]').value || null;
  const date = tr.dataset.attDate;
  if(!employee_name){ flash('Enter the employee name.', true); return; }
  const isNew = id.startsWith('new-');
  saveAttendanceRecord({ id: isNew ? null : id, employee_name, date, checkIn, checkOut, shiftId });
}

async function saveAttendanceRecord({ id, employee_name, date, checkIn, checkOut, shiftId }){
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  const shift = shiftId ? shiftsCache.find(s => s.id === shiftId) : null;
  const metrics = computeAttendanceMetrics(checkIn || null, checkOut || null, shift);
  const recId = id || 'att-' + Date.now().toString(36);

  const payload = {
    id: recId, employee_name, date,
    check_in: checkIn ? `${date}T${checkIn}:00` : null,
    check_out: checkOut ? `${date}T${checkOut}:00` : null,
    shift_id: shiftId || null,
    device_id: null, verification_method: 'manual',
    working_minutes: metrics.workingMinutes, late_minutes: metrics.lateMinutes,
    overtime_minutes: metrics.overtimeMinutes, early_leave_minutes: metrics.earlyLeaveMinutes,
    status: metrics.status, updated_at: new Date().toISOString()
  };

  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/attendance`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save_attendance', recId, employee_name);
    flash('Attendance record saved ✓');
    loadAttendanceRecords();
    loadAttendanceDashboard();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function deleteAttendanceRecord(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can delete attendance records.', true); return; }
  if(!confirm('Delete this attendance record?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/attendance?id=eq.${encodeURIComponent(id)}`, { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    loadAttendanceRecords();
    loadAttendanceDashboard();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function approveOvertime(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can approve overtime.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/attendance?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ overtime_approved: true, overtime_approved_by: session.email, overtime_approved_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Overtime approved ✓');
    loadAttendanceRecords();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

// ===================== Leave Requests =====================
let leaveRequestsCache = [];

function toggleLeaveHourlyMode(){
  const hourly = document.getElementById('leaveIsHourly').checked;
  document.getElementById('leaveHourlyRow').style.display = hourly ? 'flex' : 'none';
  document.getElementById('leaveToRow').style.display = hourly ? 'none' : '';
  document.getElementById('leaveDaysRow').style.display = hourly ? 'none' : '';
  if(hourly){
    // For hourly leave, To = From (a single day) so days_count stays meaningful.
    document.getElementById('leaveTo').value = document.getElementById('leaveFrom').value;
  }
}

function updateLeaveDaysCount(){
  const isHourly = document.getElementById('leaveIsHourly').checked;
  const from = document.getElementById('leaveFrom').value;
  if(isHourly){ document.getElementById('leaveTo').value = from; return; }
  const to = document.getElementById('leaveTo').value;
  const daysInp = document.getElementById('leaveDays');
  if(!from || !to){ daysInp.value = ''; return; }
  const fromD = new Date(from), toD = new Date(to);
  const diff = Math.round((toD - fromD) / 86400000) + 1;
  daysInp.value = diff > 0 ? diff : '';
}

function openLeaveRequestForm(){
  document.getElementById('leaveEmployee').value = '';
  document.getElementById('leaveType').value = 'Annual';
  document.getElementById('leaveIsHourly').checked = false;
  document.getElementById('leaveFrom').value = '';
  document.getElementById('leaveTo').value = '';
  document.getElementById('leaveStartTime').value = '';
  document.getElementById('leaveEndTime').value = '';
  document.getElementById('leaveDays').value = '';
  document.getElementById('leaveReason').value = '';
  toggleLeaveHourlyMode();
  document.getElementById('leaveRequestOverlay').classList.add('open');
}
function closeLeaveRequestForm(){ document.getElementById('leaveRequestOverlay').classList.remove('open'); }

async function submitLeaveRequest(){
  const employee = document.getElementById('leaveEmployee').value.trim();
  const type = document.getElementById('leaveType').value;
  const isHourly = document.getElementById('leaveIsHourly').checked;
  const from = document.getElementById('leaveFrom').value;
  const startTime = document.getElementById('leaveStartTime').value;
  const endTime = document.getElementById('leaveEndTime').value;
  const to = isHourly ? from : document.getElementById('leaveTo').value;
  const days = isHourly ? 0 : (parseInt(document.getElementById('leaveDays').value) || 0);
  const reason = document.getElementById('leaveReason').value.trim();

  if(!employee){ flash('Enter the employee name.', true); return; }
  if(!from){ flash('Pick a date.', true); return; }
  if(isHourly){
    if(!startTime || !endTime){ flash('Pick both Start and End times.', true); return; }
    if(endTime <= startTime){ flash('End time must be after Start time.', true); return; }
  }else{
    if(!to){ flash('Pick both From and To dates.', true); return; }
    if(days <= 0){ flash('To date must be on or after From date.', true); return; }
  }
  if(!backendReady()){ flash('Backend not configured.', true); return; }

  const id = 'leave-' + Date.now().toString(36);
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/leave_requests`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        id, employee_name: employee, leave_type: type, start_date: from, end_date: to, days_count: days,
        is_hourly: isHourly, start_time: isHourly ? startTime : null, end_time: isHourly ? endTime : null,
        reason: reason || null, status: 'pending', requested_by: session.email, requested_at: new Date().toISOString()
      })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('request_leave', id, employee);
    flash('Leave request submitted ✓');
    closeLeaveRequestForm();
    loadLeaveRequests();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadLeaveRequests(){
  const body = document.getElementById('leaveBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/leave_requests?select=*&order=requested_at.desc`, { headers: sbHeaders() });
    leaveRequestsCache = res.ok ? await res.json() : [];
  }catch(e){ leaveRequestsCache = []; }
  renderLeaveRequests();
}

function renderLeaveRequests(){
  const body = document.getElementById('leaveBody');
  const statusFilter = document.getElementById('leaveStatusFilter').value;
  let rows = leaveRequestsCache;
  if(statusFilter) rows = rows.filter(r => r.status === statusFilter);

  if(!rows.length){ body.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#888;padding:14px;">No leave requests found.</td></tr>'; return; }

  const statusColors = { pending:'#b9770e', approved:'#0f7a3d', rejected:'#a8462e' };
  const canManage = isSuperAdmin() || session.role === 'admin';
  const bulkBtn = document.getElementById('bulkApproveLeaveBtn');
  const pendingCount = rows.filter(r => r.status === 'pending').length;
  if(bulkBtn) bulkBtn.style.display = (canManage && pendingCount > 1) ? '' : 'none';
  body.innerHTML = rows.map(r => {
    const color = statusColors[r.status] || '#555';
    const payLabel = r.status !== 'approved' ? '—' : (r.paid_status === 'paid' ? '💰 Paid' : '🚫 Unpaid');
    const checkbox = (canManage && r.status === 'pending') ? `<input type="checkbox" class="leave-row-check" value="${r.id}">` : '';
    const actions = (canManage && r.status === 'pending')
      ? `<button class="btn-small" onclick="approveLeaveRequest('${r.id}')">✓ Approve</button>
         <button class="btn-small remove" onclick="rejectLeaveRequest('${r.id}')">✕ Reject</button>`
      : (canManage ? `<button class="btn-small remove" onclick="deleteLeaveRequest('${r.id}')">×</button>` : '');
    return `<tr>
      <td>${checkbox}</td>
      <td>${(r.employee_name||'').replace(/</g,'&lt;')}</td>
      <td>${r.leave_type||''}${r.is_hourly ? ' <small style="opacity:.7;">(hourly)</small>' : ''}</td>
      <td>${r.start_date||''}</td>
      <td>${r.is_hourly ? `${r.start_time||''}–${r.end_time||''}` : (r.end_date||'')}</td>
      <td>${r.is_hourly ? '—' : (r.days_count||'')}</td>
      <td style="max-width:180px;">${r.reason ? String(r.reason).replace(/</g,'&lt;') : '—'}</td>
      <td><span style="background:${color}1a;color:${color};padding:2px 8px;border-radius:999px;font-weight:700;font-size:.72rem;">${r.status}</span></td>
      <td>${payLabel}</td>
      <td>${actions}</td>
    </tr>`;
  }).join('');
}

async function approveLeaveRequest(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can approve leave.', true); return; }
  const paid = confirm('Approve this leave as PAID (no salary deduction)?\n\nOK = Paid leave\nCancel = Unpaid leave (salary deducted)');
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/leave_requests?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({
        status: 'approved', paid_status: paid ? 'paid' : 'unpaid',
        approved_by: session.email, approved_at: new Date().toISOString()
      })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('approve_leave', id, paid ? 'paid' : 'unpaid');
    flash(`Leave approved as ${paid ? 'Paid' : 'Unpaid'} ✓`);
    loadLeaveRequests();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function rejectLeaveRequest(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can reject leave.', true); return; }
  if(!confirm('Reject this leave request?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/leave_requests?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ status: 'rejected', approved_by: session.email, approved_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('reject_leave', id);
    flash('Leave request rejected');
    loadLeaveRequests();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function deleteLeaveRequest(id){
  if(!confirm('Delete this leave request record?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/leave_requests?id=eq.${encodeURIComponent(id)}`, { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    loadLeaveRequests();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function toggleAllLeaveCheckboxes(master){
  document.querySelectorAll('.leave-row-check').forEach(cb => { cb.checked = master.checked; });
}

async function bulkApproveLeave(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can approve leave.', true); return; }
  const ids = Array.from(document.querySelectorAll('.leave-row-check:checked')).map(cb => cb.value);
  if(!ids.length){ flash('Select at least one pending request first.', true); return; }
  const paid = confirm(`Approve ${ids.length} selected request(s) as PAID (no salary deduction)?\n\nOK = Paid leave\nCancel = Unpaid leave (salary deducted)`);
  try{
    for(const id of ids){
      await fetch(`${SUPABASE_URL}/rest/v1/leave_requests?id=eq.${encodeURIComponent(id)}`, {
        method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({ status:'approved', paid_status: paid ? 'paid' : 'unpaid', approved_by: session.email, approved_at: new Date().toISOString() })
      });
    }
    logActivity('bulk_approve_leave', null, `${ids.length} requests, ${paid ? 'paid' : 'unpaid'}`);
    flash(`${ids.length} request(s) approved as ${paid ? 'Paid' : 'Unpaid'} ✓`);
    loadLeaveRequests();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function exportLeaveRequestsExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load. Check your connection and try again.', true); return; }
  if(!leaveRequestsCache.length){ flash('Nothing to export.', true); return; }
  const rows = leaveRequestsCache.map(r => ({
    'Employee': r.employee_name || '', 'Type': r.leave_type || '', 'Hourly': r.is_hourly ? 'Yes' : 'No',
    'From': r.start_date || '', 'To': r.end_date || '', 'Start Time': r.start_time || '', 'End Time': r.end_time || '',
    'Days': r.days_count || '', 'Reason': r.reason || '', 'Status': r.status || '',
    'Pay': r.paid_status || '', 'Requested By': r.requested_by || '', 'Requested At': r.requested_at || '',
    'Approved By': r.approved_by || '', 'Approved At': r.approved_at || ''
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Leave Requests');
  XLSX.writeFile(wb, `leave-requests-${new Date().toISOString().slice(0,10)}.xlsx`);
}

async function exportAttendanceExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load. Check your connection and try again.', true); return; }
  if(!attendanceCache.length){ flash('Nothing to export for this date. Pick a date with records, or export a wider range from Supabase directly.', true); return; }
  const rows = attendanceCache.map(r => ({
    'Employee': r.employee_name || '', 'Date': r.date || '',
    'Check In': r.check_in ? new Date(r.check_in).toLocaleTimeString('en-US', {hour:'2-digit', minute:'2-digit'}) : '',
    'Check Out': r.check_out ? new Date(r.check_out).toLocaleTimeString('en-US', {hour:'2-digit', minute:'2-digit'}) : '',
    'Working Hours': formatMinutes(r.working_minutes), 'Late (min)': r.late_minutes || 0, 'Overtime (min)': r.overtime_minutes || 0,
    'Status': r.status || ''
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
  XLSX.writeFile(wb, `attendance-${document.getElementById('attDateFilter').value || 'export'}.xlsx`);
}

let payrollReportCache = [];

let deductionsCache = [];

function openDeductionsManager(){
  document.getElementById('deductionsOverlay').classList.add('open');
  document.getElementById('dedMonth').value = document.getElementById('attReportMonth').value || '';
  loadDeductions();
}
function closeDeductionsManager(){ document.getElementById('deductionsOverlay').classList.remove('open'); }

async function loadDeductions(){
  const box = document.getElementById('deductionsList');
  if(!backendReady()){ box.innerHTML = '<tr><td colspan="6">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/payroll_adjustments?select=*&order=created_at.desc&limit=100`, { headers: sbHeaders() });
    deductionsCache = res.ok ? await res.json() : [];
    renderDeductions();
  }catch(e){ box.innerHTML = '<tr><td colspan="6">'+sbError(e)+'</td></tr>'; }
}
function renderDeductions(){
  const box = document.getElementById('deductionsList');
  if(!deductionsCache.length){ box.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">No entries yet.</td></tr>'; return; }
  box.innerHTML = deductionsCache.map(d => `
    <tr>
      <td>${(d.employee_name||'').replace(/</g,'&lt;')}</td>
      <td>${d.type}</td>
      <td>${(d.amount||0).toLocaleString()}</td>
      <td>${d.month||''}</td>
      <td>${d.note ? String(d.note).replace(/</g,'&lt;') : ''}</td>
      <td><button class="btn-small remove" onclick="deleteDeduction('${d.id}')">×</button></td>
    </tr>`).join('');
}

async function addDeduction(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can add deductions.', true); return; }
  const employee_name = document.getElementById('dedEmployee').value.trim();
  const type = document.getElementById('dedType').value;
  const amount = parseFloat(document.getElementById('dedAmount').value) || 0;
  const month = document.getElementById('dedMonth').value;
  const note = document.getElementById('dedNote').value.trim();
  if(!employee_name || !amount || !month){ flash('Fill in employee, amount, and month.', true); return; }
  if(amount < 0){ flash('Amount can\'t be negative.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/payroll_adjustments`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ id:'adj-'+Date.now().toString(36), employee_name, type, amount, month, note: note||null, created_by: session.email, created_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Added ✓');
    document.getElementById('dedAmount').value = '';
    document.getElementById('dedNote').value = '';
    loadDeductions();
    loadAttendanceReports();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function deleteDeduction(id){
  if(!confirm('Delete this entry?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/payroll_adjustments?id=eq.${encodeURIComponent(id)}`, { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    loadDeductions();
    loadAttendanceReports();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadAttendanceReports(){
  const body = document.getElementById('payrollBody');
  const month = document.getElementById('attReportMonth').value;
  if(!month){ body.innerHTML = '<tr><td colspan="12" style="text-align:center;color:#888;padding:14px;">Pick a month to see the report.</td></tr>'; return; }
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="12" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  body.innerHTML = '<tr><td colspan="12" style="text-align:center;color:#888;padding:14px;">Loading…</td></tr>';

  try{
    const [attRes, leaveRes, empRes, adjRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/attendance?select=*&date=gte.${month}-01&date=lte.${month}-31`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/leave_requests?select=*&status=eq.approved`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/employees?select=full_name,base_salary`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/payroll_adjustments?select=*&month=eq.${month}`, { headers: sbHeaders() })
    ]);
    const attRows = attRes.ok ? await attRes.json() : [];
    const leaveRows = leaveRes.ok ? await leaveRes.json() : [];
    const empRows = empRes.ok ? await empRes.json() : [];
    const adjRows = adjRes.ok ? await adjRes.json() : [];
    const salaryByName = {};
    empRows.forEach(e => { if(e.full_name) salaryByName[e.full_name] = e.base_salary || 0; });
    const adjByName = {};
    adjRows.forEach(a => {
      if(!adjByName[a.employee_name]) adjByName[a.employee_name] = { deduction:0, advance:0, bonus:0 };
      adjByName[a.employee_name][a.type] = (adjByName[a.employee_name][a.type]||0) + (a.amount||0);
    });

    // Keep only leave that overlaps this month.
    const monthStart = new Date(month + '-01');
    const monthEnd = new Date(monthStart.getFullYear(), monthStart.getMonth()+1, 0);
    const monthLeave = leaveRows.filter(r => {
      const s = new Date(r.start_date), e = new Date(r.end_date || r.start_date);
      return s <= monthEnd && e >= monthStart;
    });

    const byEmployee = {};
    const ensure = (name) => { if(!byEmployee[name]) byEmployee[name] = { present:0, minutes:0, overtimeMin:0, late:0, absent:0, paidDays:0, unpaidDays:0 }; return byEmployee[name]; };

    attRows.forEach(r => {
      const e = ensure(r.employee_name || '(unnamed)');
      if(r.status === 'absent'){ e.absent++; return; }
      e.present++;
      e.minutes += r.working_minutes || 0;
      e.overtimeMin += r.overtime_approved ? (r.overtime_minutes || 0) : 0;
      if(r.status === 'late') e.late++;
    });
    monthLeave.forEach(r => {
      const e = ensure(r.employee_name || '(unnamed)');
      const days = r.is_hourly ? 0 : (r.days_count || 0);
      if(r.paid_status === 'paid') e.paidDays += days; else e.unpaidDays += days;
    });

    // Standard payroll assumptions: 26 working days/month, 8-hour day, 1.5x overtime rate.
    const WORK_DAYS = 26, WORK_HOURS = 8, OT_MULTIPLIER = 1.5;
    payrollReportCache = Object.keys(byEmployee).sort().map(name => {
      const base = salaryByName[name] || 0;
      const dailyRate = base / WORK_DAYS;
      const hourlyRate = dailyRate / WORK_HOURS;
      const r = byEmployee[name];
      const overtimeHrs = r.overtimeMin / 60;
      const overtimePay = overtimeHrs * hourlyRate * OT_MULTIPLIER;
      const unpaidDeduction = r.unpaidDays * dailyRate;
      const adj = adjByName[name] || { deduction:0, advance:0, bonus:0 };
      const manualAdjTotal = adj.bonus - adj.deduction - adj.advance;
      const netPay = base ? Math.max(0, base - unpaidDeduction + overtimePay + manualAdjTotal) : null;
      return { employee: name, ...r, baseSalary: base, overtimePay, unpaidDeduction, manualAdj: adj, manualAdjTotal, netPay };
    });

    if(!payrollReportCache.length){ body.innerHTML = `<tr><td colspan="12" style="text-align:center;color:#888;padding:14px;">No attendance or leave data for ${month}.</td></tr>`; return; }

    body.innerHTML = payrollReportCache.map(r => `
      <tr>
        <td>${r.employee.replace(/</g,'&lt;')}</td>
        <td>${r.present}</td>
        <td>${formatMinutes(r.minutes)}</td>
        <td>${(r.overtimeMin/60).toFixed(1)}</td>
        <td>${r.late}</td>
        <td>${r.absent}</td>
        <td>${r.paidDays}</td>
        <td>${r.unpaidDays}</td>
        <td>${r.baseSalary ? r.baseSalary.toLocaleString() : '—'}</td>
        <td>${r.baseSalary ? ('-'+r.unpaidDeduction.toLocaleString(undefined,{maximumFractionDigits:0})+' / +'+r.overtimePay.toLocaleString(undefined,{maximumFractionDigits:0})+(r.manualAdjTotal ? ' / '+(r.manualAdjTotal>0?'+':'')+r.manualAdjTotal.toLocaleString(undefined,{maximumFractionDigits:0}) : '')) : '—'}</td>
        <td style="font-weight:800;color:var(--forest-deep);">${r.netPay !== null ? r.netPay.toLocaleString(undefined,{maximumFractionDigits:0}) : '—'}</td>
        <td class="no-print"><button class="btn-small" onclick="openPayslip('${r.employee.replace(/'/g,"\\'")}')">📄 Payslip</button></td>
      </tr>`).join('');
  }catch(e){ console.error(e); body.innerHTML = '<tr><td colspan="12" style="text-align:center;color:#888;">'+sbError(e)+'</td></tr>'; }
}

function openPayslip(employeeName){
  const r = payrollReportCache.find(x => x.employee === employeeName);
  if(!r){ flash('Payroll data not found for this employee.', true); return; }
  const month = document.getElementById('attReportMonth').value;
  const box = document.getElementById('payslipContent');
  const adj = r.manualAdj || { deduction:0, advance:0, bonus:0 };
  const fmt = (n) => (n||0).toLocaleString(undefined,{maximumFractionDigits:0});

  box.innerHTML = `
    <div id="payslipPrintArea" style="border:1px solid var(--line);border-radius:12px;padding:20px;font-family:'IBM Plex Sans',sans-serif;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;border-bottom:2px solid var(--forest);padding-bottom:12px;">
        <div style="font-weight:800;font-size:1.1rem;color:var(--forest-deep);">DALARE WAREHOUSE</div>
      </div>
      <div style="font-weight:800;font-size:1rem;margin-bottom:4px;">Payslip — ${month}</div>
      <div style="color:#555;margin-bottom:14px;">${r.employee}</div>
      <table style="width:100%;border-collapse:collapse;font-size:.85rem;">
        <tr><td style="padding:5px 0;">Base Salary</td><td style="text-align:end;font-weight:700;">${fmt(r.baseSalary)}</td></tr>
        <tr><td style="padding:5px 0;">Days Present</td><td style="text-align:end;">${r.present}</td></tr>
        <tr><td style="padding:5px 0;">Unpaid Leave Deduction</td><td style="text-align:end;color:#a8462e;">-${fmt(r.unpaidDeduction)}</td></tr>
        <tr><td style="padding:5px 0;">Overtime Pay (${(r.overtimeMin/60).toFixed(1)} hrs)</td><td style="text-align:end;color:#0f7a3d;">+${fmt(r.overtimePay)}</td></tr>
        ${adj.bonus ? `<tr><td style="padding:5px 0;">Bonus</td><td style="text-align:end;color:#0f7a3d;">+${fmt(adj.bonus)}</td></tr>` : ''}
        ${adj.deduction ? `<tr><td style="padding:5px 0;">Deduction</td><td style="text-align:end;color:#a8462e;">-${fmt(adj.deduction)}</td></tr>` : ''}
        ${adj.advance ? `<tr><td style="padding:5px 0;">Advance</td><td style="text-align:end;color:#a8462e;">-${fmt(adj.advance)}</td></tr>` : ''}
        <tr><td colspan="2" style="border-top:2px solid var(--forest);padding-top:8px;"></td></tr>
        <tr><td style="padding:5px 0;font-weight:800;">Net Pay</td><td style="text-align:end;font-weight:800;font-size:1.1rem;color:var(--forest-deep);">${r.netPay !== null ? fmt(r.netPay) : '—'} IQD</td></tr>
      </table>
      <div style="margin-top:16px;font-size:.7rem;color:#888;">Generated ${new Date().toLocaleDateString('en-US')} · Assumes 26 working days/month, 8-hour day, 1.5× overtime rate.</div>
    </div>`;
  document.getElementById('payslipOverlay').classList.add('open');
}
function closePayslip(){ document.getElementById('payslipOverlay').classList.remove('open'); }

function printPayslip(){
  const content = document.getElementById('payslipPrintArea').outerHTML;
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head><title>Payslip</title>
    <style>body{font-family:'IBM Plex Sans',Arial,sans-serif;padding:20px;} @media print{body{padding:0;}}</style>
    </head><body>${content}</body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 300);
}
