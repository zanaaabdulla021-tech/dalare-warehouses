/* ---- QR badge ---- */
function showQr(id){
  const row = readEmpRow(id) || employees.find(e => e.id === id) || {};
  const url = empPublicUrl(id);
  const qrSrc = 'https://api.qrserver.com/v1/create-qr-code/?size=240x240&color=0c3a1b&bgcolor=ffffff&data='
    + encodeURIComponent(url);

  document.getElementById('idfRole').textContent  = (row.job_title || '—').toUpperCase();
  document.getElementById('idfName').textContent  = row.full_name || '(no name)';
  document.getElementById('idfId').textContent    = id;
  document.getElementById('idfQrImg').src = qrSrc;

  const extraBox = document.getElementById('idfExtra');
  extraBox.innerHTML = cardLayout.front.map(fid=>{
    const def = CARD_FIELD_DEFS.find(f=>f.id===fid);
    if(!def) return '';
    return `<div class="idf-field"><b>${def.label.toUpperCase()}:</b> ${cardFieldValue(row, fid)}</div>`;
  }).join('');

  const photoBox = document.getElementById('idfPhotoBox');
  photoBox.innerHTML = row.photo ? `<img src="${row.photo}" alt="">` : 'PHOTO';

  document.getElementById('idbQrImg').src = qrSrc;

  document.getElementById('qrModal').classList.add('open');
}
function closeQr(){ document.getElementById('qrModal').classList.remove('open'); }

function printBadge(){
  const front = document.getElementById('idCardFront').outerHTML;
  const back  = document.getElementById('idCardBack').outerHTML;
  const styles = Array.from(document.querySelectorAll('style'))
    .map(s => s.innerHTML).join('\n');
  const w = window.open('', '_blank', 'width=760,height=460');
  w.document.write(`<html><head><title>Employee ID card</title>
    <style>${styles}
      body{margin:0;padding:16px;display:flex;gap:6mm;justify-content:center;background:#fff;}
      .card{box-shadow:none;border:1px solid #ccc;}
      @media print{ body{padding:0;} .card{border:none;} }
      *{-webkit-print-color-adjust:exact !important;print-color-adjust:exact !important;}
    </style></head><body>${front}${back}</body></html>`);
  w.document.close();
  setTimeout(()=>{ w.print(); }, 900);
}

/* ---- Public view when a QR code is scanned ---- */
async function checkPublicView(){
  const id = new URLSearchParams(location.search).get('emp');
  if(!id) return false;
  // public badge only — hide the whole app chrome behind it
  document.getElementById('authOverlay').classList.add('hidden');
  document.querySelector('.tabbar').style.display = 'none';
  document.querySelector('.toolbar').style.display = 'none';
  document.getElementById('userBar').style.display = 'none';
  document.querySelectorAll('.sheet').forEach(s => s.style.display = 'none');
  document.getElementById('pubWrap').classList.add('open');
  try{
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/employees_public?id=eq.${encodeURIComponent(id)}&select=*`,
      { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY } });
    const rows = await res.json();
    if(!res.ok || !rows.length){
      document.getElementById('pubName').textContent = 'Record not found';
      return true;
    }
    const e = rows[0];
    document.getElementById('pubName').textContent   = e.full_name || '—';
    document.getElementById('pubTitle').textContent  = e.job_title || '';

    let publicFields = cardLayout.public;
    try{
      const layoutRes = await fetch(`${SUPABASE_URL}/rest/v1/card_layout?id=eq.default&select=public_fields`,
        { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY } });
      if(layoutRes.ok){
        const layoutRows = await layoutRes.json();
        if(layoutRows.length && layoutRows[0].public_fields) publicFields = layoutRows[0].public_fields;
      }
    }catch(err){ /* fall back to default */ }

    document.getElementById('pubRows').innerHTML = publicFields.map(fid=>{
      const def = CARD_FIELD_DEFS.find(f=>f.id===fid);
      if(!def) return '';
      return `<div class="pub-row"><span class="k">${def.label}</span><span class="v">${cardFieldValue(e, fid)}</span></div>`;
    }).join('');

    if(e.photo){
      document.getElementById('pubLogoImg').src = e.photo;
      document.getElementById('pubAvatar').classList.add('has-photo');
    }
  }catch(err){
    document.getElementById('pubName').textContent = 'Could not load record';
  }
  return true;
}



/* =======================  PDF COLUMN CHOOSER (Invoice / Cash Flow)  ======================= */
const PRINT_COL_DEFS = {
  inv: [
    {idx:2,  label:'Date',             width:13},
    {idx:3,  label:'Invoice Number',   width:11},
    {idx:4,  label:'Price (IQD)',      width:10},
    {idx:5,  label:'Bonus (IQD)',      width:9},
    {idx:6,  label:'Cash Back (%)',    width:5},
    {idx:7,  label:'Discount (%)',     width:5},
    {idx:8,  label:'Before Discount',  width:7},
    {idx:9,  label:'After Discount',   width:7},
    {idx:10, label:'Price Verified',   width:4},
    {idx:11, label:'Bonus Verified',   width:4},
    {idx:12, label:'Qty Verified',     width:4},
    {idx:13, label:'Notes',            width:17}
  ],
  cf: [
    {idx:2, label:'Product', width:15},
    {idx:3, label:'Batch/Lot Number', width:12},
    {idx:4, label:'Items per Package', width:11},
    {idx:5, label:'Cash Flow', width:13},
    {idx:6, label:'Stock Dalare', width:13},
    {idx:7, label:'Note', width:24}
  ]
};

let printColumns = { inv: [], cf: [] }; // arrays of HIDDEN column indices

async function loadPrintColumns(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/print_columns?select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    rows.forEach(r=>{ if(printColumns[r.tab] !== undefined) printColumns[r.tab] = r.hidden || []; });
  }catch(e){ /* keep defaults (show everything) */ }
}


/* =======================  EXTRA COLUMNS (Invoice / Cash Flow)  ======================= */
let extraColumns = { inv: [], cf: [] };

/* =======================  RESIZABLE TABLE COLUMNS (Invoice / Cash Flow)  ======================= */
function makeColumnsResizable(tableSel, storageKey){
  const table = document.querySelector(tableSel);
  if(!table) return;
  const headerRow = table.querySelector('thead tr');
  if(!headerRow) return;

  headerRow.querySelectorAll('.col-resize-handle').forEach(h => h.remove());
  const allThs = Array.from(headerRow.children);
  const resizableThs = allThs.slice(1, allThs.length - 1); // skip row-num and trailing action column

  function recalcTableWidth(){
    // Sum every column's actual rendered width so the table can grow past its
    // container (wrapper scrolls) instead of squeezing sibling columns.
    const total = allThs.reduce((sum, th) => sum + th.offsetWidth, 0);
    if(total > 0) table.style.width = total + 'px';
  }

  let saved = {};
  try{ saved = JSON.parse(localStorage.getItem(storageKey) || '{}'); }catch(e){}
  resizableThs.forEach((th, i) => {
    if(saved[i]) th.style.width = saved[i] + 'px';
  });
  requestAnimationFrame(recalcTableWidth);

  resizableThs.forEach(th => {
    const handle = document.createElement('div');
    handle.className = 'col-resize-handle';
    th.appendChild(handle);

    let startX = 0, startWidth = 0;
    const onMove = (e) => {
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const newWidth = Math.max(40, Math.round(startWidth + (clientX - startX)));
      th.style.width = newWidth + 'px';
    };
    const onUp = () => {
      handle.classList.remove('resizing');
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onUp);
      recalcTableWidth();
      let widths = {};
      try{ widths = JSON.parse(localStorage.getItem(storageKey) || '{}'); }catch(e){}
      resizableThs.forEach((t, idx) => { widths[idx] = t.offsetWidth; });
      try{ localStorage.setItem(storageKey, JSON.stringify(widths)); }catch(e){}
    };
    const onStart = (e) => {
      e.preventDefault();
      e.stopPropagation();
      // Freeze every sibling column at its current pixel width first, so this
      // drag only changes the one column being resized — none of the others move.
      allThs.forEach(t => { if(t !== th) t.style.width = t.offsetWidth + 'px'; });
      startX = e.touches ? e.touches[0].clientX : e.clientX;
      startWidth = th.offsetWidth;
      handle.classList.add('resizing');
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      document.addEventListener('touchmove', onMove, {passive:false});
      document.addEventListener('touchend', onUp);
    };
    handle.addEventListener('mousedown', onStart);
    handle.addEventListener('touchstart', onStart, {passive:false});
  });
}

function extraColCells(tab){
  return (extraColumns[tab] || []).map(f =>
    `<td data-extra-cell="${f.id}"><input type="${f.type === 'number' ? 'text' : 'text'}" data-extra="${f.id}"${f.type==='date' ? ' placeholder="dd/mm/yyyy"' : ''}></td>`
  ).join('');
}

async function loadExtraColumns(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/extra_columns?select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    rows.forEach(r => { if(extraColumns[r.tab] !== undefined) extraColumns[r.tab] = r.fields || []; });
    rebuildExtraColumnsUI('inv');
    rebuildExtraColumnsUI('cf');
  }catch(e){ /* keep defaults (no extra columns) */ }
}

function rebuildExtraColumnsUI(tab){
  const anchorId = tab === 'inv' ? 'invExtraHead' : 'cfExtraHead';
  const anchor = document.getElementById(anchorId);
  if(!anchor) return;

  let sib = anchor.previousElementSibling;
  while(sib && sib.classList.contains('extra-th')){
    const toRemove = sib;
    sib = sib.previousElementSibling;
    toRemove.remove();
  }
  (extraColumns[tab] || []).forEach(f=>{
    const th = document.createElement('th');
    th.className = 'extra-th';
    th.textContent = f.label;
    anchor.parentElement.insertBefore(th, anchor);
  });

  const bodyId = tab === 'inv' ? 'priceBody' : 'cashBody';
  const body = document.getElementById(bodyId);
  if(!body) return;
  Array.from(body.querySelectorAll('tr')).forEach(tr=>{
    Array.from(tr.querySelectorAll('td[data-extra-cell]')).forEach(td=>{
      const fid = td.dataset.extraCell;
      if(!(extraColumns[tab]||[]).some(f=>f.id===fid)) td.remove();
    });
    const lastTd = tr.lastElementChild;
    (extraColumns[tab]||[]).forEach(f=>{
      if(!tr.querySelector(`td[data-extra-cell="${f.id}"]`)){
        const td = document.createElement('td');
        td.dataset.extraCell = f.id;
        td.innerHTML = `<input type="text" data-extra="${f.id}"${f.type==='date' ? ' placeholder="dd/mm/yyyy"' : ''}>`;
        tr.insertBefore(td, lastTd);
      }
    });
  });
  const storageKey = tab === 'inv' ? 'dalare-col-widths-inv' : 'dalare-col-widths-cf';
  const tableSel = tab === 'inv' ? '#form table.pricelist' : '#cfForm table.pricelist';
  makeColumnsResizable(tableSel, storageKey);
}

function updateColumnMgrButton(){
  const btn = document.getElementById('colMgrBtn');
  if(!btn) return;
  const relevant = activeTab === 'inv' || activeTab === 'cf';
  btn.style.display = (relevant && isAdmin()) ? 'inline-block' : 'none';
}

function openColumnManager(){
  if(!isAdmin()){ flash('Managers only.', true); return; }
  if(activeTab !== 'inv' && activeTab !== 'cf'){ flash('Open Invoice or Cash Flow first.', true); return; }
  document.getElementById('cmTitle').textContent =
    'Manage Columns — ' + (activeTab === 'inv' ? 'Invoice Verification' : 'Cash Flow');
  document.getElementById('cmHint').textContent = activeTab === 'inv'
    ? "Add extra columns here. The built-in pricing columns (Price, Bonus, Cash Back, Discount, totals) are protected and can't be removed, since the calculations depend on them."
    : 'Add or remove extra columns for this table.';
  renderColumnManagerList();
  document.getElementById('cmOverlay').classList.add('open');
}
function closeColumnManager(){ document.getElementById('cmOverlay').classList.remove('open'); }

function renderColumnManagerList(){
  const box = document.getElementById('cmExisting');
  const fields = extraColumns[activeTab] || [];
  if(!fields.length){ box.innerHTML = '<div class="mgr-empty">No extra columns yet.</div>'; return; }
  box.innerHTML = fields.map(f => `
    <div class="cd-field-row">
      <label style="flex:1;">${f.label.replace(/</g,'&lt;')} <span style="color:#888;font-weight:600;">(${f.type})</span></label>
      <button class="sb-del" onclick="removeExtraColumnField('${f.id}')">×</button>
    </div>
  `).join('');
}

function addExtraColumnField(){
  const label = document.getElementById('cmNewLabel').value.trim();
  const type = document.getElementById('cmNewType').value;
  if(!label){ flash('Enter a column name.', true); return; }
  const id = 'x' + Math.random().toString(36).slice(2,8);
  extraColumns[activeTab] = [...(extraColumns[activeTab]||[]), {id, label, type}];
  document.getElementById('cmNewLabel').value = '';
  renderColumnManagerList();
  saveExtraColumnsConfig();
}

function removeExtraColumnField(id){
  if(!confirm('Remove this column? Any data already entered in it will be lost when you save.')) return;
  extraColumns[activeTab] = (extraColumns[activeTab]||[]).filter(f=>f.id!==id);
  renderColumnManagerList();
  saveExtraColumnsConfig();
}

async function saveExtraColumnsConfig(){
  const tab = activeTab;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/extra_columns`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ tab, fields: extraColumns[tab], updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    rebuildExtraColumnsUI(tab);
    logActivity('save_extra_columns', null, `${tab}: ${extraColumns[tab].map(f=>f.label).join(',')}`);
    flash('Columns updated');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function updatePdfColsButton(){
  const btn = document.getElementById('pdfColsBtn');
  if(!btn) return;
  const relevant = activeTab === 'inv' || activeTab === 'cf';
  btn.style.display = (relevant && isAdmin()) ? 'inline-block' : 'none';
}

function openPrintColumnsDesigner(){
  if(!isAdmin()){ flash('Managers only.', true); return; }
  if(activeTab !== 'inv' && activeTab !== 'cf'){ flash('Open Invoice or Cash Flow first.', true); return; }
  document.getElementById('pcTitle').textContent =
    'PDF Columns — ' + (activeTab === 'inv' ? 'Invoice Verification' : 'Cash Flow');
  const container = document.getElementById('pcFields');
  container.innerHTML = '';
  const hidden = printColumns[activeTab] || [];
  PRINT_COL_DEFS[activeTab].forEach(def=>{
    const row = document.createElement('div');
    row.className = 'cd-field-row';
    row.dataset.idx = def.idx;
    row.innerHTML = `<label><input type="checkbox" ${hidden.includes(def.idx) ? '' : 'checked'}> ${def.label}</label>`;
    container.appendChild(row);
  });
  document.getElementById('pcOverlay').classList.add('open');
}
function closePrintColumnsDesigner(){ document.getElementById('pcOverlay').classList.remove('open'); }

async function savePrintColumnsConfig(){
  const tab = activeTab;
  const hidden = Array.from(document.querySelectorAll('#pcFields .cd-field-row'))
    .filter(row => !row.querySelector('input[type=checkbox]').checked)
    .map(row => parseInt(row.dataset.idx, 10));
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/print_columns`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ tab, hidden, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    printColumns[tab] = hidden;
    closePrintColumnsDesigner();
    logActivity('save_print_columns', null, `${tab}: hide ${hidden.join(',')}`);
    flash('PDF column settings saved');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function detectEmptyColumns(tab){
  const tableSel = tab === 'inv' ? '#form table.pricelist' : '#cfForm table.pricelist';
  const table = document.querySelector(tableSel);
  if(!table) return [];
  const bodyRows = Array.from(table.querySelectorAll('tbody tr'));
  if(!bodyRows.length) return [];
  const defs = PRINT_COL_DEFS[tab];
  const empty = [];
  defs.forEach(d => {
    // idx is 1-based across <td> including the row-num cell, so the (idx-1)th <td> matches.
    const allEmpty = bodyRows.every(tr => {
      const cell = tr.children[d.idx - 1];
      if(!cell) return true;
      const inputs = cell.querySelectorAll('input, textarea');
      if(!inputs.length) return !cell.textContent.trim();
      return Array.from(inputs).every(isEmptyInput);
    });
    if(allEmpty) empty.push(d.idx);
  });
  return empty;
}

function applyPrintColumnOverrides(){
  removePrintColumnOverrides();
  const tab = activeTab;
  if(tab !== 'inv' && tab !== 'cf') return;
  const manualHidden = printColumns[tab] || [];
  const autoEmpty = detectEmptyColumns(tab);
  const hidden = [...new Set([...manualHidden, ...autoEmpty])];
  const extras = extraColumns[tab] || [];
  if(!hidden.length && !extras.length) return;

  const tableSel = tab === 'inv' ? '#form table.pricelist' : '#cfForm table.pricelist';
  const defs = PRINT_COL_DEFS[tab];
  let css = '';
  hidden.forEach(idx=>{
    css += `${tableSel} th:nth-child(${idx}), ${tableSel} td:nth-child(${idx}){display:none !important;}\n`;
  });

  // Compute a fair width share for every still-visible column, built-in or extra.
  const fallbackWeight = defs.length ? (100 / defs.length) : 10;
  const visibleDefs = defs.filter(d => !hidden.includes(d.idx))
    .map(d => ({ idx: d.idx, weight: d.width || fallbackWeight }));

  const lastBuiltinIdx = Math.max(...defs.map(d=>d.idx));
  const extraDefs = extras.map((f,i) => ({ idx: lastBuiltinIdx + 1 + i, weight: fallbackWeight }));

  const allVisible = [...visibleDefs, ...extraDefs];
  const totalWeight = allVisible.reduce((s,d)=>s+d.weight, 0);
  if(totalWeight > 0){
    allVisible.forEach(d=>{
      const pct = (d.weight / totalWeight * 100).toFixed(2);
      css += `${tableSel} th:nth-child(${d.idx}), ${tableSel} td:nth-child(${d.idx}){width:${pct}% !important;}\n`;
    });
  }

  const style = document.createElement('style');
  style.id = 'printColOverride';
  document.head.appendChild(style);
  style.textContent = css;
}
function removePrintColumnOverrides(){
  const el = document.getElementById('printColOverride');
  if(el) el.remove();
}
