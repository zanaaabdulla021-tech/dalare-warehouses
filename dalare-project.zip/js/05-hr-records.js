// ===================== HR Records: Assets, Expenses, Disciplinary, Training =====================
let assetsCache = [], expensesCache = [], disciplinaryCache = [], trainingCache = [];

async function loadHrRecordsTab(){
  await Promise.all([loadAssets(), loadExpenses(), loadDisciplinary(), loadTraining()]);
}

// ---- Assets ----
async function loadAssets(){
  const body = document.getElementById('assetsBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/assets?select=*&deleted_at=is.null&order=assigned_date.desc`, { headers: sbHeaders() });
    assetsCache = res.ok ? await res.json() : [];
    renderAssets();
  }catch(e){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">'+sbError(e)+'</td></tr>'; }
}
function renderAssets(){
  const body = document.getElementById('assetsBody');
  const canManage = isSuperAdmin() || session.role === 'admin';
  if(!assetsCache.length){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;padding:14px;">No assets recorded yet.</td></tr>'; return; }
  body.innerHTML = assetsCache.map(a => `
    <tr data-asset-id="${a.id}">
      <td><input value="${(a.name||'').replace(/"/g,'&quot;')}" data-f="name" ${canManage?'':'readonly'}></td>
      <td><input value="${(a.serial||'').replace(/"/g,'&quot;')}" data-f="serial" ${canManage?'':'readonly'}></td>
      <td><input value="${(a.assigned_to||'').replace(/"/g,'&quot;')}" data-f="assigned_to" list="employeeNamesList" ${canManage?'':'readonly'}></td>
      <td><input type="date" value="${a.assigned_date||''}" data-f="assigned_date" ${canManage?'':'readonly'}></td>
      <td><select data-f="status" ${canManage?'':'disabled'}>
        <option ${a.status==='in_use'?'selected':''} value="in_use">In Use</option>
        <option ${a.status==='returned'?'selected':''} value="returned">Returned</option>
        <option ${a.status==='lost'?'selected':''} value="lost">Lost/Damaged</option>
      </select></td>
      <td>${canManage ? `<button class="btn-small" onclick="saveAssetRow('${a.id}')">Save</button>
        <button class="btn-small remove" onclick="deleteAsset('${a.id}')">×</button>` : ''}</td>
    </tr>`).join('');
}
function addBlankAssetRow(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can manage assets.', true); return; }
  const tempId = 'new-' + Date.now().toString(36);
  assetsCache.unshift({ id: tempId, name:'', serial:'', assigned_to:'', assigned_date: new Date().toISOString().slice(0,10), status:'in_use' });
  renderAssets();
}
async function saveAssetRow(id){
  const tr = document.querySelector(`#assetsBody tr[data-asset-id="${id}"]`);
  if(!tr) return;
  const name = tr.querySelector('[data-f="name"]').value.trim();
  const serial = tr.querySelector('[data-f="serial"]').value.trim();
  const assigned_to = tr.querySelector('[data-f="assigned_to"]').value.trim();
  const assigned_date = tr.querySelector('[data-f="assigned_date"]').value;
  const status = tr.querySelector('[data-f="status"]').value;
  if(!name){ flash('Enter an asset name.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  const realId = id.startsWith('new-') ? 'asset-'+Date.now().toString(36) : id;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/assets`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id: realId, name, serial, assigned_to, assigned_date, status })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Saved ✓');
    loadAssets();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function deleteAsset(id){
  if(!confirm('Move this asset record to Trash?')) return;
  await softDelete('assets', id, loadAssets);
}
function exportAssetsExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load.', true); return; }
  if(!assetsCache.length){ flash('Nothing to export.', true); return; }
  const rows = assetsCache.map(a => ({ 'Asset': a.name, 'Serial #': a.serial, 'Assigned To': a.assigned_to, 'Assigned Date': a.assigned_date, 'Status': a.status }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Assets');
  XLSX.writeFile(wb, `assets-${new Date().toISOString().slice(0,10)}.xlsx`);
}

// ---- Expense Reimbursement ----
function openExpenseForm(){
  document.getElementById('expEmployee').value = '';
  document.getElementById('expCategory').value = 'Travel';
  document.getElementById('expAmount').value = '';
  document.getElementById('expDate').value = new Date().toISOString().slice(0,10);
  document.getElementById('expNote').value = '';
  document.getElementById('expenseFormOverlay').classList.add('open');
}
function closeExpenseForm(){ document.getElementById('expenseFormOverlay').classList.remove('open'); }
async function submitExpense(){
  const employee_name = document.getElementById('expEmployee').value.trim();
  const category = document.getElementById('expCategory').value;
  const amount = parseFloat(document.getElementById('expAmount').value) || 0;
  const date = document.getElementById('expDate').value;
  const note = document.getElementById('expNote').value.trim();
  if(!employee_name || !amount || !date){ flash('Fill in employee, amount, and date.', true); return; }
  if(amount < 0){ flash('Amount can\'t be negative.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/expenses`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ id:'exp-'+Date.now().toString(36), employee_name, category, amount, date, note: note||null, status:'pending', requested_by: session.email, requested_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('request_expense', null, employee_name);
    flash('Reimbursement request submitted ✓');
    closeExpenseForm();
    loadExpenses();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function loadExpenses(){
  const body = document.getElementById('expensesBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/expenses?select=*&deleted_at=is.null&order=requested_at.desc&limit=100`, { headers: sbHeaders() });
    expensesCache = res.ok ? await res.json() : [];
    renderExpenses();
  }catch(e){ body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#888;">'+sbError(e)+'</td></tr>'; }
}
function renderExpenses(){
  const body = document.getElementById('expensesBody');
  const statusFilter = document.getElementById('expenseStatusFilter').value;
  let rows = expensesCache;
  if(statusFilter) rows = rows.filter(r => r.status === statusFilter);
  const canManage = isSuperAdmin() || session.role === 'admin';
  const statusColors = { pending:'#b9770e', approved:'#0f7a3d', rejected:'#a8462e' };
  if(!rows.length){ body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#888;padding:14px;">No expense requests found.</td></tr>'; return; }
  body.innerHTML = rows.map(r => {
    const color = statusColors[r.status]||'#555';
    const actions = (canManage && r.status === 'pending')
      ? `<button class="btn-small" onclick="approveExpense('${r.id}')">✓</button><button class="btn-small remove" onclick="rejectExpense('${r.id}')">✕</button>`
      : (canManage ? `<button class="btn-small remove" onclick="deleteExpense('${r.id}')">×</button>` : '');
    return `<tr>
      <td>${(r.employee_name||'').replace(/</g,'&lt;')}</td><td>${r.category||''}</td><td>${(r.amount||0).toLocaleString()}</td>
      <td>${r.date||''}</td><td style="max-width:160px;">${r.note?String(r.note).replace(/</g,'&lt;'):'—'}</td>
      <td><span style="background:${color}1a;color:${color};padding:2px 8px;border-radius:999px;font-weight:700;font-size:.72rem;">${r.status}</span></td>
      <td>${actions}</td>
    </tr>`;
  }).join('');
}
async function approveExpense(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can approve.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/expenses?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ status:'approved', approved_by: session.email, approved_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Approved ✓'); loadExpenses();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function rejectExpense(id){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can reject.', true); return; }
  if(!confirm('Reject this reimbursement request?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/expenses?id=eq.${encodeURIComponent(id)}`, {
      method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ status:'rejected', approved_by: session.email, approved_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Rejected'); loadExpenses();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function deleteExpense(id){
  if(!confirm('Move this record to Trash?')) return;
  await softDelete('expenses', id, loadExpenses);
}
function exportExpensesExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load.', true); return; }
  if(!expensesCache.length){ flash('Nothing to export.', true); return; }
  const rows = expensesCache.map(r => ({ 'Employee': r.employee_name, 'Category': r.category, 'Amount': r.amount, 'Date': r.date, 'Note': r.note||'', 'Status': r.status }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Expenses');
  XLSX.writeFile(wb, `expenses-${new Date().toISOString().slice(0,10)}.xlsx`);
}

// ---- Disciplinary Records ----
async function loadDisciplinary(){
  const body = document.getElementById('disciplinaryBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/disciplinary_records?select=*&deleted_at=is.null&order=date.desc`, { headers: sbHeaders() });
    disciplinaryCache = res.ok ? await res.json() : [];
    renderDisciplinary();
  }catch(e){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">'+sbError(e)+'</td></tr>'; }
}
function renderDisciplinary(){
  const body = document.getElementById('disciplinaryBody');
  const canManage = isSuperAdmin() || session.role === 'admin';
  if(!disciplinaryCache.length){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;padding:14px;">No records yet.</td></tr>'; return; }
  body.innerHTML = disciplinaryCache.map(d => `
    <tr>
      <td>${(d.employee_name||'').replace(/</g,'&lt;')}</td>
      <td>${d.date||''}</td>
      <td>${d.type||''}</td>
      <td style="max-width:220px;">${(d.description||'').replace(/</g,'&lt;')}</td>
      <td>${(d.issued_by||'').replace(/</g,'&lt;')}</td>
      <td>${canManage ? `<button class="btn-small remove" onclick="deleteDisciplinary('${d.id}')">×</button>` : ''}</td>
    </tr>`).join('');
}
function addBlankDisciplinaryRow(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can add disciplinary records.', true); return; }
  const employee_name = prompt('Employee name');
  if(!employee_name || !employee_name.trim()) return;
  const type = prompt('Type (e.g. Verbal Warning, Written Warning, Suspension)', 'Verbal Warning');
  if(!type) return;
  const description = prompt('Description');
  if(description === null) return;
  saveDisciplinaryRecord({ employee_name: employee_name.trim(), type, description });
}
async function saveDisciplinaryRecord({ employee_name, type, description }){
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/disciplinary_records`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ id:'disc-'+Date.now().toString(36), employee_name, type, description: description||null, date: new Date().toISOString().slice(0,10), issued_by: session.email })
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('add_disciplinary', null, employee_name);
    flash('Record added ✓');
    loadDisciplinary();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function deleteDisciplinary(id){
  if(!confirm('Move this record to Trash?')) return;
  await softDelete('disciplinary_records', id, loadDisciplinary);
}

// ---- Training & Certifications ----
async function loadTraining(){
  const body = document.getElementById('trainingBody');
  if(!backendReady()){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">Backend not configured.</td></tr>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/trainings?select=*&deleted_at=is.null&order=expiry_date.asc`, { headers: sbHeaders() });
    trainingCache = res.ok ? await res.json() : [];
    renderTraining();
  }catch(e){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;">'+sbError(e)+'</td></tr>'; }
}
function renderTraining(){
  const body = document.getElementById('trainingBody');
  const canManage = isSuperAdmin() || session.role === 'admin';
  if(!trainingCache.length){ body.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888;padding:14px;">No certifications recorded yet.</td></tr>'; return; }
  const today = new Date().toISOString().slice(0,10);
  const in30 = new Date(Date.now() + 30*86400000).toISOString().slice(0,10);
  body.innerHTML = trainingCache.map(t => {
    let statusLabel = 'Valid', color = '#0f7a3d';
    if(t.expiry_date && t.expiry_date < today){ statusLabel = 'Expired'; color = '#a8462e'; }
    else if(t.expiry_date && t.expiry_date <= in30){ statusLabel = 'Expiring Soon'; color = '#b9770e'; }
    return `<tr>
      <td>${(t.employee_name||'').replace(/</g,'&lt;')}</td>
      <td>${(t.certification||'').replace(/</g,'&lt;')}</td>
      <td>${t.issued_date||''}</td>
      <td>${t.expiry_date||'—'}</td>
      <td><span style="background:${color}1a;color:${color};padding:2px 8px;border-radius:999px;font-weight:700;font-size:.72rem;">${statusLabel}</span></td>
      <td>${canManage ? `<button class="btn-small remove" onclick="deleteTraining('${t.id}')">×</button>` : ''}</td>
    </tr>`;
  }).join('');
}
function addBlankTrainingRow(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can add certifications.', true); return; }
  const employee_name = prompt('Employee name');
  if(!employee_name || !employee_name.trim()) return;
  const certification = prompt('Certification name');
  if(!certification || !certification.trim()) return;
  const issued_date = prompt('Issued date (YYYY-MM-DD)', new Date().toISOString().slice(0,10));
  if(issued_date === null) return;
  const expiry_date = prompt('Expiry date (YYYY-MM-DD, leave blank if none)', '');
  if(expiry_date === null) return;
  saveTrainingRecord({ employee_name: employee_name.trim(), certification: certification.trim(), issued_date, expiry_date: expiry_date || null });
}
async function saveTrainingRecord({ employee_name, certification, issued_date, expiry_date }){
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/trainings`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify({ id:'train-'+Date.now().toString(36), employee_name, certification, issued_date, expiry_date })
    });
    if(!res.ok) throw new Error(await res.text());
    flash('Certification added ✓');
    loadTraining();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
async function deleteTraining(id){
  if(!confirm('Move this certification record to Trash?')) return;
  await softDelete('trainings', id, loadTraining);
}

function exportPayrollExcel(){
  if(typeof XLSX === 'undefined'){ flash('Excel library failed to load. Check your connection and try again.', true); return; }
  if(!payrollReportCache.length){ flash('Nothing to export — pick a month with data first.', true); return; }
  const month = document.getElementById('attReportMonth').value;
  const rows = payrollReportCache.map(r => ({
    'Employee': r.employee, 'Days Present': r.present, 'Total Hours': formatMinutes(r.minutes),
    'Overtime (hrs)': (r.overtimeMin/60).toFixed(1), 'Late (times)': r.late, 'Absences': r.absent,
    'Paid Leave (days)': r.paidDays, 'Unpaid Leave (days)': r.unpaidDays,
    'Base Salary': r.baseSalary || '', 'Unpaid Deduction': r.baseSalary ? Math.round(r.unpaidDeduction) : '',
    'Overtime Pay': r.baseSalary ? Math.round(r.overtimePay) : '', 'Net Pay': r.netPay !== null ? Math.round(r.netPay) : ''
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Payroll Summary');
  XLSX.writeFile(wb, `payroll-summary-${month}.xlsx`);
}

async function markAbsentees(){
  if(!isSuperAdmin() && session.role !== 'admin'){ flash('Only a manager can mark absentees.', true); return; }
  const date = document.getElementById('attDateFilter').value;
  if(!date){ flash('Pick a date first.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const [empRes, attRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/employees?select=full_name&status=eq.Active`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/attendance?select=employee_name&date=eq.${date}`, { headers: sbHeaders() })
    ]);
    const empRows = empRes.ok ? await empRes.json() : [];
    const attRows = attRes.ok ? await attRes.json() : [];
    const recordedNames = new Set(attRows.map(r => r.employee_name));
    const missing = empRows.filter(e => e.full_name && !recordedNames.has(e.full_name));

    if(!missing.length){ flash('Every active employee already has a record for this date.'); return; }
    if(!confirm(`Mark ${missing.length} employee(s) as absent for ${date}? (Anyone without a check-in today.)`)) return;

    for(const e of missing){
      await fetch(`${SUPABASE_URL}/rest/v1/attendance`, {
        method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({
          id: 'att-absent-'+date+'-'+e.full_name.toLowerCase().replace(/[^a-z0-9]+/g,'-'),
          employee_name: e.full_name, date, status: 'absent', verification_method: 'manual', updated_at: new Date().toISOString()
        })
      });
    }
    logActivity('mark_absentees', null, `${missing.length} on ${date}`);
    flash(`${missing.length} employee(s) marked absent ✓`);
    loadAttendanceRecords();
    loadAttendanceDashboard();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadAttendanceDashboard(){
  if(!backendReady()) return;
  const today = new Date().toISOString().slice(0,10);
  try{
    const [attRes, empRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/attendance?select=*&deleted_at=is.null&date=eq.${today}`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/employees?select=id&status=eq.Active`, { headers: sbHeaders() }).catch(()=>null)
    ]);
    const todayRecords = attRes.ok ? await attRes.json() : [];
    const totalEmployees = empRes && empRes.ok ? (await empRes.json()).length : null;

    const present = todayRecords.filter(r => r.status === 'present' || r.status === 'late' || r.status === 'missing_checkout').length;
    const late = todayRecords.filter(r => r.status === 'late').length;
    const earlyLeave = todayRecords.filter(r => r.early_leave_minutes > 0).length;
    const totalMinutes = todayRecords.reduce((s,r) => s + (r.working_minutes||0), 0);
    const absent = totalEmployees !== null ? Math.max(0, totalEmployees - present) : todayRecords.filter(r => r.status === 'absent').length;

    document.getElementById('attPresentCount').textContent = present;
    document.getElementById('attAbsentCount').textContent = absent;
    document.getElementById('attLateCount').textContent = late;
    document.getElementById('attEarlyLeaveCount').textContent = earlyLeave;
    document.getElementById('attTotalHours').textContent = formatMinutes(totalMinutes);
  }catch(e){ /* dashboard is a nice-to-have */ }
}

async function loadStaffDeptListOnly(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?select=department`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    const depts = [...new Set(rows.map(e => e.department).filter(Boolean))];
    const deptList = document.getElementById('staffDeptList');
    if(deptList) deptList.innerHTML = depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">`).join('');
  }catch(e){ /* nice-to-have, fail silently */ }
}

async function loadEmployees(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?select=*&order=full_name`,
      { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    employees = await res.json();
    const depts = [...new Set(employees.map(e => e.department).filter(Boolean))];
    const deptList = document.getElementById('staffDeptList');
    if(deptList) deptList.innerHTML = depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">`).join('');
    const deptFilterSel = document.getElementById('empDeptFilter');
    if(deptFilterSel){
      const current = deptFilterSel.value;
      deptFilterSel.innerHTML = '<option value="">All departments</option>' + depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">${d.replace(/</g,'&lt;')}</option>`).join('');
      deptFilterSel.value = current;
    }
    renderEmployees();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function renderEmployees(){
  const q = (document.getElementById('empSearch').value || '').toLowerCase().trim();
  const deptFilter = document.getElementById('empDeptFilter').value;
  let list = employees;
  if(deptFilter) list = list.filter(e => e.department === deptFilter);
  if(q){
    list = list.filter(e =>
      (e.full_name||'').toLowerCase().includes(q) ||
      (e.department||'').toLowerCase().includes(q) ||
      (e.id||'').toLowerCase().includes(q));
  }
  const body = document.getElementById('empBody');
  if(!list.length){
    body.innerHTML = '<tr><td colspan="10" style="text-align:center;color:#777;padding:16px;">No employees yet.</td></tr>';
    return;
  }
  body.innerHTML = list.map(e => `<tr data-id="${e.id}">
    <td>
      <div class="emp-photo-cell no-print" onclick="document.getElementById('photoInput_${e.id}').click()">
        ${e.photo ? `<img src="${e.photo}" class="emp-thumb" alt="">` : `<span class="emp-thumb-placeholder">＋</span>`}
      </div>
      ${e.photo ? `<img src="${e.photo}" class="emp-thumb print-only" alt="">` : ''}
      <input type="file" accept="image/*" id="photoInput_${e.id}" style="display:none;" onchange="handlePhotoUpload(event,'${e.id}')">
    </td>
    <td style="font-family:'IBM Plex Mono',monospace;font-weight:700;">${e.id}</td>
    <td><input value="${(e.full_name||'').replace(/"/g,'&quot;')}" data-f="full_name"></td>
    <td><select data-f="gender">
      <option value="" ${!e.gender?'selected':''}>—</option>
      <option value="Male" ${e.gender==='Male'?'selected':''}>Male</option>
      <option value="Female" ${e.gender==='Female'?'selected':''}>Female</option>
    </select></td>
    <td><input value="${e.age||''}" data-f="age" style="width:46px;"></td>
    <td><input value="${(e.job_title||'').replace(/"/g,'&quot;')}" data-f="job_title"></td>
    <td><input value="${(e.department||'').replace(/"/g,'&quot;')}" data-f="department" list="staffDeptList"></td>
    <td><input value="${(e.phone||'').replace(/"/g,'&quot;')}" data-f="phone"></td>
    <td><input type="email" value="${(e.email||'').replace(/"/g,'&quot;')}" data-f="email" placeholder="login@email.com"></td>
    <td><input value="${(e.start_date||'').replace(/"/g,'&quot;')}" data-f="start_date" placeholder="dd/mm/yyyy"></td>
    <td><input type="number" min="0" value="${e.base_salary||''}" data-f="base_salary" placeholder="0" style="width:90px;"></td>
    <td><div class="emp-actions no-print">
      <button class="btn-save-emp" onclick="saveEmployee('${e.id}')">Save</button>
      <button class="btn-qr" onclick="openEmployeeProfile('${e.id}')" style="background:#1d4ed8;">Profile</button>
      <button class="btn-qr" onclick="showQr('${e.id}')">QR</button>
      ${isSuperAdmin() ? `<button class="btn-del-emp" onclick="deleteEmployee('${e.id}')">×</button>` : ''}
    </div></td>
  </tr>`).join('');
}

function handlePhotoUpload(evt, id){
  const file = evt.target.files[0];
  if(!file) return;
  if(file.size > 800*1024){ flash('Image too large — pick one under 800KB.', true); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const emp = employees.find(e => e.id === id);
    if(emp) emp.photo = reader.result;
    const cell = document.querySelector(`#empBody tr[data-id="${id}"] .emp-photo-cell`);
    if(cell) cell.innerHTML = `<img src="${reader.result}" class="emp-thumb" alt="">`;
    flash('Photo attached — press Save to keep it.');
  };
  reader.readAsDataURL(file);
}

function addEmployee(){
  employees.unshift({ id: makeEmpId(), full_name:'', age:'', gender:'', job_title:'', department:'', phone:'', start_date:'', base_salary:'', photo:'' });
  document.getElementById('empSearch').value = '';
  renderEmployees();
}

function readEmpRow(id){
  const tr = document.querySelector(`#empBody tr[data-id="${id}"]`);
  if(!tr) return null;
  const out = { id };
  tr.querySelectorAll('input[data-f], select[data-f]').forEach(i=>{ out[i.dataset.f] = i.value.trim(); });
  out.age = out.age === '' ? null : parseInt(out.age, 10) || null;
  out.base_salary = out.base_salary === '' ? null : parseFloat(out.base_salary) || null;
  const existing = employees.find(e => e.id === id);
  out.photo = existing ? (existing.photo || '') : '';
  return out;
}

async function saveEmployee(id){
  const row = readEmpRow(id);
  if(!row) return;
  if(!row.full_name){ flash('Enter the employee name first.', true); return; }
  if(row.base_salary !== null && row.base_salary < 0){ flash('Base Salary can\'t be negative.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(Object.assign(row, { updated_at: new Date().toISOString() }))
    });
    if(!res.ok) throw new Error(await res.text());
    const i = employees.findIndex(e => e.id === id);
    if(i >= 0) employees[i] = Object.assign(employees[i], row);
    logActivity('save_employee', id, row.full_name);
    flash('Saved ✓ ' + row.full_name);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function deleteEmployee(id){
  if(!isSuperAdmin()){ flash('Only a super admin can delete employees.', true); return; }
  if(!confirm('Permanently delete this employee record?')) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?id=eq.${encodeURIComponent(id)}`,
      { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    employees = employees.filter(e => e.id !== id);
    renderEmployees();
    logActivity('delete_employee', id);
    flash('Deleted ' + id);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
