/* =======================  CUSTOM SECTIONS (super_admin builder)  ======================= */
let customSections = {};   // id -> {id, name, fields, created_by}
let customRowCounts = {};  // id -> row counter
let customFormIds = {};    // id -> current Form ID
let customSectionsLoaded = false;


/* =======================  TAB ORDER (super_admin)  ======================= */
let tabOrder = ['inv','cf','sop','staff'];

function tabIdLabel(id){
  if(id === 'inv') return 'Invoice Verification';
  if(id === 'cf') return 'Cash Flow';
  if(id === 'sop') return 'SOP';
  if(id === 'staff') return 'Employees';
  if(id === 'kpi') return 'KPI Evaluation';
  if(id.startsWith('custom:')) return (customSections[id.slice(7)] || {}).name || id;
  return id;
}

function tabIdButton(id){
  if(id === 'inv') return document.getElementById('tabInv');
  if(id === 'cf') return document.getElementById('tabCf');
  if(id === 'sop') return document.getElementById('tabSop');
  if(id === 'staff') return document.getElementById('tabStaff');
  if(id === 'kpi') return document.getElementById('tabKpi');
  if(id.startsWith('custom:')) return document.getElementById('tab_custom_' + id.slice(7));
  return null;
}

function currentTabIds(){
  const customIds = Object.keys(customSections).map(id => 'custom:' + id);
  return ['inv','cf','sop','staff','kpi', ...customIds];
}

async function loadTabOrder(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/tab_order?id=eq.default&select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(rows.length && rows[0].order) tabOrder = rows[0].order;
    applyTabOrder();
    renderHomeGrid();
  }catch(e){ /* keep default order */ }
}

function applyTabOrder(){
  const bar = document.querySelector('.tabbar');
  if(!bar) return;
  const all = currentTabIds();
  const ordered = [...tabOrder.filter(id => all.includes(id)), ...all.filter(id => !tabOrder.includes(id))];
  ordered.forEach(id=>{
    const btn = tabIdButton(id);
    if(btn) bar.appendChild(btn);
  });
  // keep the Settings menu at the very end, after all tabs
  const settingsWrap = document.getElementById('settingsMenuWrap');
  if(settingsWrap) bar.appendChild(settingsWrap);
}

function updateReorderTabsButton(){
  const wrap = document.getElementById('settingsMenuWrap');
  if(wrap) wrap.style.display = isSuperAdmin() ? '' : 'none';
}

const I18N = {
  en: {
    'nav.home':'Home', 'nav.search':'Search All Forms', 'nav.inv':'Invoice Verification', 'nav.cf':'Cash Flow',
    'nav.sop':'SOP', 'nav.staff':'Employees', 'nav.kpi':'KPI Evaluation', 'nav.att':'Attendance', 'nav.signout':'Sign out',
    'tb.back':'← Back', 'tb.newform':'+ New Form', 'tb.myforms':'📁 My Forms', 'tb.admin':'⚙️ Admin',
    'tb.cleardata':'🗑️ Clear Data', 'tb.save':'💾 Save', 'tb.print':'🖨️ Print / Save as PDF',
    'att.overview':"Today's Overview", 'att.shifts':'Shifts', 'att.records':'Attendance Records',
    'att.leave':'Leave Requests', 'att.reports':'Monthly Reports'
  },
  ku: {
    'nav.home':'ماڵەوە', 'nav.search':'گەڕان بە هەموو فۆرمەکان', 'nav.inv':'پشکنینی وەصڵ', 'nav.cf':'گەشەی دارایی',
    'nav.sop':'ڕێنمایی کار', 'nav.staff':'کارمەندان', 'nav.kpi':'هەڵسەنگاندنی KPI', 'nav.att':'ئامادەبوون', 'nav.signout':'چوونەدەرەوە',
    'tb.back':'← گەڕانەوە', 'tb.newform':'+ فۆرمی نوێ', 'tb.myforms':'📁 فۆرمەکانم', 'tb.admin':'⚙️ بەڕێوەبردن',
    'tb.cleardata':'🗑️ سڕینەوەی داتا', 'tb.save':'💾 پاشەکەوتکردن', 'tb.print':'🖨️ چاپکردن / وەک PDF',
    'att.overview':'تێڕوانینی ئەمڕۆ', 'att.shifts':'گۆڕەکان', 'att.records':'تۆمارەکانی ئامادەبوون',
    'att.leave':'داواکاری مۆڵەت', 'att.reports':'ڕاپۆرتی مانگانە'
  }
};
let currentLang = localStorage.getItem('dalare_lang') || 'en';

function applyLanguage(){
  const dict = I18N[currentLang] || I18N.en;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    // In English mode, elements that also carry an admin-customizable
    // data-label-key are left to applySiteLabels() so a manager's custom
    // wording isn't silently overwritten by our built-in English default.
    if(currentLang === 'en' && el.dataset.labelKey) return;
    const key = el.dataset.i18n;
    if(dict[key]) el.textContent = dict[key];
  });
  const btn = document.getElementById('langToggleBtn');
  if(btn) btn.textContent = currentLang === 'en' ? '🌐 EN' : '🌐 کوردی';
  document.documentElement.setAttribute('lang', currentLang === 'ku' ? 'ckb' : 'en');
}

function toggleLanguage(){
  currentLang = currentLang === 'en' ? 'ku' : 'en';
  localStorage.setItem('dalare_lang', currentLang);
  applyLanguage();
}

function toggleSettingsMenu(){
  const dd = document.getElementById('settingsMenuDropdown');
  const willOpen = dd.style.display === 'none';
  if(willOpen){
    const btn = document.getElementById('settingsMenuBtn');
    const rect = btn.getBoundingClientRect();
    dd.style.top = (rect.bottom + 4) + 'px';
    dd.style.left = Math.max(8, rect.right - 200) + 'px';
  }
  dd.style.display = willOpen ? 'block' : 'none';
}
function closeSettingsMenu(){
  document.getElementById('settingsMenuDropdown').style.display = 'none';
}
document.addEventListener('click', (e) => {
  const wrap = document.getElementById('settingsMenuWrap');
  if(wrap && !wrap.contains(e.target)) closeSettingsMenu();
});

function openTabOrderManager(){
  if(!isSuperAdmin()){ flash('Only a super admin can reorder tabs.', true); return; }
  const list = document.getElementById('toList');
  list.innerHTML = '';
  const all = currentTabIds();
  const ordered = [...tabOrder.filter(id => all.includes(id)), ...all.filter(id => !tabOrder.includes(id))];
  ordered.forEach(id=>{
    const row = document.createElement('div');
    row.className = 'sb-field-row';
    row.draggable = true;
    row.dataset.tabid = id;
    row.innerHTML = `<span class="sb-drag">⋮⋮</span><span style="flex:1;font-size:.88rem;color:#000;">${tabIdLabel(id).replace(/</g,'&lt;')}</span>`;
    row.addEventListener('dragstart', ()=>{ row.classList.add('dragging'); });
    row.addEventListener('dragend', ()=>{ row.classList.remove('dragging'); });
    list.appendChild(row);
  });
  document.getElementById('toOverlay').classList.add('open');
}
function closeTabOrderManager(){ document.getElementById('toOverlay').classList.remove('open'); }

async function saveTabOrder(){
  const newOrder = Array.from(document.querySelectorAll('#toList .sb-field-row')).map(row => row.dataset.tabid);
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/tab_order`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', order: newOrder, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    tabOrder = newOrder;
    applyTabOrder();
    renderHomeGrid();
    closeTabOrderManager();
    logActivity('save_tab_order', null, newOrder.join(','));
    flash('Tab order saved');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function addKpiOrderRow(){
  const list = document.getElementById('kpiOrderList');
  const row = document.createElement('div');
  row.className = 'sb-field-row';
  row.draggable = true;
  row.dataset.taskId = 'task-' + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
  row.innerHTML = `
    <span class="sb-drag">⋮⋮</span>
    <input type="text" class="kpi-order-label" value="" placeholder="New task name" style="flex:1;">
    <select class="kpi-order-group" style="width:105px;">
      ${KPI_GROUPS.map(g => `<option value="${g.id}">${g.icon} ${g.label}</option>`).join('')}
    </select>
    <input type="text" value="" class="kpi-order-dept" placeholder="Department" list="staffDeptList" style="width:110px;">
    <input type="number" min="0" max="100" value="0" class="kpi-order-weight" style="width:60px;">
    <span style="font-size:.7rem;color:#888;">%</span>
    <button type="button" class="btn-small remove" onclick="this.closest('.sb-field-row').remove(); updateKpiOrderTotal();" title="Remove task">×</button>
  `;
  row.addEventListener('dragstart', ()=>{ row.classList.add('dragging'); });
  row.addEventListener('dragend', ()=>{ row.classList.remove('dragging'); updateKpiOrderTotal(); });
  row.querySelector('.kpi-order-weight').addEventListener('input', updateKpiOrderTotal);
  list.appendChild(row);
  row.querySelector('.kpi-order-label').focus();
  updateKpiOrderTotal();
}

async function loadStaffDeptList(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/employees?select=department`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    const depts = [...new Set(rows.map(r => r.department).filter(Boolean))];
    document.getElementById('staffDeptList').innerHTML = depts.map(d => `<option value="${d.replace(/"/g,'&quot;')}">`).join('');
  }catch(e){ /* fine, list just stays empty */ }
}

function openKpiOrderManager(){
  if(!isSuperAdmin()){ flash('Only a super admin can reorder KPI tasks.', true); return; }
  const gRow = document.getElementById('kpiGroupWeightRow');
  gRow.innerHTML = KPI_GROUPS.map(g => `
    <div style="display:flex;flex-direction:column;gap:4px;">
      <label style="font-size:.72rem;color:#666;">${g.icon} ${g.label}</label>
      <div style="display:flex;align-items:center;gap:4px;">
        <input type="number" min="0" max="100" class="kpi-group-weight" data-group="${g.id}"
          value="${KPI_GROUP_WEIGHTS[g.id] !== undefined ? KPI_GROUP_WEIGHTS[g.id] : 0}" style="width:70px;">
        <span style="font-size:.75rem;color:#888;">%</span>
      </div>
    </div>
  `).join('');
  gRow.querySelectorAll('.kpi-group-weight').forEach(inp => inp.addEventListener('input', updateKpiGroupWeightTotal));
  updateKpiGroupWeightTotal();

  const list = document.getElementById('kpiOrderList');
  list.innerHTML = '';
  KPI_DEFS.forEach(k => {
    const row = document.createElement('div');
    row.className = 'sb-field-row';
    row.draggable = true;
    row.dataset.taskId = k.id;
    row.innerHTML = `
      <span class="sb-drag">⋮⋮</span>
      <input type="text" class="kpi-order-label" value="${k.label.replace(/"/g,'&quot;')}" style="flex:1;">
      <select class="kpi-order-group" style="width:105px;">
        ${KPI_GROUPS.map(g => `<option value="${g.id}" ${g.id === (k.group||'data-entry') ? 'selected' : ''}>${g.icon} ${g.label}</option>`).join('')}
      </select>
      <input type="text" value="${(k.department||'').replace(/"/g,'&quot;')}" class="kpi-order-dept" placeholder="Department" list="staffDeptList" style="width:110px;">
      <input type="number" min="0" max="100" value="${k.weight}" class="kpi-order-weight" style="width:60px;">
      <span style="font-size:.7rem;color:#888;">%</span>
      <button type="button" class="btn-small remove" onclick="this.closest('.sb-field-row').remove(); updateKpiOrderTotal();" title="Remove task">×</button>
    `;
    row.addEventListener('dragstart', ()=>{ row.classList.add('dragging'); });
    row.addEventListener('dragend', ()=>{ row.classList.remove('dragging'); updateKpiOrderTotal(); });
    list.appendChild(row);
  });
  list.querySelectorAll('.kpi-order-weight').forEach(inp => inp.addEventListener('input', updateKpiOrderTotal));
  updateKpiOrderTotal();
  document.getElementById('kpiOrderOverlay').classList.add('open');
  loadStaffDeptList();
}
function closeKpiOrderManager(){ document.getElementById('kpiOrderOverlay').classList.remove('open'); }

function updateKpiOrderTotal(){
  const total = Array.from(document.querySelectorAll('#kpiOrderList .kpi-order-weight'))
    .reduce((sum, inp) => sum + (parseFloat(inp.value) || 0), 0);
  const box = document.getElementById('kpiOrderTotal');
  box.textContent = `Total weight: ${total}%` + (total !== 100 ? ' (should be 100)' : ' ✓');
  box.style.color = total === 100 ? '#0f7a3d' : '#a8462e';
}

function updateKpiGroupWeightTotal(){
  const total = Array.from(document.querySelectorAll('.kpi-group-weight'))
    .reduce((sum, inp) => sum + (parseFloat(inp.value) || 0), 0);
  const box = document.getElementById('kpiGroupWeightTotal');
  box.textContent = `Section weights total: ${total}%` + (total !== 100 ? ' (should be 100)' : ' ✓');
  box.style.color = total === 100 ? '#0f7a3d' : '#a8462e';
}

async function saveKpiOrder(){
  const rows = Array.from(document.querySelectorAll('#kpiOrderList .sb-field-row'));
  const newDefs = rows.map(row => ({
    id: row.dataset.taskId,
    label: row.querySelector('.kpi-order-label').value.trim() || 'Untitled',
    department: row.querySelector('.kpi-order-dept').value.trim(),
    group: row.querySelector('.kpi-order-group').value || 'data-entry',
    weight: parseFloat(row.querySelector('.kpi-order-weight').value) || 0
  }));
  const newGroupWeights = {};
  document.querySelectorAll('.kpi-group-weight').forEach(inp => {
    newGroupWeights[inp.dataset.group] = parseFloat(inp.value) || 0;
  });
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', kpi_defs: newDefs, kpi_group_weights: newGroupWeights, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    KPI_DEFS = newDefs;
    KPI_GROUP_WEIGHTS = newGroupWeights;
    if(document.getElementById('kpiGroupsWrap')) renderKpiRows();
    closeKpiOrderManager();
    logActivity('save_kpi_order', null, newDefs.map(d=>d.label).join(','));
    flash('KPI tasks updated');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}


let editingSectionId = null;


/* =======================  HEADER/FOOTER TEXT (super_admin)  ======================= */
let siteSubtitle = 'DALARE WAREHOUSE — BUILDING TRUST, DELIVERING QUALITY';

function applySubtitleText(){
  document.querySelectorAll('.subtitle-bar .subtitle-text').forEach(el => {
    el.textContent = siteSubtitle;
  });
}

function refreshTabVisibility(){
  document.getElementById('tabInv').style.display   = canViewTab('inv')   ? '' : 'none';
  document.getElementById('tabCf').style.display    = canViewTab('cf')    ? '' : 'none';
  document.getElementById('tabSop').style.display   = canViewTab('sop')   ? '' : 'none';
  document.getElementById('tabStaff').style.display = canViewTab('staff') ? 'block' : 'none';
  document.getElementById('tabKpi').style.display = canViewTab('kpi') ? '' : 'none';
  document.getElementById('tabAtt').style.display = canViewTab('att') ? '' : 'none';
  document.getElementById('tabHr').style.display = canViewTab('hr') ? '' : 'none';
  document.getElementById('globalSearchTabBtn').style.display = isEmployee() ? 'none' : '';
  if(!canViewTab(activeTab)){
    const firstOk = ['home','inv','cf','sop','staff','kpi','att','hr'].find(canViewTab);
    if(firstOk) switchTab(firstOk);
  }
  applyViewerLock();
  renderHomeGrid();
}

/* =======================  GLOBAL SEARCH ACROSS ALL FORMS  ======================= */
let globalSearchTimer = null;

function openGlobalSearch(){
  document.getElementById('globalSearchInput').value = '';
  document.getElementById('globalSearchResults').innerHTML = '<div class="mgr-empty">Start typing to search across every section.</div>';
  document.getElementById('globalSearchOverlay').classList.add('open');
  setTimeout(() => document.getElementById('globalSearchInput').focus(), 100);
}
function closeGlobalSearch(){ document.getElementById('globalSearchOverlay').classList.remove('open'); }

function debouncedGlobalSearch(){
  clearTimeout(globalSearchTimer);
  globalSearchTimer = setTimeout(performGlobalSearch, 300);
}

async function performGlobalSearch(){
  const q = document.getElementById('globalSearchInput').value.trim();
  const box = document.getElementById('globalSearchResults');
  if(!q){ box.innerHTML = '<div class="mgr-empty">Start typing to search across every section.</div>'; return; }
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }
  box.innerHTML = '<div class="mgr-empty">Searching…</div>';

  const sources = [];
  if(canViewTab('inv'))  sources.push({ type:'inv',  table:'forms',          label:'Invoice',  icon:'🧾' });
  if(canViewTab('cf'))   sources.push({ type:'cf',   table:'cashflow_forms', label:'Cash Flow', icon:'💵' });
  if(canViewTab('sop'))  sources.push({ type:'sop',  table:'sop_forms',      label:'SOP',       icon:'📋' });
  if(canViewTab('kpi'))  sources.push({ type:'kpi',  table:'kpi_forms',      label:'KPI',       icon:'📊' });

  const hrSources = [];
  if(canViewTab('hr')){
    hrSources.push(
      { table:'assets', label:'Asset', icon:'🗂️', nameField:'assigned_to', titleField:'name' },
      { table:'expenses', label:'Expense', icon:'💰', nameField:'employee_name', titleField:'category' },
      { table:'disciplinary_records', label:'Disciplinary', icon:'⚠️', nameField:'employee_name', titleField:'type' },
      { table:'trainings', label:'Training', icon:'🎓', nameField:'employee_name', titleField:'certification' }
    );
  }

  try{
    const calls = sources.map(s =>
      fetch(`${SUPABASE_URL}/rest/v1/${s.table}?select=id,company_name,updated_at&deleted_at=is.null&order=updated_at.desc&limit=100`, { headers: sbHeaders() })
        .then(r => r.ok ? r.json() : [])
        .then(rows => rows.map(r => ({ ...r, ...s })))
        .catch(() => [])
    );

    // Custom sections share one table; search it once and tag each row with its section.
    const customPromise = fetch(`${SUPABASE_URL}/rest/v1/custom_section_forms?select=id,company_name,updated_at,section_id&deleted_at=is.null&order=updated_at.desc&limit=200`, { headers: sbHeaders() })
      .then(r => r.ok ? r.json() : [])
      .then(rows => rows.map(r => ({
        ...r, type:'custom:'+r.section_id, table:'custom_section_forms',
        icon:'📁', label:(customSections[r.section_id]||{}).name || 'Custom'
      })))
      .catch(() => []);

    const hrCalls = hrSources.map(s =>
      fetch(`${SUPABASE_URL}/rest/v1/${s.table}?select=*&limit=100`, { headers: sbHeaders() })
        .then(r => r.ok ? r.json() : [])
        .then(rows => rows.map(r => ({
          id: r.id, company_name: r[s.nameField] || '(unnamed)', updated_at: r.created_at || r.requested_at || r.assigned_date || new Date().toISOString(),
          type: 'hr', table: s.table, label: s.label, icon: s.icon, detail: r[s.titleField] || ''
        })))
        .catch(() => [])
    );

    const results = (await Promise.all([...calls, customPromise, ...hrCalls])).flat();
    const qLower = q.toLowerCase();
    const filtered = results.filter(r =>
      (r.id || '').toLowerCase().includes(qLower) ||
      (r.company_name || '').toLowerCase().includes(qLower) ||
      (r.detail || '').toLowerCase().includes(qLower)
    ).sort((a,b) => new Date(b.updated_at) - new Date(a.updated_at)).slice(0, 40);

    if(!filtered.length){ box.innerHTML = '<div class="mgr-empty">No matching forms found.</div>'; return; }

    box.innerHTML = filtered.map(r => `
      <div class="ep-kpi-row" onclick="openGlobalSearchResult('${r.type}','${r.id.replace(/'/g,"\\'")}')">
        <div>
          <div style="font-weight:700;font-size:.82rem;">${r.icon} ${(r.company_name || '(unnamed)').replace(/</g,'&lt;')}</div>
          <div style="font-size:.72rem;color:#777;">${r.label}${r.detail ? ' · ' + String(r.detail).replace(/</g,'&lt;') : ''}${r.type !== 'hr' ? ' · ' + r.id.replace(/</g,'&lt;') : ''}</div>
        </div>
        <div style="font-size:.7rem;color:#999;">${timeAgo(r.updated_at)}</div>
      </div>
    `).join('');
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">Search failed. Try again.</div>'; }
}

function openGlobalSearchResult(type, id){
  closeGlobalSearch();
  switchTab(type === 'hr' ? 'hr' : type);
  if(type === 'inv') openInv(id);
  else if(type === 'cf') openCF(id);
  else if(type === 'sop') openSOP(id);
  else if(type === 'kpi') openKPI(id);
  else if(type.startsWith('custom:')) openCustomSectionForm(type.slice(7), id);
}

/* =======================  TRASH / RECOVER  ======================= */
const TRASH_TABLES = [
  { table:'forms',               label:'Invoice',   icon:'🧾', displayField:'company_name' },
  { table:'cashflow_forms',      label:'Cash Flow',  icon:'💵', displayField:'company_name' },
  { table:'sop_forms',           label:'SOP',        icon:'📋', displayField:'company_name' },
  { table:'kpi_forms',           label:'KPI',        icon:'📊', displayField:'company_name' },
  { table:'custom_section_forms',label:'Custom',     icon:'📁', displayField:'company_name' },
  { table:'attendance',          label:'Attendance', icon:'🕐', displayField:'employee_name' },
  { table:'leave_requests',      label:'Leave Request', icon:'📨', displayField:'employee_name' },
  { table:'assets',              label:'Asset',      icon:'🗂️', displayField:'name' },
  { table:'expenses',            label:'Expense',    icon:'💰', displayField:'employee_name' },
  { table:'disciplinary_records',label:'Disciplinary', icon:'⚠️', displayField:'employee_name' },
  { table:'trainings',           label:'Training',   icon:'🎓', displayField:'certification' },
];

let trashItemsCache = [];

function openTrash(){
  if(!isSuperAdmin()){ flash('Only a super admin can manage Trash.', true); return; }
  document.getElementById('trashFilterSelect').value = 'all';
  document.getElementById('trashOverlay').classList.add('open');
  loadTrashItems();
}
function closeTrash(){ document.getElementById('trashOverlay').classList.remove('open'); }

async function loadTrashItems(){
  const box = document.getElementById('trashResults');
  box.innerHTML = '<div class="mgr-empty">Loading\u2026</div>';
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }
  try{
    const calls = TRASH_TABLES.map(t =>
      fetch(`${SUPABASE_URL}/rest/v1/${t.table}?select=id,${t.displayField},deleted_at${t.table==='custom_section_forms' ? ',section_id' : ''}&deleted_at=not.is.null&order=deleted_at.desc&limit=100`, { headers: sbHeaders() })
        .then(r => r.ok ? r.json() : [])
        .then(rows => rows.map(r => ({ ...r, displayName: r[t.displayField], table:t.table, label: t.table === 'custom_section_forms' ? ((customSections[r.section_id]||{}).name || 'Custom') : t.label, icon:t.icon })))
        .catch(() => [])
    );
    trashItemsCache = (await Promise.all(calls)).flat().sort((a,b) => new Date(b.deleted_at) - new Date(a.deleted_at));

    const select = document.getElementById('trashFilterSelect');
    const prevValue = select.value || 'all';
    const uniqueLabels = [...new Set(trashItemsCache.map(r => r.label))];
    select.innerHTML = '<option value="all">All sections</option>' +
      uniqueLabels.map(l => `<option value="${l.replace(/"/g,'&quot;')}">${l.replace(/</g,'&lt;')}</option>`).join('');
    select.value = uniqueLabels.includes(prevValue) ? prevValue : 'all';

    renderTrashItems();
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">Could not load Trash.</div>'; }
}

function renderTrashItems(){
  const box = document.getElementById('trashResults');
  const filter = document.getElementById('trashFilterSelect').value;
  const items = filter === 'all' ? trashItemsCache : trashItemsCache.filter(r => r.label === filter);
  if(!items.length){ box.innerHTML = `<div class="mgr-empty">${trashItemsCache.length ? 'No items match this filter.' : 'Trash is empty.'}</div>`; return; }
  box.innerHTML = items.map(r => `
    <div class="ep-kpi-row" style="cursor:default;">
      <div>
        <div style="font-weight:700;font-size:.82rem;">${r.icon} ${(r.displayName || '(unnamed)').replace(/</g,'&lt;')}</div>
        <div style="font-size:.72rem;color:#777;">${r.label} \u00b7 ${r.id.replace(/</g,'&lt;')} \u00b7 deleted ${timeAgo(r.deleted_at)}</div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="mgr-btn open-b" style="padding:6px 10px;font-size:.72rem;" onclick="restoreTrashItem('${r.table}','${r.id.replace(/'/g,"\\'")}')">Restore</button>
        <button class="mgr-btn del-b" style="padding:6px 10px;font-size:.72rem;" onclick="permanentlyDeleteTrashItem('${r.table}','${r.id.replace(/'/g,"\\'")}')">Delete Forever</button>
      </div>
    </div>
  `).join('');
}

async function restoreTrashItem(table, id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`,
      { method:'PATCH', headers: sbHeaders(), body: JSON.stringify({ deleted_at: null }) });
    if(!res.ok) throw new Error(await res.text());
    flash('Restored ' + id);
    loadTrashItems();
    if(activeTable() === table) loadFormsList();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function permanentlyDeleteTrashItem(table, id){
  if(!confirm(`Permanently delete ${id}? This cannot be undone.`)) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`,
      { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    logActivity('permanent_delete', id, table);
    flash('Permanently deleted ' + id);
    loadTrashItems();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadCompanyNamesList(){
  if(!backendReady()) return;
  try{
    const [invRes, cfRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/forms?select=company_name&deleted_at=is.null&order=updated_at.desc&limit=200`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms?select=company_name&deleted_at=is.null&order=updated_at.desc&limit=200`, { headers: sbHeaders() }),
    ]);
    const invRows = invRes.ok ? await invRes.json() : [];
    const cfRows = cfRes.ok ? await cfRes.json() : [];
    const names = [...new Set([...invRows, ...cfRows].map(r => (r.company_name||'').trim()).filter(Boolean))];
    const list = document.getElementById('companyNamesList');
    if(list) list.innerHTML = names.map(n => `<option value="${n.replace(/"/g,'&quot;')}">`).join('');
  }catch(e){ /* autocomplete is a nice-to-have; fail silently */ }
}

async function loadEmployeeNamesList(){
  if(!backendReady()) return;
  try{
    const [empRes, kpiRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/employees?select=full_name`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/kpi_forms?select=company_name&deleted_at=is.null&order=updated_at.desc&limit=200`, { headers: sbHeaders() }),
    ]);
    const empRows = empRes.ok ? await empRes.json() : [];
    const kpiRows = kpiRes.ok ? await kpiRes.json() : [];
    const names = [...new Set([...empRows.map(r=>r.full_name), ...kpiRows.map(r=>r.company_name)].map(n => (n||'').trim()).filter(Boolean))];
    const list = document.getElementById('employeeNamesList');
    if(list) list.innerHTML = names.map(n => `<option value="${n.replace(/"/g,'&quot;')}">`).join('');
  }catch(e){ /* autocomplete is a nice-to-have; fail silently */ }
}

async function loadCfSectionList(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms?select=data&deleted_at=is.null&order=updated_at.desc&limit=200`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    const sections = new Set();
    rows.forEach(r => (r.data && r.data.rows || []).forEach(row => { if(row.sectionNo) sections.add(String(row.sectionNo).trim()); }));
    const list = document.getElementById('cfSectionList');
    if(list) list.innerHTML = [...sections].map(s => `<option value="${s.replace(/"/g,'&quot;')}">`).join('');
  }catch(e){ /* fine, list just stays empty */ }
}

async function loadRolePermissions(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/role_permissions?id=eq.default&select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(!rows.length || !rows[0].matrix || !Object.keys(rows[0].matrix).length) return;
    const stored = rows[0].matrix;
    const firstRole = stored[Object.keys(stored)[0]];
    const isOldFormat = firstRole && Array.isArray(firstRole.view);
    permissionMatrix = isOldFormat ? migrateOldPermissionFormat(stored) : { ...defaultPermissionMatrix(), ...stored };
    // Any module added to the app after this matrix was last saved won't
    // exist in stored data yet — fill it in with a safe default instead of
    // silently leaving the module invisible to that role.
    const modules = ['inv','cf','sop','staff','kpi','att','hr'];
    ALL_ROLES.forEach(role => {
      if(!permissionMatrix[role]) permissionMatrix[role] = {};
      modules.forEach(mod => {
        if(!permissionMatrix[role][mod]) permissionMatrix[role][mod] = defaultPermissionMatrix()[role][mod];
      });
    });
    refreshTabVisibility();
  }catch(e){ /* keep defaults */ }
}

const PERM_TAB_LABELS = { inv:'Invoice Verification', cf:'Cash Flow', sop:'SOP', staff:'Employees', kpi:'KPI Evaluation', att:'Attendance', hr:'HR Records' };
const CONFIGURABLE_ROLES = ['admin','manager','reviewer','accountant','warehouse_staff','staff','viewer'];

function openPermissionsManager(){
  if(!isSuperAdmin()){ flash('Only a super admin can manage permissions.', true); return; }
  const roleSelect = document.getElementById('permRoleSelect');
  roleSelect.innerHTML = CONFIGURABLE_ROLES.map(r => `<option value="${r}">${ROLE_LABELS[r]}</option>`).join('');
  renderPermissionGrid();
  document.getElementById('permOverlay').classList.add('open');
}
function closePermissionsManager(){ document.getElementById('permOverlay').classList.remove('open'); }

function renderPermissionGrid(){
  const role = document.getElementById('permRoleSelect').value;
  const box = document.getElementById('permMatrixBody');
  box.innerHTML = MANAGEABLE_TABS.map(tab => {
    const perm = (permissionMatrix[role] && permissionMatrix[role][tab]) || emptyPerms();
    return `
      <tr>
        <td class="perm-tab-label">${PERM_TAB_LABELS[tab] || tab}</td>
        ${PERMISSION_TYPES.map(pt => `
          <td class="perm-cell" style="text-align:center;">
            <input type="checkbox" data-tab="${tab}" data-perm="${pt}" ${perm[pt] ? 'checked' : ''} onchange="onPermCellToggle(this)">
          </td>`).join('')}
      </tr>`;
  }).join('');
}

function onPermCellToggle(checkbox){
  const role = document.getElementById('permRoleSelect').value;
  const tab = checkbox.dataset.tab;
  const pt = checkbox.dataset.perm;
  if(!permissionMatrix[role]) permissionMatrix[role] = {};
  if(!permissionMatrix[role][tab]) permissionMatrix[role][tab] = emptyPerms();
  permissionMatrix[role][tab][pt] = checkbox.checked;

  // Create/Edit/Delete/Approve/Reject/Export all require View — turn it on
  // automatically rather than leaving a contradictory state.
  if(checkbox.checked && pt !== 'view'){
    permissionMatrix[role][tab].view = true;
    const viewBox = document.querySelector(`input[data-tab="${tab}"][data-perm="view"]`);
    if(viewBox) viewBox.checked = true;
  }
  // Turning off View turns off everything else for that module — can't
  // create/edit/delete/approve/export what you can't see.
  if(pt === 'view' && !checkbox.checked){
    PERMISSION_TYPES.forEach(other => {
      if(other === 'view') return;
      permissionMatrix[role][tab][other] = false;
      const box = document.querySelector(`input[data-tab="${tab}"][data-perm="${other}"]`);
      if(box) box.checked = false;
    });
  }
}

async function saveRolePermissions(){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/role_permissions`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', matrix: permissionMatrix, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    closePermissionsManager();
    logActivity('save_role_permissions', null, 'Updated permission matrix');
    flash('Permissions updated ✓');
    refreshTabVisibility();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadSiteSettings(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings?id=eq.default&select=*`, { headers: sbHeaders() });
    if(!res.ok) return;
    const rows = await res.json();
    if(rows.length && rows[0].subtitle) siteSubtitle = rows[0].subtitle;
    if(rows.length && rows[0].contact_text) siteContactText = rows[0].contact_text;
    if(rows.length && rows[0].labels) siteLabels = rows[0].labels;
    if(rows.length && rows[0].theme_color) siteThemeColor = rows[0].theme_color;
    if(rows.length && rows[0].kpi_defs && rows[0].kpi_defs.length){
      const knownGroups = {
        'invoice-entry':'data-entry', 'invoice-return':'data-entry', 'definition':'data-entry',
        'barcode':'data-entry', 'audit-edit':'data-entry', 'branch-maintenance':'data-entry',
        'account-statement':'data-entry', 'transit':'data-entry',
        'errors':'errors',
        'uniform-compliance':'satisfaction', 'management-evaluation':'satisfaction',
      };
      KPI_DEFS = rows[0].kpi_defs.map(k => ({
        ...k,
        group: k.group || knownGroups[k.id] || 'data-entry'
      }));
    }
    if(rows.length && rows[0].kpi_group_weights && Object.keys(rows[0].kpi_group_weights).length){
      KPI_GROUP_WEIGHTS = rows[0].kpi_group_weights;
    }
    if(rows.length && rows[0].kpi_groups && rows[0].kpi_groups.length){
      KPI_GROUPS = rows[0].kpi_groups;
    }
    if(document.getElementById('kpiGroupsWrap')) renderKpiRows();
    if(rows.length && rows[0].logo_data_url) applyCustomLogo(rows[0].logo_data_url);
    applySubtitleText();
    applyContactText();
    applySiteLabels();
    applyThemeColor();
  }catch(e){ /* keep default text */ }
}

function applyCustomLogo(dataUrl){
  document.querySelectorAll('.drawer-logo, .home-logo, .logo-badge img').forEach(img => { img.src = dataUrl; });
}

function handleLogoUpload(input){
  if(!isSuperAdmin()){ flash('Only a super admin can change the logo.', true); return; }
  const file = input.files[0];
  if(!file) return;
  if(!file.type.startsWith('image/')){ flash('Please choose an image file.', true); return; }
  if(file.size > 2 * 1024 * 1024){ flash('Please choose an image under 2MB.', true); return; }
  const reader = new FileReader();
  reader.onload = async () => {
    const dataUrl = reader.result;
    applyCustomLogo(dataUrl);
    try{
      const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
        method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
        body: JSON.stringify({ id:'default', logo_data_url: dataUrl, updated_by: session.email, updated_at: new Date().toISOString() })
      });
      if(!res.ok) throw new Error(await res.text());
      logActivity('change_logo', null, null);
      flash('Logo updated for everyone');
    }catch(e){ console.error(e); flash(sbError(e), true); }
  };
  reader.readAsDataURL(file);
  input.value = '';
}

function openFooterEditor(){
  if(!isSuperAdmin()){ flash('Only a super admin can edit this.', true); return; }
  document.getElementById('footerTextInput').value = siteSubtitle;
  document.getElementById('footerOverlay').classList.add('open');
}
function closeFooterEditor(){ document.getElementById('footerOverlay').classList.remove('open'); }

async function saveFooterText(){
  const text = document.getElementById('footerTextInput').value.trim();
  if(!text){ flash('Enter some text first.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', subtitle: text, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    siteSubtitle = text;
    applySubtitleText();
    closeFooterEditor();
    logActivity('save_header_text', null, text);
    flash('Header text updated');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

let siteContactText = 'www.dalarecompany.com | +964 750 123 4567 | Erbil, Kurdistan Region, Iraq | info@dalarecompany.com';

function applyContactText(){
  document.querySelectorAll('footer.contact .contact-text').forEach(el => {
    el.textContent = siteContactText;
  });
}

function openContactEditor(){
  if(!isSuperAdmin()){ flash('Only a super admin can edit this.', true); return; }
  document.getElementById('contactTextInput').value = siteContactText;
  document.getElementById('contactOverlay').classList.add('open');
}
function closeContactEditor(){ document.getElementById('contactOverlay').classList.remove('open'); }

async function saveContactText(){
  const text = document.getElementById('contactTextInput').value.trim();
  if(!text){ flash('Enter some text first.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', contact_text: text, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    siteContactText = text;
    applyContactText();
    closeContactEditor();
    logActivity('save_contact_text', null, text);
    flash('Contact footer updated');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

/* =======================  SITE-WIDE TEXT & BRAND COLOR (super_admin)  ======================= */
let siteLabels = {};
let siteThemeColor = '#229949';

function applySiteLabels(){
  document.querySelectorAll('[data-label-key]').forEach(el => {
    const key = el.dataset.labelKey;
    if(siteLabels[key] !== undefined) el.textContent = siteLabels[key];
  });
}

function darkenHex(hex, amount){
  hex = hex.replace('#','');
  const num = parseInt(hex, 16);
  let r = Math.max(0, (num >> 16) - amount);
  let g = Math.max(0, ((num >> 8) & 0xff) - amount);
  let bl = Math.max(0, (num & 0xff) - amount);
  return '#' + [r,g,bl].map(v => v.toString(16).padStart(2,'0')).join('');
}

function applyThemeColor(){
  document.documentElement.style.setProperty('--forest', siteThemeColor);
  document.documentElement.style.setProperty('--forest-deep', darkenHex(siteThemeColor, 55));
}

async function quickEditLabel(key){
  if(!isSuperAdmin()){ flash('Only a super admin can edit this.', true); return; }
  const el = document.querySelector(`[data-label-key="${key}"]`);
  const current = el ? el.textContent.trim() : '';
  const text = prompt('Edit text:', current);
  if(text === null || !text.trim() || text.trim() === current) return;
  const trimmed = text.trim();
  try{
    const labels = { ...siteLabels, [key]: trimmed };
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', labels, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    siteLabels = labels;
    applySiteLabels();
    flash('Updated ✓');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function openSiteTextEditor(){
  if(!isSuperAdmin()){ flash('Only a super admin can edit site text.', true); return; }
  document.getElementById('brandColorInput').value = siteThemeColor;

  const seen = {};
  document.querySelectorAll('[data-label-key]').forEach(el => {
    const key = el.dataset.labelKey;
    if(!seen[key]) seen[key] = el.textContent.trim();
  });

  const box = document.getElementById('siteTextFields');
  box.innerHTML = Object.keys(seen).map(key => `
    <div class="site-text-row">
      <label title="${key}">${key}</label>
      <input type="text" data-key="${key}" value="${seen[key].replace(/"/g,'&quot;')}">
    </div>
  `).join('');

  document.getElementById('siteTextOverlay').classList.add('open');
}
function closeSiteTextEditor(){ document.getElementById('siteTextOverlay').classList.remove('open'); }

async function saveSiteText(){
  const labels = {};
  document.querySelectorAll('#siteTextFields input[data-key]').forEach(inp => {
    labels[inp.dataset.key] = inp.value;
  });
  const color = document.getElementById('brandColorInput').value;

  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', labels, theme_color: color, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    siteLabels = labels;
    siteThemeColor = color;
    applySiteLabels();
    applyThemeColor();
    closeSiteTextEditor();
    logActivity('save_site_text', null, 'labels + color updated');
    flash('Site text & color updated');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function openSectionBuilder(sectionId){
  if(!isSuperAdmin()){ flash('Only a super admin can manage sections.', true); return; }
  editingSectionId = sectionId || null;
  const section = sectionId ? customSections[sectionId] : null;

  document.getElementById('sbName').value = section ? section.name : '';
  document.getElementById('sbFields').innerHTML = '';
  if(section && section.fields.length){
    section.fields.forEach(f => sbAddField(f.label, f.type, f.id));
  } else {
    sbAddField(); sbAddField();
  }

  document.getElementById('sbTitle').textContent = section ? 'Edit Section' : 'New Section';
  document.getElementById('sbSaveBtn').textContent = section ? 'Save Changes' : 'Create Section';
  document.getElementById('sbHint').textContent = section
    ? 'Add, remove, or reorder fields. Existing data is kept for any field you leave in place.'
    : 'Drag the ⋮⋮ handle to reorder fields. Everyone with access to the app will see this as a new tab once created. You can delete the whole section later from the tab itself.';

  document.getElementById('sbOverlay').classList.add('open');
}
function closeSectionBuilder(){ document.getElementById('sbOverlay').classList.remove('open'); editingSectionId = null; }

function sbAddField(label, type, existingId){
  const wrap = document.getElementById('sbFields');
  const row = document.createElement('div');
  row.className = 'sb-field-row';
  row.draggable = true;
  if(existingId) row.dataset.fieldId = existingId;
  row.innerHTML = `
    <span class="sb-drag">⋮⋮</span>
    <input type="text" placeholder="Field name" value="${(label||'').replace(/"/g,'&quot;')}">
    <select>
      <option value="text" ${type==='text'?'selected':''}>Text</option>
      <option value="number" ${type==='number'?'selected':''}>Number</option>
      <option value="date" ${type==='date'?'selected':''}>Date</option>
      <option value="textarea" ${type==='textarea'?'selected':''}>Long text</option>
    </select>
    <button class="sb-del" onclick="this.closest('.sb-field-row').remove()">×</button>
  `;
  wrap.appendChild(row);
  row.addEventListener('dragstart', ()=>{ row.classList.add('dragging'); });
  row.addEventListener('dragend', ()=>{ row.classList.remove('dragging'); });
}

document.addEventListener('dragover', (e)=>{
  const dragging = document.querySelector('.dragging');
  if(!dragging) return;
  const container = dragging.parentElement;
  if(!container) return;
  e.preventDefault();
  const siblings = [...container.children].filter(el => el !== dragging && el.draggable);
  const after = siblings.find(el=>{
    const box = el.getBoundingClientRect();
    return e.clientY <= box.top + box.height/2;
  });
  if(after) container.insertBefore(dragging, after);
  else container.appendChild(dragging);
});

function slugify(name){
  return String(name).toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') || 'section';
}

async function createCustomSection(){
  const name = document.getElementById('sbName').value.trim();
  if(!name){ flash('Enter a section name.', true); return; }
  const fieldRows = Array.from(document.querySelectorAll('#sbFields .sb-field-row'));
  const fields = fieldRows.map((row,i) => {
    const label = row.querySelector('input[type=text]').value.trim();
    const type = row.querySelector('select').value;
    if(!label) return null;
    const id = row.dataset.fieldId || ('f' + i + '_' + Math.random().toString(36).slice(2,7));
    return { id, label, type };
  }).filter(Boolean);
  if(!fields.length){ flash('Add at least one named field.', true); return; }

  if(editingSectionId){
    const id = editingSectionId;
    try{
      const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_sections?id=eq.${encodeURIComponent(id)}`, {
        method:'PATCH', headers: sbHeaders({'Prefer':'return=minimal'}),
        body: JSON.stringify({ name, fields, updated_by: session.email, updated_at: new Date().toISOString() })
      });
      if(!res.ok) throw new Error(await res.text());
      customSections[id] = Object.assign({}, customSections[id], { name, fields });
      rebuildCustomSectionStructure(id);
      closeSectionBuilder();
      logActivity('edit_section', id, name);
      flash('Section updated: ' + name);
    }catch(e){ console.error(e); flash(sbError(e), true); }
    return;
  }

  const id = slugify(name) + '-' + Math.random().toString(36).slice(2,6);
  const section = { id, name, fields, created_by: session.email };

  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_sections`, {
      method:'POST', headers: sbHeaders({'Prefer':'return=minimal'}),
      body: JSON.stringify(section)
    });
    if(!res.ok) throw new Error(await res.text());
    customSections[id] = section;
    mountCustomSection(section);
    newCustomSectionForm(id);
    closeSectionBuilder();
    switchTab('custom:' + id);
    applyTabOrder();
    logActivity('create_section', id, name);
    flash('Section created: ' + name);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

function rebuildCustomSectionStructure(id){
  const section = customSections[id];
  if(!section) return;

  const tabBtn = document.getElementById('tab_custom_' + id);
  if(tabBtn){
    tabBtn.innerHTML = `📁 ${section.name.replace(/</g,'&lt;')}<span class="custom-tab-edit" title="Edit section" onclick="event.stopPropagation(); openSectionBuilder('${id}')">✎</span><span class="custom-tab-del" title="Delete section" onclick="event.stopPropagation(); deleteCustomSection('${id}')">×</span>`;
  }

  const sheet = document.getElementById('customForm_' + id);
  if(!sheet) return;
  const h1 = sheet.querySelector('.title-block h1');
  if(h1) h1.textContent = section.name;
  const sectionTitle = sheet.querySelector('.section-header .title');
  if(sectionTitle) sectionTitle.textContent = section.name;

  const table = sheet.querySelector('table.customlist');
  if(!table) return;
  const headRow = table.querySelector('thead tr');
  const ths = Array.from(headRow.children);
  for(let i=1;i<ths.length-1;i++) ths[i].remove();
  const lastTh = headRow.lastElementChild;
  section.fields.forEach(f=>{
    const th = document.createElement('th');
    th.textContent = f.label;
    headRow.insertBefore(th, lastTh);
  });

  const body = document.getElementById('customBody_' + id);
  if(!body) return;
  Array.from(body.querySelectorAll('tr')).forEach(tr=>{
    const existingVals = {};
    tr.querySelectorAll('input[data-field]').forEach(inp => { existingVals[inp.dataset.field] = inp.value; });
    const tds = Array.from(tr.children);
    for(let i=1;i<tds.length-1;i++) tds[i].remove();
    const lastTd = tr.lastElementChild;
    section.fields.forEach(f=>{
      const td = document.createElement('td');
      const ph = f.type === 'date' ? ' placeholder="dd/mm/yyyy"' : '';
      td.innerHTML = `<input type="text" data-field="${f.id}"${ph}>`;
      tr.insertBefore(td, lastTd);
      if(existingVals[f.id] !== undefined) td.querySelector('input').value = existingVals[f.id];
    });
  });
  applyViewerLock();
}

function mountCustomSection(section){
  customSections[section.id] = section;
  if(document.getElementById('tab_custom_' + section.id)) return; // already mounted

  const tabBtn = document.createElement('button');
  tabBtn.className = 'custom-tab-btn';
  tabBtn.id = 'tab_custom_' + section.id;
  tabBtn.onclick = () => switchTab('custom:' + section.id);
  tabBtn.innerHTML = `📁 ${section.name.replace(/</g,'&lt;')}<span class="custom-tab-edit" title="Edit section" onclick="event.stopPropagation(); openSectionBuilder('${section.id}')">✎</span><span class="custom-tab-del" title="Delete section" onclick="event.stopPropagation(); deleteCustomSection('${section.id}')">×</span>`;
  document.getElementById('customTabsSlot').appendChild(tabBtn);

  const logoSrc = document.querySelector('.logo-badge img').src;
  const headCols = section.fields.map(f => `<th>${f.label.replace(/</g,'&lt;')}</th>`).join('');

  const sheet = document.createElement('div');
  sheet.className = 'sheet hidden-tab';
  sheet.id = 'customForm_' + section.id;
  sheet.innerHTML = `
    <header class="title-block">
      <div class="logo-badge"><img src="${logoSrc}" alt="Dalare"></div>
      <div style="text-align:center;">
        <h1>${section.name.replace(/</g,'&lt;')}</h1>
        <div style="font-size:1.1rem;font-weight:700;">For Companies</div>
      </div>
    </header>
    <div class="subtitle-bar"><span class="subtitle-text">DALARE WAREHOUSE — BUILDING TRUST, DELIVERING QUALITY</span><span class="subtitle-edit" onclick="openFooterEditor()" title="Edit this text">✎</span></div>
    <div class="company-banner">
      <span class="company-label">Company</span>
      <input type="text" class="company-name-input" placeholder="Company Name" list="companyNamesList">
    </div>
    <div class="form-meta-bar">
      <div class="form-id-box">
        <span class="lbl">Form ID</span>
        <span class="val" id="customFormId_${section.id}">—</span>
      </div>
    </div>
    <div class="section-header"><div class="num">1</div><div class="title">${section.name.replace(/</g,'&lt;')}</div></div>
    <div class="price-table-wrap">
      <table class="customlist">
        <thead><tr><th style="width:40px;">No.</th>${headCols}<th style="width:34px;"></th></tr></thead>
        <tbody id="customBody_${section.id}"></tbody>
      </table>
    </div>
    <div class="table-actions">
      <button class="btn-small" onclick="addCustomRow('${section.id}')">+ Add Row</button>
    </div>
    <div style="height:18px;"></div>
  `;
  document.getElementById('customSheetsSlot').appendChild(sheet);
  customRowCounts[section.id] = 0;
  applySubtitleText();
}

function addCustomRow(sectionId, values){
  const section = customSections[sectionId];
  if(!section) return;
  customRowCounts[sectionId] = (customRowCounts[sectionId]||0) + 1;
  const tbody = document.getElementById('customBody_' + sectionId);
  const cells = section.fields.map(f => {
    const ph = f.type === 'date' ? ' placeholder="dd/mm/yyyy"' : '';
    return `<td><input type="text" data-field="${f.id}"${ph}></td>`;
  }).join('');
  const tr = document.createElement('tr');
  tr.innerHTML = `<td class="row-num">${customRowCounts[sectionId]}</td>${cells}<td><button class="btn-small remove" onclick="removeCustomRow('${sectionId}', this)">×</button></td>`;
  tbody.appendChild(tr);
  if(values){
    section.fields.forEach(f => {
      const inp = tr.querySelector(`[data-field="${f.id}"]`);
      if(inp) inp.value = values[f.id] || '';
    });
  }
}

function removeCustomRow(sectionId, btn){
  btn.closest('tr').remove();
  const rows = document.querySelectorAll(`#customBody_${sectionId} tr`);
  rows.forEach((r,i)=>{ r.querySelector('.row-num').textContent = i+1; });
  customRowCounts[sectionId] = rows.length;
}

function serializeCustomSection(sectionId){
  const section = customSections[sectionId];
  const sheet = document.getElementById('customForm_' + sectionId);
  const rows = Array.from(document.querySelectorAll(`#customBody_${sectionId} tr`)).map(tr=>{
    const row = {};
    section.fields.forEach(f=>{
      const inp = tr.querySelector(`[data-field="${f.id}"]`);
      row[f.id] = inp ? inp.value : '';
    });
    return row;
  });
  return { companyName: sheet.querySelector('.company-name-input').value, rows };
}

function restoreCustomSection(sectionId, d){
  const sheet = document.getElementById('customForm_' + sectionId);
  sheet.querySelector('.company-name-input').value = d.companyName || '';
  document.getElementById('customBody_' + sectionId).innerHTML = '';
  customRowCounts[sectionId] = 0;
  const rows = d.rows && d.rows.length ? d.rows : [];
  const total = Math.max(rows.length, 10);
  for(let i=0;i<total;i++) addCustomRow(sectionId, rows[i]);
  applyViewerLock();
}

function setCustomFormId(sectionId, id){
  customFormIds[sectionId] = id;
  const el = document.getElementById('customFormId_' + sectionId);
  if(el) el.textContent = id || '—';
}
function makeCustomFormId(sectionId){
  const prefix = (sectionId.slice(0,3) || 'CX').toUpperCase();
  return `${prefix}-${new Date().getFullYear()}-${Math.floor(Math.random()*90000 + 10000)}`;
}

function newCustomSectionForm(sectionId){
  setCustomFormId(sectionId, makeCustomFormId(sectionId));
  restoreCustomSection(sectionId, {});
  flash('New form started');
}

async function saveCustomSectionForm(sectionId){
  if(!backendReady()){ flash('Backend not configured — see CONFIG at top of file.', true); return; }
  if(!customFormIds[sectionId]) setCustomFormId(sectionId, makeCustomFormId(sectionId));
  const section = customSections[sectionId];
  const payload = {
    id: customFormIds[sectionId],
    section_id: sectionId,
    company_name: document.querySelector(`#customForm_${sectionId} .company-name-input`).value || '(unnamed)',
    data: serializeCustomSection(sectionId),
    updated_by: session.email,
    updated_at: new Date().toISOString()
  };
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_section_forms`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save', customFormIds[sectionId], section.name);
    flash('Saved ✓ ' + customFormIds[sectionId]);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function openCustomSectionForm(sectionId, id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_section_forms?id=eq.${encodeURIComponent(id)}&select=*`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Form not found.', true); return; }
    setCustomFormId(sectionId, rows[0].id);
    restoreCustomSection(sectionId, rows[0].data || {});
    closeManager();
    flash('Opened ' + rows[0].id);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadCustomSections(){
  if(!backendReady()) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_sections?select=*&order=created_at.asc`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    rows.forEach(s => mountCustomSection(s));
    document.querySelectorAll('.custom-tab-btn').forEach(btn=>{
      const sid = btn.id.replace('tab_custom_','');
      btn.style.display = canViewTab('custom:'+sid) ? '' : 'none';
    });
    customSectionsLoaded = true;
    applyTabOrder();
    renderHomeGrid();
  }catch(e){ console.error(e); }
}

async function loadHomeTrendChart(){
  const box = document.getElementById('homeTrendChart');
  if(!box) return;
  if(!backendReady() || isEmployee() || !canViewTab('att')){ box.innerHTML = ''; return; }
  try{
    const start = new Date(); start.setDate(start.getDate() - 29);
    const startStr = start.toISOString().slice(0,10);
    const res = await fetch(`${SUPABASE_URL}/rest/v1/attendance?select=date,status&date=gte.${startStr}`, { headers: sbHeaders() });
    const rows = res.ok ? await res.json() : [];
    if(!rows.length){ box.innerHTML = ''; return; }

    const byDate = {};
    for(let i = 0; i < 30; i++){
      const d = new Date(start); d.setDate(d.getDate() + i);
      byDate[d.toISOString().slice(0,10)] = 0;
    }
    rows.forEach(r => {
      if(r.status === 'present' || r.status === 'late' || r.status === 'missing_checkout'){
        if(byDate[r.date] !== undefined) byDate[r.date]++;
      }
    });
    const dates = Object.keys(byDate).sort();
    const values = dates.map(d => byDate[d]);
    const max = Math.max(...values, 1);
    const w = 900, h = 90, barW = w / dates.length;

    const bars = values.map((v, i) => {
      const barH = (v / max) * (h - 16);
      const x = i * barW;
      const y = h - barH;
      const color = v === 0 ? '#e2e8e5' : '#229949';
      return `<rect x="${x + barW*0.15}" y="${y}" width="${barW*0.7}" height="${barH}" fill="${color}" rx="2"><title>${dates[i]}: ${v} present</title></rect>`;
    }).join('');

    box.innerHTML = `
      <div style="background:#fff;border-radius:14px;padding:16px 18px;box-shadow:0 4px 14px -8px rgba(10,36,23,.15);">
        <div style="font-weight:800;color:var(--forest-deep);font-size:.85rem;margin-bottom:8px;">Attendance — Last 30 Days</div>
        <svg viewBox="0 0 ${w} ${h}" style="width:100%;height:70px;display:block;">${bars}</svg>
        <div style="display:flex;justify-content:space-between;font-size:.65rem;color:#888;margin-top:4px;">
          <span>${dates[0]}</span><span>${dates[dates.length-1]}</span>
        </div>
      </div>`;
  }catch(e){ box.innerHTML = ''; }
}

async function loadHomeAnnouncement(){
  const box = document.getElementById('homeAnnouncementBanner');
  if(!box) return;
  if(!backendReady()){ box.innerHTML = ''; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings?id=eq.default&select=announcement,announcement_expiry`, { headers: sbHeaders() });
    const rows = res.ok ? await res.json() : [];
    const text = rows.length ? rows[0].announcement : '';
    const expiry = rows.length ? rows[0].announcement_expiry : null;
    if(!text || (expiry && expiry < new Date().toISOString().slice(0,10))){ box.innerHTML = ''; return; }
    box.innerHTML = `<div style="max-width:960px;margin:0 auto 10px;background:linear-gradient(120deg,#2f6fed,#1d4ed8);color:#fff;border-radius:12px;padding:12px 18px;display:flex;align-items:center;gap:10px;font-size:.85rem;font-weight:700;box-shadow:0 8px 22px -10px rgba(29,78,216,.5);">
      <span style="font-size:1.05rem;">📢</span><span>${text.replace(/</g,'&lt;')}</span>
    </div>`;
  }catch(e){ box.innerHTML = ''; }
}

function openAnnouncementEditor(){
  if(!isSuperAdmin()){ flash('Only a super admin can set the announcement.', true); return; }
  document.getElementById('announcementText').value = window._currentAnnouncement || '';
  document.getElementById('announcementExpiry').value = window._currentAnnouncementExpiry || '';
  document.getElementById('announcementOverlay').classList.add('open');
}
function closeAnnouncementEditor(){ document.getElementById('announcementOverlay').classList.remove('open'); }

async function openKpiVersionHistory(){
  if(!kpiFormId){ flash('Save the form at least once before viewing history.', true); return; }
  document.getElementById('kpiHistoryOverlay').classList.add('open');
  const box = document.getElementById('kpiHistoryList');
  box.innerHTML = '<div class="mgr-empty">Loading…</div>';
  if(!backendReady()){ box.innerHTML = '<div class="mgr-empty">Backend not configured.</div>'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/form_versions?form_table=eq.kpi_forms&form_id=eq.${encodeURIComponent(kpiFormId)}&select=*&order=saved_at.desc&limit=20`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ box.innerHTML = '<div class="mgr-empty">No earlier versions saved yet — history starts recording from your next save.</div>'; return; }
    box.innerHTML = `<table class="adm-table">
      <tr><th>Saved</th><th>By</th><th>Score</th><th></th></tr>
      ${rows.map((v,i) => {
        const score = computeKpiScoreFromData(v.data || {});
        return `<tr>
          <td>${new Date(v.saved_at).toLocaleString('en-US')}</td>
          <td>${(v.saved_by||'').replace(/</g,'&lt;')}</td>
          <td>${score.toFixed(1)}%</td>
          <td><button class="btn-small" onclick="restoreKpiVersion(${i})">↺ Restore</button></td>
        </tr>`;
      }).join('')}
    </table>`;
    window._kpiVersionRows = rows;
  }catch(e){ console.error(e); box.innerHTML = '<div class="mgr-empty">'+sbError(e)+'</div>'; }
}
function closeKpiVersionHistory(){ document.getElementById('kpiHistoryOverlay').classList.remove('open'); }

function restoreKpiVersion(index){
  const v = window._kpiVersionRows[index];
  if(!v) return;
  if(!confirm(`Restore this version from ${new Date(v.saved_at).toLocaleString('en-US')}? Your current unsaved changes will be lost.`)) return;
  restoreKpi(v.data);
  closeKpiVersionHistory();
  flash('Version restored — press Save to keep it.');
}

async function downloadFullBackup(){
  if(!isSuperAdmin()){ flash('Only a super admin can download a full backup.', true); return; }
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  flash('Preparing backup — this may take a moment…');
  const tables = [
    'forms','cashflow_forms','sop_forms','kpi_forms','employees','activity_log',
    'attendance','shifts','leave_requests','payroll_adjustments','form_versions',
    'assets','expenses','disciplinary_records','trainings','site_settings',
    'role_permissions','card_layout','print_columns','extra_columns','tab_order','custom_sections'
  ];
  const backup = { generated_at: new Date().toISOString(), generated_by: session.email, tables: {} };
  try{
    await Promise.all(tables.map(async (t) => {
      try{
        const res = await fetch(`${SUPABASE_URL}/rest/v1/${t}?select=*`, { headers: sbHeaders() });
        backup.tables[t] = res.ok ? await res.json() : [];
      }catch(e){ backup.tables[t] = []; }
    }));
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type:'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `dalare-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    logActivity('full_backup', null, `${tables.length} tables`);
    flash('Backup downloaded ✓');
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function saveAnnouncement(){
  const text = document.getElementById('announcementText').value.trim();
  const expiry = document.getElementById('announcementExpiry').value || null;
  if(!backendReady()){ flash('Backend not configured.', true); return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_settings`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify({ id:'default', announcement: text, announcement_expiry: expiry, updated_by: session.email, updated_at: new Date().toISOString() })
    });
    if(!res.ok) throw new Error(await res.text());
    window._currentAnnouncement = text;
    window._currentAnnouncementExpiry = expiry;
    flash('Announcement saved ✓');
    closeAnnouncementEditor();
    loadHomeAnnouncement();
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function loadHomeNotifications(){
  const box = document.getElementById('homeNotifBanner');
  if(!box) return;
  if(!backendReady() || isEmployee() || !canViewTab('att')){ box.innerHTML = ''; return; }
  try{
    const today = new Date().toISOString().slice(0,10);
    const [attRes, leaveRes] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/attendance?select=status&date=eq.${today}`, { headers: sbHeaders() }),
      fetch(`${SUPABASE_URL}/rest/v1/leave_requests?select=id&status=eq.pending`, { headers: sbHeaders() })
    ]);
    const attRows = attRes.ok ? await attRes.json() : [];
    const leaveRows = leaveRes.ok ? await leaveRes.json() : [];
    const lateCount = attRows.filter(r => r.status === 'late').length;
    const missingCount = attRows.filter(r => r.status === 'missing_checkout').length;
    const pendingLeaveCount = leaveRows.length;

    const items = [];
    if(lateCount) items.push({ ic:'⏰', text:`${lateCount} employee${lateCount===1?'':'s'} late today`, action:`switchTab('att')` });
    if(missingCount) items.push({ ic:'⚠️', text:`${missingCount} missing checkout${missingCount===1?'':'s'} today`, action:`switchTab('att')` });
    if(pendingLeaveCount) items.push({ ic:'📨', text:`${pendingLeaveCount} leave request${pendingLeaveCount===1?'':'s'} awaiting approval`, action:`switchTab('att')` });

    if(!items.length){ box.innerHTML = ''; return; }
    box.innerHTML = `<div style="max-width:960px;margin:0 auto 18px;display:flex;flex-direction:column;gap:8px;">
      ${items.map(it => `
        <div onclick="${it.action}" style="cursor:pointer;background:#fff;border:1px solid var(--line);border-radius:12px;padding:11px 16px;display:flex;align-items:center;gap:10px;font-size:.85rem;font-weight:700;color:#233b2b;box-shadow:0 4px 14px -8px rgba(10,36,23,.15);">
          <span style="font-size:1.05rem;">${it.ic}</span><span>${it.text}</span>
          <span style="margin-inline-start:auto;opacity:.5;font-size:.78rem;">View →</span>
        </div>`).join('')}
    </div>`;
  }catch(e){ box.innerHTML = ''; }
}

function renderHomeGrid(){
  const grid = document.getElementById('homeGrid');
  if(!grid) return;
  const cardDefs = {
    inv: {ic:'🧾', nm:'Invoice Verification', tab:'inv', key:'inv', color:'#2f6fed',
      dsc:'Accounting verification & pricing', bullets:['Verify invoices','Check pricing','Approve & record']},
    cf: {ic:'💵', nm:'Cash Flow', tab:'cf', key:'cf', color:'#0c8a4a',
      dsc:'Product, cash flow & stock tracking', bullets:['Track cash flow entries','Monitor stock','Save & print reports']},
    sop: {ic:'📋', nm:'SOP', tab:'sop', key:'sop', color:'#b8720e',
      dsc:'Standard operating procedures', bullets:['View SOP documents','Department procedures','Work instructions']},
    staff: {ic:'🪪', nm:'Employees', tab:'staff', key:'staff', color:'#7c5cd4',
      dsc:'Employee directory & ID cards', bullets:['View employee directory','Manage ID cards','Design & QR codes']},
    kpi: {ic:'📊', nm:'KPI Evaluation', tab:'kpi', key:'kpi', color:'#0e7c86',
      dsc:'Score employee performance', bullets:['Set targets & accuracy','Auto-calculated scores','Supervisor notes']},
  };
  Object.keys(cardDefs).forEach(id => { if(!canViewTab(id)) delete cardDefs[id]; });

  const customIds = Object.keys(customSections).filter(id => canViewTab('custom:'+id));
  // Order: whatever sequence Reorder Tabs has set, core tabs first then any custom ids not yet in tabOrder.
  const orderedIds = [...tabOrder.filter(id => cardDefs[id]), ...Object.keys(cardDefs).filter(id => !tabOrder.includes(id))];
  const cards = orderedIds.map(id => cardDefs[id]);
  customIds.forEach(id => {
    const s = customSections[id];
    cards.push({ic:'📁', nm:s.name, tab:'custom:'+id, key:null, color:'#64748b', dsc:'Custom section', bullets:['View records','Add new entries','Save & print']});
  });

  grid.innerHTML = cards.map((c,idx) => `
    <div class="home-card" style="--accent:${c.color};--i:${idx};" onclick="switchTab('${c.tab}')">
      <div class="card-top">
        <div class="ic" style="background:${c.color}1a;color:${c.color};">${c.ic}</div>
        <div>
          <div class="nm">${c.nm.replace(/</g,'&lt;')}</div>
          <div class="dsc"${c.key?` data-label-key="home.${c.key}.dsc"`:''}>${c.dsc}</div>
        </div>
      </div>
      <ul class="checklist">${c.bullets.map((b,i)=>`<li${c.key?` data-label-key="home.${c.key}.b${i+1}"`:''}>${b}</li>`).join('')}</ul>
      <button class="go-btn" style="background:${c.color};" onclick="event.stopPropagation(); switchTab('${c.tab}')">Go to Module →</button>
    </div>
  `).join('');

  const line = document.getElementById('homeUserLine');
  if(line && session.email) line.textContent = `${session.email} · ${session.role.replace('_',' ')}`;

  const greetEl = document.getElementById('homeGreeting');
  if(greetEl && session.email){
    const hour = new Date().getHours();
    const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    const namePart = session.email.split('@')[0].replace(/[._]/g,' ').replace(/\b\w/g, c => c.toUpperCase());
    greetEl.textContent = `${greeting}, ${namePart} 👋`;
  }

  applySiteLabels();
  renderHomeStats();
  renderRecentActivities();
}

async function renderHomeStats(){
  const box = document.getElementById('homeStats');
  if(!box) return;
  if(!backendReady() || isEmployee()){ box.innerHTML = ''; return; }
  try{
    const calls = [
      canViewTab('inv')  ? fetch(`${SUPABASE_URL}/rest/v1/forms?select=id`, { headers: sbHeaders() }) : null,
      canViewTab('cf')   ? fetch(`${SUPABASE_URL}/rest/v1/cashflow_forms?select=data`, { headers: sbHeaders() }) : null,
      canViewTab('sop')  ? fetch(`${SUPABASE_URL}/rest/v1/sop_forms?select=id`, { headers: sbHeaders() }) : null,
      canViewTab('staff')? fetch(`${SUPABASE_URL}/rest/v1/employees?select=id`, { headers: sbHeaders() }) : null,
    ];
    const [invRes, cfRes, sopRes, empRes] = await Promise.all(calls.map(c => c ? c.catch(()=>null) : null));

    const stats = [];
    if(invRes && invRes.ok) stats.push({ic:'🧾', label:'Total Invoices', numVal: (await invRes.json()).length, suffix:'', color:'#2f6fed'});
    if(cfRes && cfRes.ok){
      const rows = await cfRes.json();
      let total = 0;
      rows.forEach(r=>{
        const rrows = (r.data && r.data.rows) ? r.data.rows : [];
        rrows.forEach(row=>{ total += parseFloat(String(row.cashflow||'0').replace(/,/g,'')) || 0; });
      });
      stats.push({ic:'💵', label:'Total Cash Flow', numVal: total, suffix:'', color:'#0c8a4a'});
    }
    if(sopRes && sopRes.ok) stats.push({ic:'📋', label:'SOP Documents', numVal: (await sopRes.json()).length, suffix:'', color:'#b8720e'});
    if(empRes && empRes.ok) stats.push({ic:'🪪', label:'Employees', numVal: (await empRes.json()).length, suffix:'', color:'#7c5cd4'});

    box.innerHTML = stats.map(s => `
      <div class="stat-card">
        <div class="stat-ic" style="background:${s.color}1a;color:${s.color};">${s.ic}</div>
        <div class="stat-val" data-target="${s.numVal}" data-suffix="${(s.suffix||'').replace(/"/g,'&quot;')}">0${s.suffix||''}</div>
        <div class="stat-label">${s.label}</div>
      </div>
    `).join('');
    box.querySelectorAll('.stat-val').forEach(el => animateCountUp(el));
  }catch(e){ box.innerHTML = ''; }
}

function animateCountUp(el){
  const target = parseFloat(el.dataset.target) || 0;
  const suffix = el.dataset.suffix || '';
  if(target === 0 || window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    el.textContent = target.toLocaleString('en-US') + suffix;
    return;
  }
  const duration = 700;
  const startTime = performance.now();
  function tick(now){
    const progress = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const current = Math.round(target * eased);
    el.textContent = current.toLocaleString('en-US') + suffix;
    if(progress < 1) requestAnimationFrame(tick);
    else el.textContent = target.toLocaleString('en-US') + suffix;
  }
  requestAnimationFrame(tick);
}

function timeAgo(iso){
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if(diff < 60) return 'just now';
  if(diff < 3600) return Math.floor(diff/60) + ' min ago';
  if(diff < 86400) return Math.floor(diff/3600) + ' hr ago';
  const days = Math.floor(diff/86400);
  return days + (days > 1 ? ' days ago' : ' day ago');
}

async function renderRecentActivities(){
  const box = document.getElementById('homeActivities');
  if(!box) return;
  if(!isSuperAdmin() || !backendReady()){ box.style.display = 'none'; return; }
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/activity_log?select=*&order=created_at.desc&limit=5`, { headers: sbHeaders() });
    if(!res.ok) throw new Error();
    const rows = await res.json();
    box.style.display = '';
    box.querySelector('.activities-list').innerHTML = rows.length ? rows.map(r => `
      <div class="activity-row">
        <span class="activity-dot"></span>
        <div>
          <div class="activity-text">${(r.user_email||'someone').replace(/</g,'&lt;')} — ${(r.action||'').replace(/</g,'&lt;')}${r.form_id ? ' (' + r.form_id.replace(/</g,'&lt;') + ')' : ''}</div>
          <div class="activity-time">${timeAgo(r.created_at)}</div>
        </div>
      </div>
    `).join('') : '<div class="mgr-empty">No recent activity.</div>';
  }catch(e){ box.style.display = 'none'; }
}

async function deleteCustomSection(sectionId){
  if(!isSuperAdmin()){ flash('Only a super admin can delete sections.', true); return; }
  const section = customSections[sectionId];
  if(!confirm(`Permanently delete the section "${section.name}" and all its data? This cannot be undone.`)) return;
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_sections?id=eq.${encodeURIComponent(sectionId)}`,
      { method:'DELETE', headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    document.getElementById('tab_custom_' + sectionId)?.remove();
    document.getElementById('customForm_' + sectionId)?.remove();
    delete customSections[sectionId];
    if(activeTab === 'custom:' + sectionId) switchTab('home');
    logActivity('delete_section', sectionId, section.name);
    flash('Section deleted: ' + section.name);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
