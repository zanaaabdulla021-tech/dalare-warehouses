/* =======================  SOP  ======================= */
let sopFormId = null;

const SOP_DEFAULTS = [
  'تەواوکردنی داخلکردنی هەموو قائیمەکان',
  'پابەند بوون بەگروپی تەسعیر و داخل کردن (نوسینی تاریخ و سەعات و ناو و توقیع)',
  'داخل کردنی استرجعی لقەکان و رۆژانە تەواو بکرێ',
  'تەواو کردنی هەموو بارکۆدەکان رۆژانە',
  'جل و بەرگ و پێڵاو',
  'تێکەڵاو نەکردنی ئاتمی دەرمان و تجهیزات',
  'تعدیل کردن و ناردنی قائیمەی تەعدیل رۆژانە',
  'پاک و خاوێنی ژوور و کۆمپیتەر و هەموو شتێک',
  'دانانی وێنە لە گروپی مام سید لە واتسئەپ'
];

function autoGrow(ta){
  ta.style.height = 'auto';
  ta.style.height = ta.scrollHeight + 'px';
}

function renumberSop(){
  document.querySelectorAll('#sopList .sop-item').forEach((el,i)=>{
    el.querySelector('.sop-num').textContent = (i + 1) + '.';
  });
}

function addSopItem(text){
  const list = document.getElementById('sopList');
  const div = document.createElement('div');
  div.className = 'sop-item';
  div.innerHTML = `
    <span class="sop-num"></span>
    <textarea rows="1" oninput="autoGrow(this)"></textarea>
    <button class="sop-del no-print" onclick="removeSopItem(this)">×</button>
  `;
  list.appendChild(div);
  const ta = div.querySelector('textarea');
  ta.value = text || '';
  renumberSop();
  autoGrow(ta);
}

function removeSopItem(btn){
  btn.closest('.sop-item').remove();
  renumberSop();
}

function setSopFormId(id){
  sopFormId = id;
  document.getElementById('sopFormIdDisplay').textContent = id || '—';
}
function makeSopFormId(){
  return `SOP-${new Date().getFullYear()}-${Math.floor(Math.random()*90000 + 10000)}`;
}

function serializeSOP(){
  return {
    department: document.querySelector('.sop-dept').value,
    items: Array.from(document.querySelectorAll('#sopList textarea')).map(t => t.value),
    signLine: document.querySelector('.sop-signline').value,
    signName: document.querySelector('.sop-signname').value
  };
}

function restoreSOP(d){
  document.querySelector('.sop-dept').value =
    (d.department !== undefined && d.department !== '') ? d.department : 'DATA ENTRY (IT)';
  document.getElementById('sopList').innerHTML = '';
  const items = (d.items && d.items.length) ? d.items : SOP_DEFAULTS;
  items.forEach(t => addSopItem(t));
  document.querySelector('.sop-signline').value = d.signLine || '';
  document.querySelector('.sop-signname').value = d.signName || '';
  applyViewerLock();
}

function newFormSOP(){
  setSopFormId(makeSopFormId());
  restoreSOP({});
  flash('New SOP started');
}

async function saveSOP(){
  if(!backendReady()){ flash('Backend not configured — see CONFIG at top of file.', true); return; }
  if(!sopFormId) setSopFormId(makeSopFormId());
  const payload = {
    id: sopFormId,
    company_name: document.querySelector('.sop-dept').value || '(no department)',
    stage: 'entry',
    data: serializeSOP(),
    updated_at: new Date().toISOString(),
    updated_by: session.email || null
  };
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/sop_forms`, {
      method:'POST', headers: sbHeaders({'Prefer':'resolution=merge-duplicates'}),
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error(await res.text());
    logActivity('save', sopFormId);
    flash('Saved ✓ ' + sopFormId);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}

async function openSOP(id){
  try{
    const res = await fetch(`${SUPABASE_URL}/rest/v1/sop_forms?id=eq.${encodeURIComponent(id)}&select=*`, { headers: sbHeaders() });
    if(!res.ok) throw new Error(await res.text());
    const rows = await res.json();
    if(!rows.length){ flash('Form not found.', true); return; }
    setSopFormId(rows[0].id);
    restoreSOP(rows[0].data || {});
    closeManager();
    flash('Opened ' + rows[0].id);
  }catch(e){ console.error(e); flash(sbError(e), true); }
}
